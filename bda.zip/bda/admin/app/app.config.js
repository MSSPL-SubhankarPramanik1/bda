/**
 * Load modules for application
 */

angular
    .module('bda', [
        'ui.router',
        'ui.bootstrap',
        'ajaxServices',
        'helperServices',
        'cgBusy',
        'ngCookies', 
        'angular-confirm',       
        'angularUtils.directives.dirPagination',
        'blockUI'
        /*'ui.sortable',
        'ngFileUpload',
        'ngAnimate',
        'monospaced.qrcode',
        'ui.bootstrap.datetimepicker',
        'ngSanitize',
        'ngImageInputWithPreview',
        'multipleSelect',
        'ngDragDrop'*/
    ])

    .constant('CONFIG',{
        module_name     : 'bda',
        DebugMode       : true,
        StepCounter     : 0,
        AssetsUrl       : 'http://'+(location.hostname)+'/bda/admin/',
        ApiUrl          : 'http://'+(location.hostname)+'/bda/apis/admin/',
        TimeOut         : '2000',
        itemsPerPage    : '50'
    })

    .constant('oauth',{
        client_id       : '9d911a9a00ef11e48aff0019d114582',
        client_secret   : '463ceaeab4db11e3aa520019d119645',
        token_url       : 'http://'+(location.hostname)+'/bda/apis/admin/admin/token',
    });
