/**
 * Load states for application
 * more info on UI-Router states can be found at
 * https://github.com/angular-ui/ui-router/wiki
 */
angular
    .module('bda')
    .run(function($rootScope, CONFIG, $state, helper, $confirmModalDefaults, $location){
        $rootScope.CONFIG = CONFIG;
        $rootScope.bodyClass = 'admin-body';
        //$rootScope.bodyClass      = ''; 
        $rootScope.carousel         = '';
        $rootScope.parentBreadcrumb = '';
        $rootScope.breadcrumb       = '';
        $rootScope.leftMenu         = '';


        //state change event called here           
        $rootScope.$on('$stateChangeStart', 
        function(event, toState, toParams, fromState, fromParams){ 

            //console.log(fromState);                           
            //console.log(toState);    

            if(fromState.parent == 'home' && toState.parent == 'home'){
                //$rootScope.bodyClass = 'admin-body';
            } else {
                if(toState.parent == 'home' && toState.url == '/login'){
                    $rootScope.bodyClass = 'admin-body';
                    helper.checkUserAuthentication('home');
                }else{
                    $rootScope.bodyClass = 'agent-body';
                    helper.checkUserAuthentication(toState.name);
                }
            }
        })

        //get current timestamp
        function getTimeStamp(){
            var d = new Date();
            var currentTime = d.getTime();
            $rootScope.currentTime = currentTime;
        }
        getTimeStamp();

        $confirmModalDefaults.defaultLabels.title = 'bda';
    })
    .config(['$stateProvider', '$urlRouterProvider', '$locationProvider', function($stateProvider, $urlRouterProvider, $locationProvider){
    // any unknown URLS go to 404
    $urlRouterProvider.otherwise('/404');
    // no route goes to index
    $urlRouterProvider.when('', '/home/login');
    //$urlRouterProvider.when('#', '/home/login');
    //$urlRouterProvider.when('#/home', '/home/login');
    // use a state provider for routing
    //console.log($stateParams);
    $stateProvider
        
        //404 page not found section
        .state('404', {
            url: '/404',
            views: {
                "main": {
                  templateUrl: 'app/shared/404.html'
                },
            }
        })


        //Home module section
        .state('home', {
            url: '/home',
            views: {
                "main": {
                  controller: 'homeController as ctrl',
                  templateUrl: 'app/components/home/views/home.view.html'
                },
            }
        })

        .state('login', {
            parent: 'home',
            //url: '/home/login',
            url: '/login',
            templateUrl: 'app/components/home/views/login.view.html'
        })

        .state('forgetpassword', {
            parent: 'home',
            //url: '/home/forgetpassword',
            url: '/forgetpassword',
            templateUrl: 'app/components/home/views/forgetPassword.view.html'
        })

        .state('verifyPasscode', {
            parent: 'home',
            //url: '/home/verifyPasscode',
            url: '/verifyPasscode',
            templateUrl: 'app/components/home/views/verifyPasscode.view.html'
        })

        .state('resetPassword', {
            parent: 'home',
            //url: '/home/resetPassword',
            url: '/resetPassword',
            templateUrl: 'app/components/home/views/resetPassword.view.html'
        })        



        //Dashboard module section
        .state('dashboard', {
            // we'll add another state soon
            url: '/dashboard',
            views: {
                "main": {
                  controller: 'dashboardController as ctrl',
                  templateUrl: 'app/components/dashboard/views/dashboard.index.view.html'
                },
            }
        })

        .state('welcome', {
            parent: 'dashboard',
            //url: '/dashboard/welcome',
            url: '/welcome',
            templateUrl: 'app/components/dashboard/views/dashboard.welcome.view.html',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'welcome';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'dashboard';
              $rootScope.leftMenu         = '';
            }
        })

        //Profile module section
        .state("profile", {
            parent: 'dashboard',
            //url: '/dashboard/profile',
            url: '/profile',
            templateUrl: 'app/components/profile/views/profile.index.view.html',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'profile';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'profile';
              $rootScope.leftMenu         = '';
            } 
        })

        .state("profile.edit", {
            //parent: 'dashboard',
            //url: '/dashboard/profile/edit',
            url: '/edit',
            templateUrl: 'app/components/profile/views/edit.profile.html',
            controller: 'editProfileController as epc',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'edit_profile';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'Edit Profile';
              $rootScope.leftMenu         = '';
            } 
        })

        .state("profile.changepassword", {
            //parent: 'dashboard',
            //url: '/dashboard/profile/changepassword',
            url: '/changepassword',
            templateUrl: 'app/components/profile/views/change.password.html',
            controller: 'changePasswordController as cpc',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'change_password';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'Change Password ';
              $rootScope.leftMenu         = '';
            }            
        })


        //Agent module section
        .state("agents", {
            parent: 'dashboard',
            //url: '/dashboard/agents',
            url: '/agents',
            templateUrl: 'app/components/agents/views/agents.index.view.html'
        })

        .state("agents.list", {
            //parent: 'dashboard',
            //url: '/dashboard/agents/list',
            url: '/list',
            templateUrl: 'app/components/agents/views/agents.list.view.html',
            controller: 'agentsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'agents';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'Agent Code';
              $rootScope.leftMenu         = 'list';
            }
        })

        .state("agents.add", {
            //parent: 'dashboard',
            //url: '/dashboard/agents/add',
            url: '/add',
            templateUrl: 'app/components/agents/views/agents.add.view.html',
            controller: 'agentsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'agents';
              $rootScope.parentBreadcrumb = 'agent code';
              $rootScope.breadcrumb       = 'add agent code';
              $rootScope.leftMenu         = 'add';
            }
        })

        .state("agents.import", {
            //parent: 'dashboard',
            //url: '/dashboard/agents/import',
            url: '/import',
            templateUrl: 'app/components/agents/views/agents.import.view.html',
            controller: 'agentsController',            
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'agents';
              $rootScope.parentBreadcrumb = 'agent code';
              $rootScope.breadcrumb       = 'import agent code';
              $rootScope.leftMenu         = 'import';              
            }
        })


        //Products module section
        .state("products", {
            parent: 'dashboard',
            //url: '/dashboard/products',
            url: '/products',
            templateUrl: 'app/components/products/views/products.index.view.html'
        })

        .state("products.list", {
            //url: '/dashboard/products/list',
            url: '/list',
            templateUrl: 'app/components/products/views/products.list.view.html',
            controller: 'productsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'products';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'product';
              $rootScope.leftMenu         = 'list'; 
            }
        })

        .state("products.add", {
            //url: '/dashboard/products/add',
            url: '/add',
            templateUrl: 'app/components/products/views/products.add.view.html',
            controller: 'productsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'products';
              $rootScope.parentBreadcrumb = 'product';
              $rootScope.breadcrumb       = 'add product';
              $rootScope.leftMenu         = 'add';
            }
        })

        .state("products.payment_interest", {
            //url: '/dashboard/products/payment_interest/:productId',
            url: '/payment_interest/:productId',
            templateUrl: 'app/components/products/views/products.payment_interest.view.html',
            controller: 'editProductsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'products';
              $rootScope.parentBreadcrumb = 'product';
              $rootScope.breadcrumb       = 'Payment & Interest';
              $rootScope.leftMenu         = 'payment_interest';
            }
        })

        .state("products.coin_earning", {
            //url: '/dashboard/products/coin_earning/:productId',
            url: '/coin_earning/:productId',
            templateUrl: 'app/components/products/views/products.coin_earning.view.html',
            controller: 'editProductsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'products';
              $rootScope.parentBreadcrumb = 'product';
              $rootScope.breadcrumb       = 'Activity Coin Earning';
              $rootScope.leftMenu         = 'coin_earning';
            }
        })

        .state("products.rewards", {
            //url: '/dashboard/products/coin_earning/:productId',
            url: '/rewards/:productId',
            templateUrl: 'app/components/products/views/products.rewards.view.html',
            controller: 'editProductsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'products';
              $rootScope.parentBreadcrumb = 'product';
              $rootScope.breadcrumb       = 'Rewards';
              $rootScope.leftMenu         = 'rewards';
            }
        })

        .state("products.credit_rating_benefits", {
            //url: '/dashboard/products/credit_rating_benefits/:productId',
            url: '/credit_rating_benefits/:productId',
            templateUrl: 'app/components/products/views/products.credit_rating_benefits.view.html',
            controller: 'editProductsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'products';
              $rootScope.parentBreadcrumb = 'product';
              $rootScope.breadcrumb       = 'Credit Rating Benefits';
              $rootScope.leftMenu         = 'credit_rating_benefits';
            }
        })        


        .state("products.tier_benefits", {
            //url: '/dashboard/products/tier_benefits/:productId',
            url: '/tier_benefits/:productId',
            templateUrl: 'app/components/products/views/products.tier_benefits.view.html',
            controller: 'editProductsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'products';
              $rootScope.parentBreadcrumb = 'product';
              $rootScope.breadcrumb       = 'Tier Benefits';
              $rootScope.leftMenu         = 'tier_benefits';
            }
        })        

        //Degree module section
        .state("degree", {
            parent: 'dashboard',
            //url: '/dashboard/degree',
            url: '/degree',
            templateUrl: 'app/components/degree/views/degree.index.view.html'
        })

        .state("degree.list", {
            //url: '/dashboard/degree/list',
            url: '/list',
            templateUrl: 'app/components/degree/views/degree.list.view.html',
            controller: 'degreeController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'degree';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'degree';
              $rootScope.leftMenu         = 'list'; 
            }
        })

        .state("degree.add", {
            //url: '/dashboard/degree/add',
            url: '/add',
            templateUrl: 'app/components/degree/views/degree.add.view.html',
            controller: 'degreeController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'degree';
              $rootScope.parentBreadcrumb = 'degree';
              $rootScope.breadcrumb       = 'add degree';
              $rootScope.leftMenu         = 'add'; 
            }
        })

        .state("degree.edit", {
            //url: '/dashboard/degree/edit',
            url: '/edit/:degreeId',
            templateUrl: 'app/components/degree/views/degree.edit.view.html',
            controller: 'editDegreeController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'degree';
              $rootScope.parentBreadcrumb = 'degree';
              $rootScope.breadcrumb       = 'edit degree';
              $rootScope.leftMenu         = 'edit'; 
            }
        })

        //User module section
        .state("users", {
            parent: 'dashboard',
            //url: '/dashboard/users',
            url: '/users',
            templateUrl: 'app/components/users/views/users.index.view.html'
        })

        .state("users.list", {
            //url: '/dashboard/users/list',
            url: '/list',
            templateUrl: 'app/components/users/views/users.list.view.html',
            controller: 'userController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'users';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'users';
              $rootScope.leftMenu         = 'list'; 
            }
        })

        .state("users.basic", {
            //url: '/dashboard/users/basic',
            url: '/basic/:userId',
            templateUrl: 'app/components/users/views/users.basic.view.html',
            controller: 'userEditController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'users';
              $rootScope.parentBreadcrumb = 'users';
              $rootScope.breadcrumb       = 'basic info';
              $rootScope.leftMenu         = 'basic'; 
            }
        })

        .state("users.education", {
            //url: '/dashboard/users/education',
            url: '/education/:userId',
            templateUrl: 'app/components/users/views/users.education.view.html',
            controller: 'userEducationController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'users';
              $rootScope.parentBreadcrumb = 'users';
              $rootScope.breadcrumb       = 'education';
              $rootScope.leftMenu         = 'education'; 
            }
        })

        .state("users.education-edit", {
            //url: '/dashboard/users/education-edit',
            url: '/education-edit/:userId/:eduStatus/:educationId',
            templateUrl: 'app/components/users/views/users.education.edit.view.html',
            controller: 'userEducationController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'users';
              $rootScope.parentBreadcrumb = 'users';
              $rootScope.breadcrumb       = 'education';
              $rootScope.leftMenu         = 'education'; 
            }
        })

        .state("users.kyc", {
            //url: '/dashboard/users/kyc',
            url: '/kyc/:userId',
            templateUrl: 'app/components/users/views/users.kyc.view.html',
            controller: 'userKycController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'users';
              $rootScope.parentBreadcrumb = 'users';
              $rootScope.breadcrumb       = 'kyc';
              $rootScope.leftMenu         = 'kyc'; 
            }
        })

        .state("users.kyc-edit", {
            //url: '/dashboard/users/kyc-edit',
            url: '/kyc-edit/:userId/:kycStatus/:kycId',
            templateUrl: 'app/components/users/views/users.kyc.edit.view.html',
            controller: 'userKycController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'users';
              $rootScope.parentBreadcrumb = 'users';
              $rootScope.breadcrumb       = 'kyc';
              $rootScope.leftMenu         = 'kyc'; 
            }
        })

        .state("users.bank", {
            //url: '/dashboard/users/bank',
            url: '/bank/:userId',
            templateUrl: 'app/components/users/views/users.bank.view.html',
            controller: 'userBankController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'users';
              $rootScope.parentBreadcrumb = 'users';
              $rootScope.breadcrumb       = 'bank';
              $rootScope.leftMenu         = 'bank'; 
            }
        })

        .state("users.bank-edit", {
            //url: '/dashboard/users/bank-edit',
            url: '/bank-edit/:userId/:bankStatus/:bankId',
            templateUrl: 'app/components/users/views/users.bank.edit.view.html',
            controller: 'userBankController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'users';
              $rootScope.parentBreadcrumb = 'users';
              $rootScope.breadcrumb       = 'bank';
              $rootScope.leftMenu         = 'bank'; 
            }
        })

        .state("users.interest", {
            //url: '/dashboard/users/interest',
            url: '/interest/:userId',
            templateUrl: 'app/components/users/views/users.interest.view.html',
            controller: 'userInterestController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'users';
              $rootScope.parentBreadcrumb = 'users';
              $rootScope.breadcrumb       = 'interest adjustment';
              $rootScope.leftMenu         = 'interest'; 
            }
        })

        .state("users.friend-list", {
            //url: '/dashboard/users/friend-list',
            url: '/friend-list/:userId',
            templateUrl: 'app/components/users/views/users.friend-list.view.html',
            controller: 'userFriendsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'users';
              $rootScope.parentBreadcrumb = 'users';
              $rootScope.breadcrumb       = 'friend list';
              $rootScope.leftMenu         = 'list'; 
            }
        })



        //Bank module section
        .state("banks", {
            parent: 'dashboard',
            //url: '/dashboard/banks',
            url: '/banks',
            templateUrl: 'app/components/banks/views/banks.index.view.html'
        })

        .state("banks.list", {
            //parent: 'dashboard',
            //url: '/dashboard/banks/list',
            url: '/list',
            templateUrl: 'app/components/banks/views/banks.list.view.html',
            controller: 'banksController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'banks';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'Bank';
              $rootScope.leftMenu         = 'list';
            }
        })

        .state("banks.import", {
            //parent: 'dashboard',
            //url: '/dashboard/banks/import',
            url: '/import',
            templateUrl: 'app/components/banks/views/banks.import.view.html',
            controller: 'banksController',            
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'banks';
              $rootScope.parentBreadcrumb = 'Bank';
              $rootScope.breadcrumb       = 'import Bank';
              $rootScope.leftMenu         = 'import';              
            }
        })

        //bda Account module section
        .state("virtual-account", {
            parent: 'dashboard',
            //url: '/dashboard/virtual-account',
            url: '/virtual-account',
            templateUrl: 'app/components/virtual-account/views/virtual-account.index.view.html'
        })

        .state("virtual-account.list", {
            //parent: 'dashboard',
            //url: '/dashboard/virtual-account/list',
            url: '/list',
            templateUrl: 'app/components/virtual-account/views/virtual-account.list.view.html',
            controller: 'maccountController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'virtual-account';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'virtual Account';
              $rootScope.leftMenu         = 'list';
            }
        })

        .state("virtual-account.import", {
            //parent: 'dashboard',
            //url: '/dashboard/virtual-account/import',
            url: '/import',
            templateUrl: 'app/components/virtual-account/views/virtual-account.import.view.html',
            controller: 'maccountController',            
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'virtual-account';
              $rootScope.parentBreadcrumb = 'virtual Account';
              $rootScope.breadcrumb       = 'import virtual Account';
              $rootScope.leftMenu         = 'import';              
            }
        })

        //Degree Type module section
        .state("degreetype", {
            parent: 'dashboard',
            //url: '/dashboard/degreetype',
            url: '/degreetype',
            templateUrl: 'app/components/degreetype/views/degreetype.index.view.html'
        })

        .state("degreetype.list", {
            //url: '/dashboard/degreetype/list',
            url: '/list',
            templateUrl: 'app/components/degreetype/views/degreetype.list.view.html',
            controller: 'degreeTypeController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'degreetype';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'degree type';
              $rootScope.leftMenu         = 'list'; 
            }
        })

        .state("degreetype.add", {
            //url: '/dashboard/degreetype/add',
            url: '/add',
            templateUrl: 'app/components/degreetype/views/degreetype.add.view.html',
            controller: 'degreeTypeController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'degreetype';
              $rootScope.parentBreadcrumb = 'degree type';
              $rootScope.breadcrumb       = 'add degree type';
              $rootScope.leftMenu         = 'add'; 
            }
        })

        .state("degreetype.edit", {
            //url: '/dashboard/degreetype/edit',
            url: '/edit/:degreeTypeId',
            templateUrl: 'app/components/degreetype/views/degreetype.edit.view.html',
            controller: 'editDegreeTypeController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'degreetype';
              $rootScope.parentBreadcrumb = 'degree type';
              $rootScope.breadcrumb       = 'edit degree type';
              $rootScope.leftMenu         = 'edit'; 
            }
        })

        //Field of Study module section
        .state("studies", {
            parent: 'dashboard',
            //url: '/dashboard/studies',
            url: '/studies',
            templateUrl: 'app/components/studies/views/studies.index.view.html'
        })

        .state("studies.list", {
            //url: '/dashboard/studies/list',
            url: '/list',
            templateUrl: 'app/components/studies/views/studies.list.view.html',
            controller: 'studiesController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'studies';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'studies';
              $rootScope.leftMenu         = 'list'; 
            }
        })

        .state("studies.add", {
            //url: '/dashboard/studies/add',
            url: '/add',
            templateUrl: 'app/components/studies/views/studies.add.view.html',
            controller: 'studiesController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'studies';
              $rootScope.parentBreadcrumb = 'studies';
              $rootScope.breadcrumb       = 'add studies';
              $rootScope.leftMenu         = 'add'; 
            }
        })

        .state("studies.edit", {
            //url: '/dashboard/studies/edit',
            url: '/edit/:studyId',
            templateUrl: 'app/components/studies/views/studies.edit.view.html',
            controller: 'editStudiesController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'studies';
              $rootScope.parentBreadcrumb = 'studies';
              $rootScope.breadcrumb       = 'edit studies';
              $rootScope.leftMenu         = 'edit'; 
            }
        })

        //Pincode module section
        .state("college", {
            parent: 'dashboard',
           
            url: '/college',
            templateUrl: 'app/components/college/views/college.index.view.html'
        })

        .state("college.list", {
           
            url: '/list',
            templateUrl: 'app/components/college/views/college.list.view.html',
            controller: 'collegeController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'college';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'college';
              $rootScope.leftMenu         = 'list';
            }
        })

        .state("college.edit", {
            
            url: '/edit/:collegeId',
            templateUrl: 'app/components/college/views/college.edit.view.html',
            controller: 'editCollegeController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'college';
              $rootScope.parentBreadcrumb = 'college';
              $rootScope.breadcrumb       = 'edit college';
              $rootScope.leftMenu         = 'edit'; 
            }
        }) 


        //Pincode module section
        .state("pincode", {
            parent: 'dashboard',
            //url: '/dashboard/pincode',
            url: '/pincode',
            templateUrl: 'app/components/pincode/views/pincode.index.view.html'
        })

        .state("pincode.list", {
            //parent: 'dashboard',
            //url: '/dashboard/pincode/list',
            url: '/list',
            templateUrl: 'app/components/pincode/views/pincode.list.view.html',
            controller: 'pincodeController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'pincode';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'pincode';
              $rootScope.leftMenu         = 'list';
            }
        })

        .state("pincode.import", {
            //parent: 'dashboard',
            //url: '/dashboard/pincode/import',
            url: '/import',
            templateUrl: 'app/components/pincode/views/pincode.import.view.html',
            controller: 'pincodeController',            
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'pincode';
              $rootScope.parentBreadcrumb = 'pincode';
              $rootScope.breadcrumb       = 'import pincode';
              $rootScope.leftMenu         = 'import';              
            }
        })

        .state("pincode.edit", {
            url: '/edit/:pincodeId',
            templateUrl: 'app/components/pincode/views/pincode.edit.view.html',
            controller: 'editPincodeController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'pincode';
              $rootScope.parentBreadcrumb = 'pincode';
              $rootScope.breadcrumb       = 'edit pincode';
              $rootScope.leftMenu         = 'edit'; 
            }
        }) 

        //KYC module section
        .state("kyc", {
            parent: 'dashboard',
            //url: '/dashboard/kyc',
            url: '/kyc',
            templateUrl: 'app/components/kyc/views/kyc.index.view.html'
        })

        .state("kyc.list", {
            //url: '/dashboard/kyc/list',
            url: '/list',
            templateUrl: 'app/components/kyc/views/kyc.list.view.html',
            controller: 'kycController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'kyc';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'kyc';
              $rootScope.leftMenu         = 'list'; 
            }
        })

        .state("kyc.add", {
            //url: '/dashboard/kyc/add',
            url: '/add',
            templateUrl: 'app/components/kyc/views/kyc.add-edit.view.html',
            controller: 'editKYCController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'kyc';
              $rootScope.parentBreadcrumb = 'kyc';
              $rootScope.breadcrumb       = 'add kyc';
              $rootScope.leftMenu         = 'add'; 
            }
        })

        .state("kyc.edit", {
            //url: '/dashboard/kyc/edit',
            url: '/edit/:docType/:professionTypeId',
            templateUrl: 'app/components/kyc/views/kyc.add-edit.view.html',
            controller: 'editKYCController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'kyc';
              $rootScope.parentBreadcrumb = 'kyc';
              $rootScope.breadcrumb       = 'edit kyc';
              $rootScope.leftMenu         = 'edit'; 
            }
        })


        //KYC Document module section
        .state("kyc-document", {
            parent: 'dashboard',
            //url: '/dashboard/kyc-document',
            url: '/kyc-document',
            templateUrl: 'app/components/kyc-document/views/kyc-document.index.view.html'
        })

        .state("kyc-document.list", {
            //url: '/dashboard/kyc-document/list',
            url: '/list',
            templateUrl: 'app/components/kyc-document/views/kyc-document.list.view.html',
            controller: 'kyc-documentController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'kyc';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'kyc-document';
              $rootScope.leftMenu         = 'kyc-document-list'; 
            }
        })

        .state("kyc-document.add", {
            //url: '/dashboard/kyc-document/add',
            url: '/add',
            templateUrl: 'app/components/kyc-document/views/kyc-document.add.view.html',
            controller: 'kyc-documentController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'kyc';
              $rootScope.parentBreadcrumb = 'kyc-document';
              $rootScope.breadcrumb       = 'add kyc-document';
              $rootScope.leftMenu         = 'kyc-document-add'; 
            }
        })

        .state("kyc-document.edit", {
            //url: '/dashboard/kyc-document/edit',
            url: '/edit/:documentNameId',
            templateUrl: 'app/components/kyc-document/views/kyc-document.edit.view.html',
            controller: 'editKYC-DocumentController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'kyc';
              $rootScope.parentBreadcrumb = 'kyc-document';
              $rootScope.breadcrumb       = 'edit kyc-document';
              $rootScope.leftMenu         = 'kyc-document-edit'; 
            }
        })


        //Transaction module section
        .state("transactions", {
            parent: 'dashboard',
            //url: '/dashboard/transactions',
            url: '/transactions',
            templateUrl: 'app/components/transactions/views/transactions.index.view.html'
        })

        .state("transactions.list", {
            //parent: 'dashboard',
            //url: '/dashboard/transactions/list',
            url: '/list',
            templateUrl: 'app/components/transactions/views/transactions.list.view.html',
            controller: 'transactionsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'transactions';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'Mpokket Bank Transactions';
              $rootScope.leftMenu         = 'list';
            }
        })

        .state("transactions.import", {
            //parent: 'dashboard',
            //url: '/dashboard/transactions/import',
            url: '/import',
            templateUrl: 'app/components/transactions/views/transactions.import.view.html',
            controller: 'transactionsController',            
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'transactions';
              $rootScope.parentBreadcrumb = 'Mpokket Bank Transactions';
              $rootScope.breadcrumb       = 'import';
              $rootScope.leftMenu         = 'import';              
            }
        })

        .state("transactions.import-history", {
            //parent: 'dashboard',
            //url: '/dashboard/transactions/import-history',
            url: '/import-history',
            templateUrl: 'app/components/transactions/views/transactions.import-history.view.html',
            controller: 'transactionsController',            
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'transactions';
              $rootScope.parentBreadcrumb = 'Mpokket Bank Transactions';
              $rootScope.breadcrumb       = 'import';
              $rootScope.leftMenu         = 'import-history';              
            }
        })

        .state("transactions.export", {
            //parent: 'dashboard',
            //url: '/dashboard/transactions/export',
            url: '/export',
            templateUrl: 'app/components/transactions/views/transactions.export.view.html',
            controller: 'transactionsController',            
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'transactions';
              $rootScope.parentBreadcrumb = 'Mpokket Bank Transactions';
              $rootScope.breadcrumb       = 'export';
              $rootScope.leftMenu         = 'export';              
            }
        })

        .state("transactions.export-history", {
            //parent: 'dashboard',
            //url: '/dashboard/transactions/export-history',
            url: '/export-history',
            templateUrl: 'app/components/transactions/views/transactions.export-history.view.html',
            controller: 'transactionsController',            
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'transactions';
              $rootScope.parentBreadcrumb = 'Mpokket Bank Transactions';
              $rootScope.breadcrumb       = 'export';
              $rootScope.leftMenu         = 'export-history';              
            }
        })

         .state("transactions.export-download", {
            //parent: 'dashboard',
            //url: '/dashboard/transactions/export-history',
            url: '/export-download',
            templateUrl: 'app/components/transactions/views/transactions.export-download.view.html',
            controller: 'viewExportDownloadController',            
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'transactions';
              $rootScope.parentBreadcrumb = 'Mpokket Bank Transactions';
              $rootScope.breadcrumb       = 'export';
              $rootScope.leftMenu         = 'export-download';              
            }
        })

         //Cash Request module section
        .state("cash-request", {
            parent: 'dashboard',
            //url: '/dashboard/cash-request',
            url: '/cash-request',
            templateUrl: 'app/components/cash-request/views/cash-request.index.view.html'
        })

        .state("cash-request.list", {
            //parent: 'dashboard',
            //url: '/dashboard/cash-request/list',
            url: '/list',
            templateUrl: 'app/components/cash-request/views/cash-request.list.view.html',
            controller: 'cash-requestController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'cash-request';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'cash request';
              $rootScope.leftMenu         = 'list';
            }
        })

        //Configuration module section
        .state("configuration", {
            parent: 'dashboard',
            //url: '/dashboard/configuration',
            url: '/configuration',
            templateUrl: 'app/components/configuration/views/configuration.index.view.html'
        })

        .state("configuration.basic", {
            //parent: 'dashboard',
            //url: '/dashboard/configuration/basic',
            url: '/basic',
            templateUrl: 'app/components/configuration/views/configuration.basic.view.html',
            controller: 'configurationController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'configuration';
              $rootScope.parentBreadcrumb = 'configuration';
              $rootScope.breadcrumb       = 'basic';
              $rootScope.leftMenu         = 'basic';
            }
        })

        .state("configuration.mcoins", {
            //parent: 'dashboard',
            //url: '/dashboard/configuration/mcoins',
            url: '/mcoins',
            templateUrl: 'app/components/configuration/views/configuration.mcoins.view.html',
            controller: 'configurationController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'configuration';
              $rootScope.parentBreadcrumb = 'configuration';
              $rootScope.breadcrumb       = 'mcoins';
              $rootScope.leftMenu         = 'mcoins';
            }
        })

        .state("configuration.rewards", {
            //parent: 'dashboard',
            //url: '/dashboard/configuration/rewards',
            url: '/rewards',
            templateUrl: 'app/components/configuration/views/configuration.rewards.view.html',
            controller: 'configurationController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'configuration';
              $rootScope.parentBreadcrumb = 'configuration';
              $rootScope.breadcrumb       = 'rewards';
              $rootScope.leftMenu         = 'rewards';
            }
        })

        .state("configuration.tier-user-level", {
            //parent: 'dashboard',
            //url: '/dashboard/configuration/tier-user-level',
            url: '/tier-user-level',
            templateUrl: 'app/components/configuration/views/configuration.tier.user.level.view.html',
            controller: 'configurationController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'configuration';
              $rootScope.parentBreadcrumb = 'configuration';
              $rootScope.breadcrumb       = 'tier user level';
              $rootScope.leftMenu         = 'tier-user-level';
            }
        })

       .state("configuration.creditlimit", {
            //parent: 'dashboard',
            //url: '/dashboard/configuration/basic',
            url: '/creditlimit',
            templateUrl: 'app/components/configuration/views/configuration.creditlimit.view.html',
            controller: 'configurationController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'configuration';
              $rootScope.parentBreadcrumb = 'configuration';
              $rootScope.breadcrumb       = 'credit limit';
              $rootScope.leftMenu         = 'credit limit';
            }
        })

       .state("configuration.creditscore", {
            //parent: 'dashboard',
            //url: '/dashboard/configuration/basic',
            url: '/creditscore',
            templateUrl: 'app/components/configuration/views/configuration.creditscore.view.html',
            controller: 'configurationController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'configuration';
              $rootScope.parentBreadcrumb = 'configuration';
              $rootScope.breadcrumb       = 'credit score';
              $rootScope.leftMenu         = 'credit score';
            }
        })




        //Conversations module section
        .state("conversations", {
            parent: 'dashboard',
            //url: '/dashboard/conversations',
            url: '/conversations',
            templateUrl: 'app/components/conversations/views/conversations.index.view.html'
        })

        .state("conversations.list", {
            //parent: 'dashboard',
            //url: '/dashboard/conversations/list',
            url: '/list',
            templateUrl: 'app/components/conversations/views/conversations.list.view.html',
            controller: 'conversationsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'conversations';
              $rootScope.parentBreadcrumb = 'conversations';
              $rootScope.breadcrumb       = 'list';
              $rootScope.leftMenu         = 'list';
            }
        })

        .state("conversations.details", {
            //parent: 'dashboard',
            //url: '/dashboard/conversations/details/ticketId',
            url: '/details/:ticketId',
            templateUrl: 'app/components/conversations/views/conversations.details.view.html',
            controller: 'detailsConversationsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'conversations';
              $rootScope.parentBreadcrumb = 'conversations';
              $rootScope.breadcrumb       = 'details';
              $rootScope.leftMenu         = 'details';
            }
        })


        //Data Collections module section
        .state("data-collections", {
            parent: 'dashboard',
            //url: '/dashboard/data-collections',
            url: '/data-collections',
            templateUrl: 'app/components/data-collections/views/data-collections.index.view.html'
        })

        .state("data-collections.list", {
            //parent: 'dashboard',
            //url: '/dashboard/data-collections/list',
            url: '/list',
            templateUrl: 'app/components/data-collections/views/data-collections.list.view.html',
            controller: 'dataCollectionsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'data-collections';
              $rootScope.parentBreadcrumb = 'data collections';
              $rootScope.breadcrumb       = 'list';
              $rootScope.leftMenu         = 'list';
            }
        })


        //Admin-User module section
        .state("admin-users", {
            parent: 'dashboard',
            //url: '/dashboard/admin-users',
            url: '/admin-users',
            templateUrl: 'app/components/admin-users/views/admin-users.index.view.html'
        })

        .state("admin-users.list", {
            //url: '/dashboard/admin-users/list',
            url: '/list',
            templateUrl: 'app/components/admin-users/views/admin-users.list.view.html',
            controller: 'adminUserController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'admin-users';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'admin users';
              $rootScope.leftMenu         = 'list'; 
            }
        })

        .state("admin-users.add", {
            //url: '/dashboard/admin-users/add',
            url: '/add',
            templateUrl: 'app/components/admin-users/views/admin-users.add.view.html',
            controller: 'adminUserController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'admin-users';
              $rootScope.parentBreadcrumb = 'admin users';
              $rootScope.breadcrumb       = 'ADD admin users';
              $rootScope.leftMenu         = 'add'; 
            }
        })

        //Agent-Users module section
        .state("agent-users", {
            parent: 'dashboard',
            //url: '/dashboard/agent-users',
            url: '/agent-users',
            templateUrl: 'app/components/agent-users/views/agent-users.index.view.html'
        })

        .state("agent-users.list", {
            //url: '/dashboard/agent-users/list',
            url: '/list',
            templateUrl: 'app/components/agent-users/views/agent-users.list.view.html',
            controller: 'agentUserController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'agent-users';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'agent users';
              $rootScope.leftMenu         = 'list'; 
            }
        })

        .state("agent-users.reference-list", {
            //url: '/dashboard/agent-users/reference-list/refUserId',
            url: '/reference-list/:refUserId',
            templateUrl: 'app/components/agent-users/views/agent-users.reference-list.view.html',
            controller: 'refAgentUserController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'agent-users';
              $rootScope.parentBreadcrumb = 'agent users';
              $rootScope.breadcrumb       = 'reference list';
              $rootScope.leftMenu         = 'reference-list'; 
            }
        })



        //reports module section
        .state("reports", {
            parent: 'dashboard',
            //url: '/dashboard/reports',
            url: '/reports',
            templateUrl: 'app/components/reports/views/reports.index.view.html'
        })

        .state("reports.list", {
            //url: '/dashboard/reports/list',
            url: '/list',
            templateUrl: 'app/components/reports/views/reports.list.view.html',
            controller: 'reportsController',
            onEnter: function($state,$rootScope){
              $rootScope.carousel         = 'reports';
              $rootScope.parentBreadcrumb = '';
              $rootScope.breadcrumb       = 'report';
              $rootScope.leftMenu         = 'list'; 
            }
        })

        //$locationProvider.html5Mode(true);
}]);