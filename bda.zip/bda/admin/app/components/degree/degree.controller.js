angular
	.module('bda')
	.controller('degreeController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope)
	{

		$scope.degreeData 			= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'id';
	    $scope.order 				= 'desc';
	    $scope.searchByName 		= '';
		
		// Perform to getAllDegree action
		$scope.getAllDegree = function(pageno, order_by, order)
		{ 
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : 'id';
	        $scope.order 	= order ? order : 'desc';

	        var getDegreeParam = 
	        {
	        	'pass_key' 			: $cookies.get('pass_key'),
	        	'admin_user_id'		: $cookies.get('admin_user_id'),
	            'searchByName'		: $scope.searchByName,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage
	        };
			ajaxService.ApiCall(getDegreeParam, CONFIG.ApiUrl+'degree/getAllDegree', $scope.getAllDegreeSuccess, $scope.getAllDegreeError, 'post');
		}

		//getAllDegree success function
		$scope.getAllDegreeSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.allDegree 	= result.raws.data.dataset;
                $scope.total_count 	= result.raws.data.count;	        
		    }		       
		}

		//getAllDegree error function
		$scope.getAllDegreeError = function(result) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

		/****************Search START******************/
		$scope.$watch('searchByName', function(tmpStr) 
		{
		    if (angular.isUndefined(tmpStr))
		    {		    	
		        return 0;
		    }
		    else if(tmpStr=='')
		    {
				$scope.getAllDegree($scope.pageno, $scope.order_by, $scope.order, $scope.searchByName);
		    }
		    else
		    {
		    	$timeout(function() 
		    	{ 
			        if (tmpStr === $scope.searchByName) 
			        {
						$scope.getAllDegree($scope.pageno, $scope.order_by, $scope.order, $scope.searchByName);
			        }
			    }, 1000);	
		    }		    
		});
		/**************** Search END ******************/
		
		// Perform the addDegree action
		$scope.doaddDegree = function(degreeData) 
		{ 
			ajaxService.ApiCall(degreeData, CONFIG.ApiUrl+'degree/addDegree', $scope.addDegreeSuccess, $scope.addDegreeError, 'post');
		}

		//addDegree success function
		$scope.addDegreeSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
		    	$scope.successMessage = result.raws.success_message;
		    	$scope.clearMessage();
		    	$timeout(function() {
		        	$location.path('dashboard/degree/list');
		        }, CONFIG.TimeOut);
		    }		       
		}

		//addDegree error function
		$scope.addDegreeError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}

		$scope.clearMessage = function()
		{
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}

	}])

	.controller('editDegreeController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams',"$uibModal", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams,$uibModal)
	{
		//var epc = this;
		$scope.degreeDetail 	= {};
		$scope.degreeId 		= $stateParams.degreeId;
		$scope.successMessage 	= '';
        $scope.errorMessage 	= '';

		// Perform to getDegreeDetail action
		$scope.getDegreeDetail = function()
		{ 
			var degreeParam = {'degreeId' : $scope.degreeId};
			ajaxService.ApiCall(degreeParam, CONFIG.ApiUrl+'degree/getDegreeDetail', $scope.getDegreeDetailSuccess, $scope.getDegreeDetailError, 'post');
		}

		//getDegreeDetail success function
		$scope.getDegreeDetailSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.degreeDetail = result.raws.data.dataset;
		    }
		}

		//getDegreeDetail error function
		$scope.getDegreeDetailError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}

		if($state.$current.name == 'degree.edit')
		{
			$scope.getDegreeDetail();
		}

		// Perform to updateDegreeDetail action
		$scope.updateDegreeDetail = function(degreeDetail)
		{
			
			ajaxService.ApiCall(degreeDetail, CONFIG.ApiUrl+'degree/updateDegreeDetail', $scope.updateDegreeDetailSuccess, $scope.updateDegreeDetailError, 'post');
		}

		//updateDegreeDetail success function
		$scope.updateDegreeDetailSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
		        	$location.path('dashboard/degree/list');
		        }, CONFIG.TimeOut);
		    }
		}

		//updateDegreeDetail error function
		$scope.updateDegreeDetailError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}
		
		$scope.clearMessage = function()
		{
			$timeout(function() 
			{
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}


		$scope.doMergePopup = function(degree_id){
			
			$rootScope.degree_id 		= degree_id ? degree_id : '';
			
			$uibModal.open({
				animation: true,
				templateUrl: 'app/components/degree/views/degree.modal.details.view.html',
				controllerAs : 'dmc',
				controller: 'degreeMergeController',
				bindToController : true
			});
		}

	}])
.controller('degreeMergeController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "$uibModalInstance","helper", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, $uibModalInstance, helper, $rootScope){
		var dmc = this;
		dmc.successMessage 	= '';
		dmc.errorMessage 	= '';

		dmc.cancel = function(){
			$uibModalInstance.dismiss('cancel');
			//$state.reload();
		}

		$scope.getDegreePoPDetail = function()
		{ 
			var degreeParam = {'degreeId' : $rootScope.degree_id};
			ajaxService.ApiCall(degreeParam, CONFIG.ApiUrl+'degree/getDegreeDetail', $scope.getDegreeDetailPopSuccess, $scope.getDegreePopDetailError, 'post');
		}
		//collegeDetail success function
		$scope.getDegreeDetailPopSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
		    	//console.log(result.raws.data.dataset);
                $scope.degreePopDetail = result.raws.data.dataset;
              
		    }
		}

		//collegeDetail error function
		$scope.getDegreePopDetailError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}
		if($state.$current.name == 'degree.edit')
		{
			$scope.getDegreePoPDetail();
		} 
		//console.log($rootScope.college_id); 

		$scope.searchauto = function(a)
		{
			var degreeParam = {'degree' : a};
			ajaxService.ApiCall(degreeParam, CONFIG.ApiUrl+'degree/getDegreeSearch', $scope.getCollegeSearchSuccess, $scope.getCollegeSearchError, 'post');
		
		}

		$scope.getCollegeSearchSuccess = function(result,status) 
		{
		    if(status == 200) 
		    { 
		    	//console.log(result.raws.data.dataset);
                $scope.degreeSearchDetail = result.raws.data.dataset;
                $scope.degreeSearchCount = result.raws.data.total_count;
              
		    }
		}

		//collegeDetail error function
		$scope.getCollegeSearchError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}
		if($state.$current.name == 'college.edit')
		{
			$scope.getCollegePoPDetail();
		} 
		//$scope.degreeMerge = {};

		$scope.selectDegree = function(degreeName)
		{
			$scope.degreePopDetail.mergeDegree=degreeName;
			$scope.degreeSearchCount = 0;
		}

		// Update College Merge Details------------Do FROM HERE
		$scope.updateMergeDetail = function(degreePopDetail)
		{	
			//console.log(degreePopDetail);
			var degreeDetailsId = {};
			degreeDetailsId.degree_id = $rootScope.degree_id;
			degreeDetailsId.degree_name = degreePopDetail.mergeDegree;
			ajaxService.ApiCall(degreeDetailsId, CONFIG.ApiUrl+'degree/updateDegreeDetailMerge', $scope.updateDegreeMergeDetailSuccess, $scope.updateDegreeMergeDetailError, 'post');
		}
		//updateDegreeDetail success function
		$scope.updateDegreeMergeDetailSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                dmc.cancel();
                $timeout(function() {
		        	$location.path('dashboard/degree/list');
		        }, CONFIG.TimeOut);
		    }
		}

		//updateDegreeDetail error function
		$scope.updateDegreeMergeDetailError = function(result)
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}
		
		$scope.clearMessage = function()
		{
			$timeout(function() 
			{
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		} 
		
	  ///---------------------------	
		return dmc;
	}]);