angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : degreeTypeListLeftMenu()
    * @ Added Date               : 08-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : degree type list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 08-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('degreeTypeListLeftMenu', function() {
        return {
            controllerAs : 'pllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var pllm = this;
                return pllm;
            },
            templateUrl: 'app/components/degreetype/views/degreetype.list.left.menu.html'
        };
    })
    