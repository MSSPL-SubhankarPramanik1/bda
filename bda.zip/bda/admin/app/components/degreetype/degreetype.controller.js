angular
	.module('bda')
	.controller('degreeTypeController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, blockUI)
	{

		$scope.degreeData 			= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'id';
	    $scope.order 				= 'desc';
	    $scope.searchByType 		= '';
		
		// Perform to getAllDegreeType action
		$scope.getAllDegreeType = function(pageno, order_by, order)
		{
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : 'id';
	        $scope.order 	= order ? order : 'desc';

	        var getDegreeParam = 
	        {
	        	'pass_key' 			: $cookies.get('pass_key'),
	        	'admin_user_id'		: $cookies.get('admin_user_id'),
	            'searchByType'		: $scope.searchByType,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage
	        };
			ajaxService.ApiCall(getDegreeParam, CONFIG.ApiUrl+'degree_type/getAllDegreeType', $scope.getAllDegreeTypeSuccess, $scope.getAllDegreeTypeError, 'post');
		}

		//getAllDegreeType success function
		$scope.getAllDegreeTypeSuccess = function(result, status) 
		{
		    if(status == 200) 
		    {
                $scope.allDegreeTypes 	= result.raws.data.dataset;
                $scope.total_count 	= result.raws.data.count;
                blockUI.stop();
		    }		       
		}

		//getAllDegreeType error function
		$scope.getAllDegreeTypeError = function(result, status) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		/****************Search START******************/
		$scope.$watch('searchByType', function(tmpStr) 
		{
		    if (angular.isUndefined(tmpStr))
		    {		    	
		        return 0;
		    }
		    else if(tmpStr=='')
		    {
				$scope.getAllDegreeType($scope.pageno,$scope.order_by,$scope.order,$scope.searchByType);
		    }
		    else
		    {
		    	$timeout(function() 
		    	{ 
			        if (tmpStr === $scope.searchByType) 
			        {
						$scope.getAllDegreeType($scope.pageno, $scope.order_by, $scope.order, $scope.searchByType);
			        }
			    }, 1000);	
		    }		    
		});
		/**************** Search END ******************/
		
		// Perform the addDegreeType action
		$scope.doaddDegreeType = function(degreeData) 
		{
			degreeData.pass_key 		= $cookies.get('pass_key');
        	degreeData.admin_user_id 	= $cookies.get('admin_user_id');
			ajaxService.ApiCall(degreeData, CONFIG.ApiUrl+'degree_type/addDegreeType', $scope.addDegreeTypeSuccess, $scope.addDegreeTypeError, 'post');
		}

		//addDegreeType success function
		$scope.addDegreeTypeSuccess = function(result, status) 
		{
		    if(status == 200) 
		    {
		    	$scope.successMessage = result.raws.success_message;
		    	$scope.clearMessage();
		    	$timeout(function() {
		        	$location.path('dashboard/degreetype/list');
		        }, CONFIG.TimeOut);
		    }		       
		}

		//addDegreeType error function
		$scope.addDegreeTypeError = function(result, status) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

		$scope.clearMessage = function()
		{
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])

	.controller('editDegreeTypeController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', 'blockUI', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, blockUI)
	{
		//var epc = this;
		$scope.degreeDetail 	= {};
		$scope.degreeId 		= $stateParams.degreeTypeId;
		$scope.successMessage 	= '';
        $scope.errorMessage 	= '';

		// Perform to getDegreeTypeDetail action
		$scope.getDegreeTypeDetail = function()
		{
			blockUI.start();
			var degreeParam = {
				'degreeId' 		: $scope.degreeId,
				'pass_key' 		: $cookies.get('pass_key'),
				'admin_user_id' : $cookies.get('admin_user_id')
			};
			ajaxService.ApiCall(degreeParam, CONFIG.ApiUrl+'degree_type/getDegreeTypeDetail', $scope.getDegreeTypeDetailSuccess, $scope.getDegreeTypeDetailError, 'post');
		}

		//getDegreeTypeDetail success function
		$scope.getDegreeTypeDetailSuccess = function(result, status) 
		{
		    if(status == 200) 
		    {
                $scope.degreeDetail = result.raws.data.dataset;
                //console.log($scope.degreeDetail);
                blockUI.stop();
		    }
		}

		//getDegreeTypeDetail error function
		$scope.getDegreeTypeDetailError = function(result, status) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if($state.$current.name == 'degreetype.edit')
		{
			$scope.getDegreeTypeDetail();
		}

		// Perform to updateDegreeTypeDetail action
		$scope.updateDegreeTypeDetail = function(degreeDetail)
		{
			degreeDetail.pass_key 		= $cookies.get('pass_key');
        	degreeDetail.admin_user_id 	= $cookies.get('admin_user_id');
			ajaxService.ApiCall(degreeDetail, CONFIG.ApiUrl+'degree_type/updateDegreeTypeDetail', $scope.updateDegreeTypeDetailSuccess, $scope.updateDegreeTypeDetailError, 'post');
		}

		//updateDegreeTypeDetail success function
		$scope.updateDegreeTypeDetailSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
		        	$location.path('dashboard/degreetype/list');
		        }, CONFIG.TimeOut);
		    }
		}

		//updateDegreeTypeDetail error function
		$scope.updateDegreeTypeDetailError = function(result, status) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}
		
		$scope.clearMessage = function()
		{
			$timeout(function() 
			{
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])