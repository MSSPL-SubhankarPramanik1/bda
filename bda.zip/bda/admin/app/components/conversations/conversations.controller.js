angular
	.module('bda')
	.controller('conversationsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, blockUI){

	    $scope.pageno 					= 1; // initialize page no to 1
	    $scope.itemsPerPage 			= CONFIG.itemsPerPage; 
	    $scope.order_by 				= 'id';
	    $scope.order 					= 'desc';
	    $scope.filterByStatus			= '';
	    $scope.searchByTitle 			= '';
	    $scope.allConversations 		= {};
		
		// Perform to getAllConversations action
		$scope.getAllConversations = function(pageno, order_by, order){
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : 'id';
	        $scope.order 	= order ? order : 'desc';

	        var getKYCParam ={
	        	'pass_key' 				: $cookies.get('pass_key'),
	        	'admin_user_id'			: $cookies.get('admin_user_id'),
	            'filterByStatus'		: $scope.filterByStatus,
	            'searchByTitle'			: $scope.searchByTitle,
	            'order_by'				: $scope.order_by,
	            'order'					: $scope.order,
	            'page'					: $scope.pageno,
	            'page_size'				: $scope.itemsPerPage
	        };
			ajaxService.ApiCall(getKYCParam, CONFIG.ApiUrl+'conversations/getAllConversations', $scope.getAllConversationsSuccess, $scope.getAllConversationsError, 'post');
		}

		//getAllConversations success function
		$scope.getAllConversationsSuccess = function(result, status){
		    if(status == 200){
                $scope.allConversations 	= result.raws.data.dataset;
                $scope.total_count 			= result.raws.data.count;
                blockUI.stop();
		    }		       
		}

		//getAllConversations error function
		$scope.getAllConversationsError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}
		
		// Call to getAllConversations
		if($state.$current.name == 'conversations.list'){
			$scope.$watch('searchByTitle', function(tmpStr) {
			    if (angular.isUndefined(tmpStr)){		    	
			        return 0;
			    }else if(tmpStr==''){
					$scope.getAllConversations($scope.pageno, $scope.order_by, $scope.order, $scope.searchByTitle);
			    }else{
			    	$timeout(function() { 
				        if (tmpStr === $scope.searchByTitle) {
							$scope.getAllConversations($scope.pageno, $scope.order_by, $scope.order, $scope.searchByTitle);
				        }
				    }, 1000);	
			    }		    
			});
		}

		$scope.clearMessage = function(){
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])

	.controller('detailsConversationsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', 'blockUI', '$anchorScroll', '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, blockUI, $anchorScroll, $window){
		//var epc = this;
		$scope.getConversationDetails 	= {};
		$scope.successMessage 			= '';
        $scope.errorMessage 			= '';

		$scope.ticketId 				= ($stateParams.ticketId === undefined) ? '' : $stateParams.ticketId;
		$scope.conversationThreads 		= {};

		// Perform to getConversationDetails action
		$scope.getConversationDetails = function(){
			blockUI.start();
			var getConversationDetailsParam = {
				'ticketId' 			: $scope.ticketId,
				'pass_key' 			: $cookies.get('pass_key'),
				'admin_user_id' 	: $cookies.get('admin_user_id')
			};
			ajaxService.ApiCall(getConversationDetailsParam, CONFIG.ApiUrl+'conversations/getConversationDetails', $scope.getConversationDetailsSuccess, $scope.getConversationDetailsError, 'post');
		}

		//getConversationDetails success function
		$scope.getConversationDetailsSuccess = function(result, status){
		    if(status == 200){
                $scope.getConversationDetails  	= result.raws.data;
				$scope.conversationThreads.id 	= $scope.getConversationDetails.id; 
                blockUI.stop();
		    }
		}

		//getConversationDetails error function
		$scope.getConversationDetailsError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if($state.$current.name == 'conversations.details'){
			$scope.getConversationDetails();
		}


		// Perform to doupdateConversation action
		$scope.doupdateConversation = function(getConversationDetails){

        	var getConversationDetailsParam = {	
        		'ticketId'		: getConversationDetails.id,		
        		'status'		: getConversationDetails.status,		
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
			ajaxService.ApiCall(getConversationDetailsParam, CONFIG.ApiUrl+'conversations/updateConversation', $scope.updateConversationSuccess, $scope.updateConversationError, 'post');
		}

		//updateConversation success function
		$scope.updateConversationSuccess = function(result,status){
		    if(status == 200){
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
		    }
		}

		//updateConversation error function
		$scope.updateConversationError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}



		// Perform the doaddConversationThreads action
		$scope.doaddConversationThreads = function(conversationThreads) { 

			var conversationThreadsParam = {			
		        'ticketId'			: conversationThreads.id,
		        'description'		: conversationThreads.description,
		        'fk_user_id'		: $scope.getConversationDetails.fk_user_id,
		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id' 	: $cookies.get('admin_user_id')
	        }

			ajaxService.ApiCall(conversationThreadsParam, CONFIG.ApiUrl+'conversations/addConversationThreads', $scope.addConversationThreadsSuccess, $scope.addConversationThreadsError, 'post');
		}


		$scope.addConversationThreadsSuccess = function(result,status) {
		    if(status == 200) {
		    	//$scope.successMessage = result.raws.success_message;				
				$scope.getConversationDetails.all_conversation_threads.push({ 
	                'id' 					: result.raws.data.id,
		        	'fk_support_ticket_id' 	: result.raws.data.fk_support_ticket_id,
		        	'fk_user_id' 			: result.raws.data.fk_user_id,
		        	'fk_admin_id' 			: result.raws.data.fk_admin_id,
		        	'description' 			: result.raws.data.description,
		        	'added_timestamp' 		: result.raws.data.added_timestamp,
		        	'is_unread' 			: result.raws.data.is_unread,
	            });

	           	$scope.clearMessage();
	           	$location.hash('bottom');

	           	$scope.conversationThreads.description = '';
		    }		       
		}
		$scope.addConversationThreadsError = function(result, status) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}









		//*********cancel button Functions** 
		$scope.goBack = function() { 
			$window.history.back();
		};

		
		$scope.clearMessage = function(){
			$timeout(function(){
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])