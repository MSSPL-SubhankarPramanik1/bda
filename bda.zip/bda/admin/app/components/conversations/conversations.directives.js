angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : conversationsListLeftMenu()
    * @ Added Date               : 08-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : degree type list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 08-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('conversationsListLeftMenu', function() {
        return {
            controllerAs : 'cllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var cllm = this;
                return cllm;
            },
            templateUrl: 'app/components/conversations/views/conversations.list.left.menu.html'
        };
    })
    