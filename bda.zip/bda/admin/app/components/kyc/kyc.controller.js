angular
	.module('bda')
	.controller('kycController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, blockUI){

	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'id';
	    $scope.order 				= 'desc';
	    $scope.searchByDocymentType = '';
	    $scope.kycData 				= {};
		
		// Perform to getAllKYC action
		$scope.getAllKYC = function(pageno, order_by, order){
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : 'id';
	        $scope.order 	= order ? order : 'desc';

	        var getKYCParam ={
	        	'pass_key' 				: $cookies.get('pass_key'),
	        	'admin_user_id'			: $cookies.get('admin_user_id'),
	            'searchByDocymentType'	: $scope.searchByDocymentType,
	            'order_by'				: $scope.order_by,
	            'order'					: $scope.order,
	            'page'					: $scope.pageno,
	            'page_size'				: $scope.itemsPerPage
	        };
			ajaxService.ApiCall(getKYCParam, CONFIG.ApiUrl+'kyc/getAllKYC', $scope.getAllKYCSuccess, $scope.getAllKYCError, 'post');
		}

		//getAllKYC success function
		$scope.getAllKYCSuccess = function(result, status){
		    if(status == 200){
                $scope.allKYCTemplate 	= result.raws.data.dataset;
                $scope.addressProof 	= Object.keys($scope.allKYCTemplate.A).length;
                $scope.financeProof 	= Object.keys($scope.allKYCTemplate.F).length;
                $scope.identityProof 	= Object.keys($scope.allKYCTemplate.I).length;
                $scope.dobProof 		= Object.keys($scope.allKYCTemplate.D).length;
                //$scope.total_count 	= result.raws.data.count;
                blockUI.stop();
		    }		       
		}

		//getAllKYC error function
		$scope.getAllKYCError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}
		
		// Call to getAllProduct
		if($state.$current.name == 'kyc.list'){
			$scope.getAllKYC();
		}

		$scope.clearMessage = function(){
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])

	.controller('editKYCController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', 'blockUI', '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, blockUI, $window){
		//var epc = this;
		$scope.kycData 			= {};
		$scope.successMessage 	= '';
        $scope.errorMessage 	= '';

		$scope.docType 			= ($stateParams.docType === undefined) ? '' : $stateParams.docType;
		$scope.professionTypeId = ($stateParams.professionTypeId === undefined) ? '' : $stateParams.professionTypeId;


		// Perform to getKYCData action
		$scope.getKYCData = function(){
			blockUI.start();
			var kycDataParam = {
				'docType' 			: $scope.docType,
				'professionTypeId' 	: $scope.professionTypeId,
				'pass_key' 			: $cookies.get('pass_key'),
				'admin_user_id' 	: $cookies.get('admin_user_id')
			};
			ajaxService.ApiCall(kycDataParam, CONFIG.ApiUrl+'kyc/getKYCData', $scope.getKYCDataSuccess, $scope.getKYCDataError, 'post');
		}

		//getKYCData success function
		$scope.getKYCDataSuccess = function(result, status){
		    if(status == 200){
                $scope.kycData 			= result.raws.data.dataset;
                $scope.allProfession 	= result.raws.data.allProfession;
                $scope.allKYCDocument 	= result.raws.data.allKYCDocument;
                if($scope.kycData.B.length == 0){
                	$scope.addNewRow('B');
                }
                if($scope.kycData.L.length == 0){
                	$scope.addNewRow('L');
                }
                if($scope.kycData.A.length == 0){
                	$scope.addNewRow('A');
                }
                $scope.editMode 		= ($scope.docType != '') ? 'edit' : 'add';
                //console.log($scope.kycData);
                blockUI.stop();
		    }
		}

		//getKYCData error function
		$scope.getKYCDataError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if(($state.$current.name == 'kyc.add') || ($state.$current.name == 'kyc.edit')){
			$scope.getKYCData();
		}

		// Perform to doupdateKYCDetail action
		$scope.doeditKYCDetail = function(kycData){
			//console.log(kycData);
 			var jsonString = JSON.stringify(kycData);
			kycData.kycData_str = jsonString;
        	var kycDataParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }

	        angular.extend(kycDataParam, kycData);       	
			ajaxService.ApiCall(kycDataParam, CONFIG.ApiUrl+'kyc/editKYCDetail', $scope.editKYCDetailSuccess, $scope.editKYCDetailError, 'post');
		}

		//editKYCDetail success function
		$scope.editKYCDetailSuccess = function(result,status){
		    if(status == 200){
		    	$window.scrollTo(0, 100);
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
		        	$location.path('dashboard/kyc/list');
		        }, CONFIG.TimeOut);
		    }
		}

		//editKYCDetail error function
		$scope.editKYCDetailError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

		$scope.addNewRow = function(user_mode){
			$scope.kycData[user_mode].push({ 
                'id' :"",
				'fk_document_id' : "",
				'fk_profession_type_id' : "",
				'user_mode' : user_mode,
				'document_type' : "",
				'priority_level' : "A"
            });
            //console.log($scope.kycData);
		}

		$scope.removeRow = function(user_mode, index){
			$scope.kycData[user_mode].splice(index, 1);
			//console.log($scope.kycData[user_mode]);
		}
		
		$scope.clearMessage = function(){
			$timeout(function(){
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])