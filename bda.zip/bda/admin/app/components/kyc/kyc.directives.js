angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : kycListLeftMenu()
    * @ Added Date               : 08-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : degree type list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 08-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('kycListLeftMenu', function() {
        return {
            controllerAs : 'kllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var kllm = this;
                return kllm;
            },
            templateUrl: 'app/components/kyc/views/kyc.list.left.menu.html'
        };
    })
    