angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : transactionsLeftMenu()
    * @ Added Date               : 14-04-2016
    * @ Added By                 : Subhankar
    * -----------------------------------------------------------------
    * @ Description              : admin left side menu is managed from here
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 14-04-2016
    * @ Modified By              : Subhankar
    * 
    */
    .directive('transactionsLeftMenu', function() {
        return {
            controllerAs : 'tlm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var tlm = this;
                return tlm;
            },
            templateUrl: 'app/components/transactions/views/transactions.list.left.menu.html'
        };
    })


    .directive('userInfoMain', function () {
        return function(scope, element, attrs) {
            element.hover(function(e) {
                //console.log('SD');
                // userinfo details
                var x = $(this).position();
                var $userinfodetails = $(this).next(".user-info-main");
                var $toppo = x.top - 14;
                var $leftpo = x.left + 35;
                $userinfodetails.css({
                    display: "block",
                    top: $toppo,
                    left: $leftpo
                })
                e.stopPropagation();
                e.preventDefault();
            },
            function() {
                var $userinfodetails = $(this).next(".user-info-main");
                $userinfodetails.css({
                    display: "none"
                })
            });
        }
    });


