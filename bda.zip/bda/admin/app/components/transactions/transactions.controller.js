angular
	.module('bda')
	.controller('transactionsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "$uibModal", "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, $uibModal, helper, $rootScope, blockUI){
		$scope.successMessage 		= '';
		$scope.errorMessage 		= '';
	    $scope.filterByTransferType	= '';
	    $scope.searchByACNoName 	= '';
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage;			
	    $scope.order_by 			= 'transaction_date';
	    $scope.order 				= 'desc';
	    $scope.allTransactions 		= {};

		
		// Perform to getAllTransaction action
		$scope.getAllTransaction = function(pageno, order_by, order){ 
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : $scope.pageno;
	       	$scope.order_by = order_by ? order_by : $scope.order_by;
	        $scope.order 	= order ? order : $scope.order;

	        var getAllTransactionParam = {
	            'filterByTransferType'	: $scope.filterByTransferType,
	            'searchByACNoName'		: $scope.searchByACNoName,
	            'order_by'				: $scope.order_by,
	            'order'					: $scope.order,
	            'page'					: $scope.pageno,
	            'page_size'				: $scope.itemsPerPage,
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(getAllTransactionParam, CONFIG.ApiUrl+'transactions/getAllTransaction', $scope.getAllTransactionSuccess, $scope.getAllTransactionError, 'post');
		}
		$scope.getAllTransactionSuccess = function(result,status) {
		    if(status == 200) {
                $scope.allTransactions 	= result.raws.data.dataset;
                $scope.total_count 		= result.raws.data.count;	
                blockUI.stop();
		    }
		}
		$scope.getAllTransactionError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}			

		if($state.$current.name == 'transactions.list'){
			$scope.$watch('searchByACNoName', function(tmpStr) {
			    if (angular.isUndefined(tmpStr)){		    	
			        return 0;
			    }else if(tmpStr==''){
					$scope.getAllTransaction($scope.pageno, $scope.order_by, $scope.order, $scope.searchByACNoName);
			    }else{
			    	$timeout(function() { 
				        if (tmpStr === $scope.searchByACNoName) {
							$scope.getAllTransaction($scope.pageno, $scope.order_by, $scope.order, $scope.searchByACNoName);
				        }
				    }, 1000);	
			    }		    
			});
		}
		/*************** **************** **************** **************** ******************/

		$scope.importTransactions = {};
		// Perform the import agentCode action
		$scope.uploadCSV = function (element) {
			$scope.file_csv = element.files[0];
			//console.log($scope.file_csv);
		}
		$scope.doimportTransaction = function() { 
			//console.log(agentCodeData);
			var formdata = new FormData();
			formdata.append('file_name', $scope.file_csv);
			formdata.append('pass_key', $cookies.get('pass_key'));
			formdata.append('admin_user_id', $cookies.get('admin_user_id'));

			ajaxService.ApiCallImagePost(formdata, CONFIG.ApiUrl+'transactions/importTransaction', $scope.importTransactionSuccess, $scope.importTransactionError, 'post');
		}
		//addAgentCode success function
		$scope.importTransactionSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage 		= result.raws.success_message;
                $scope.importTransactions 	= result.raws.data.dataset;
                $scope.importCount 			= result.raws.data.count;
            	$scope.clearMessage();  
		    }		       
		}
		//addAgentCode error function
		$scope.importTransactionError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }  
		}

		/*************** **************** **************** **************** ******************/
	    
	    $scope.filterByAmount	= '';
	    $scope.filterByDate		= '';
	    $scope.searchByACNo 	= '';
	    $scope.orderByImportHistory	 = 'value_date';
	    $scope.allImportHistory	 = {};

		// Perform to getAllImportHistory action
		$scope.getAllImportHistory = function(pageno, orderByImportHistory, order){ 
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : $scope.pageno;
	       	$scope.orderByImportHistory = orderByImportHistory ? orderByImportHistory : $scope.orderByImportHistory;
	        $scope.order 	= order ? order : $scope.order;

	        var getAllImportHistoryParam = {
	            'filterByAmount'		: $scope.filterByAmount,
	            'filterByDate'			: $scope.filterByDate,
	            'searchByACNo'			: $scope.searchByACNo,
	            'order_by'				: $scope.orderByImportHistory,
	            'order'					: $scope.order,
	            'page'					: $scope.pageno,
	            'page_size'				: $scope.itemsPerPage,
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(getAllImportHistoryParam, CONFIG.ApiUrl+'transactions/getAllImportHistory', $scope.getAllImportHistorySuccess, $scope.getAllImportHistoryError, 'post');
		}
		$scope.getAllImportHistorySuccess = function(result,status) {
		    if(status == 200) {
                $scope.allImportHistory = result.raws.data.dataset;
                $scope.total_count 		= result.raws.data.count;	
                //$scope.filterDate 	= result.raws.data.filterDate;	
                $scope.filterAmount 	= result.raws.data.filterAmount;	
                blockUI.stop();
		    }
		}
		$scope.getAllImportHistoryError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}			

		if($state.$current.name == 'transactions.import-history'){
			$scope.$watch('searchByACNo', function(tmpStr) {
			    if (angular.isUndefined(tmpStr)){		    	
			        return 0;
			    }else if(tmpStr==''){
					$scope.getAllImportHistory($scope.pageno, $scope.orderByImportHistory, $scope.order, $scope.searchByACNo);
			    }else{
			    	$timeout(function() { 
				        if (tmpStr === $scope.searchByACNo) {
							$scope.getAllImportHistory($scope.pageno, $scope.orderByImportHistory, $scope.order, $scope.searchByACNo);
				        }
				    }, 1000);	
			    }		    
			});
		}
		/*************** **************** **************** **************** ******************/

		//open viewImportHistoryPopup
		$scope.viewImportHistoryPopup = function(importHistoryId){
			$rootScope.importHistoryId = importHistoryId ? importHistoryId : '';

			$uibModal.open({
				animation: true,
				templateUrl: 'app/components/transactions/views/transactions.modal.import.details.view.html',
				controllerAs : 'vihdc',
				controller: 'viewImportHistoryDetailsController',
				bindToController : true
			});
		}
		/*************** **************** **************** **************** ******************/

		// Perform to getAllExportPending action
	    $scope.orderByExportPending	 = 'export_request_timestamp';
	    $scope.allExportPending	 = {};

		$scope.getAllExportPending = function(pageno, orderByExportPending, order){ 
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : $scope.pageno;
	       	$scope.orderByExportPending = orderByExportPending ? orderByExportPending : $scope.orderByExportPending;
	        $scope.order 	= order ? order : $scope.order;

	        var getAllExportPendingParam = {
	            'orderByExportPending'	: $scope.orderByExportPending,
	            'order'					: $scope.order,
	            'page'					: $scope.pageno,
	            'page_size'				: $scope.itemsPerPage,
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(getAllExportPendingParam, CONFIG.ApiUrl+'transactions/getAllExportPending', $scope.getAllExportPendingSuccess, $scope.getAllExportPendingError, 'post');
		}
		$scope.getAllExportPendingSuccess = function(result,status) {
		    if(status == 200) {
                $scope.allExportPending			= result.raws.data.dataset;
                $scope.totalExportPendingCount 	= result.raws.data.count;	
                $scope.current_date 			= result.raws.data.current_date;	
                $scope.next_expoted_series 		= result.raws.data.next_expoted_series;	
                blockUI.stop();
		    }
		}
		$scope.getAllExportPendingError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}			

		if($state.$current.name == 'transactions.export'){
			$scope.$watch('searchByACNoName', function(tmpStr) {
			    if (angular.isUndefined(tmpStr)){		    	
			        return 0;
			    }else if(tmpStr==''){
					$scope.getAllExportPending($scope.pageno, $scope.orderByExportPending, $scope.order);
			    }else{
			    	$timeout(function() { 
				        if (tmpStr === $scope.searchByACNoName) {
							$scope.getAllExportPending($scope.pageno, $scope.orderByExportPending, $scope.order);
				        }
				    }, 1000);	
			    }		    
			});
		}
		/*************** **************** **************** **************** ******************/

		$scope.doExportPendingTransaction = function(){ 
			blockUI.start();	        

	        var exportPendingParam = {
	            'current_date'			: $scope.current_date,
	            'next_expoted_series'	: $scope.next_expoted_series,
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(exportPendingParam, CONFIG.ApiUrl+'transactions/exportPendingTransaction', $scope.exportPendingSuccess, $scope.exportPendingError, 'post');
		}
		$scope.exportPendingSuccess = function(result,status) {
		    if(status == 200) {
		    	window.open(result.raws.data);
            	$scope.successMessage = result.raws.success_message;
                $scope.allExportPending			= {};
                $scope.totalExportPendingCount 	= 0;	
            	$scope.clearMessage();  
                blockUI.stop();
		    }
		}
		$scope.exportPendingError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}

		/*************** **************** **************** **************** ******************/

	    $scope.filterByTransactionType	= '';
	    $scope.filterByDate				= '';
	    $scope.searchByACNoName 		= '';
	    $scope.orderByExportHistory	 	= 'export_request_timestamp';
	    $scope.allExportHistory	 		= {};

		// Perform to getAllExportHistory action
		$scope.getAllExportHistory = function(pageno, orderByExportHistory, order){ 
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : $scope.pageno;
	       	$scope.orderByExportHistory = orderByExportHistory ? orderByExportHistory : $scope.orderByExportHistory;
	        $scope.order 	= order ? order : $scope.order;

	        var getAllExportHistoryParam = {
	            'filterByTransactionType'	: $scope.filterByTransactionType,
	            'filterByDate'				: $scope.filterByDate,
	            'searchByACNoName'			: $scope.searchByACNoName,
	            'order_by'					: $scope.orderByExportHistory,
	            'order'						: $scope.order,
	            'page'						: $scope.pageno,
	            'page_size'					: $scope.itemsPerPage,
		        'pass_key'					: $cookies.get('pass_key'),
	        	'admin_user_id' 			: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(getAllExportHistoryParam, CONFIG.ApiUrl+'transactions/getAllExportHistory', $scope.getAllExportHistorySuccess, $scope.getAllExportHistoryError, 'post');
		}
		$scope.getAllExportHistorySuccess = function(result,status) {
		    if(status == 200) {
                $scope.allExportHistory = result.raws.data.dataset;
                $scope.total_count 		= result.raws.data.count;	
                $scope.filterDate 		= result.raws.data.filterDate;	
                $scope.filterAmount 	= result.raws.data.filterAmount;	
                blockUI.stop();
		    }
		}
		$scope.getAllExportHistoryError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}			

		if($state.$current.name == 'transactions.export-history'){
			$scope.$watch('searchByACNoName', function(tmpStr) {
			    if (angular.isUndefined(tmpStr)){		    	
			        return 0;
			    }else if(tmpStr==''){
					$scope.getAllExportHistory($scope.pageno, $scope.orderByExportHistory, $scope.order, $scope.searchByACNoName);
			    }else{
			    	$timeout(function() { 
				        if (tmpStr === $scope.searchByACNoName) {
							$scope.getAllExportHistory($scope.pageno, $scope.orderByExportHistory, $scope.order, $scope.searchByACNoName);
				        }
				    }, 1000);	
			    }		    
			});
		}
		/*************** **************** **************** **************** ******************/

		//open viewExportHistoryPopup
		$scope.viewExportHistoryPopup = function(exportHistoryId){
			$rootScope.exportHistoryId = exportHistoryId ? exportHistoryId : '';

			$uibModal.open({
				animation: true,
				templateUrl: 'app/components/transactions/views/transactions.modal.export.details.view.html',
				controllerAs : 'vehdc',
				controller: 'viewExportHistoryDetailsController',
				bindToController : true
			});
		}
		/*************** **************** **************** **************** ******************/


		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])

	.controller('viewImportHistoryDetailsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', "$uibModalInstance", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $uibModalInstance, $rootScope){
		//var vbdc = this;

		$scope.cancel = function(){
			$uibModalInstance.dismiss('cancel');
		}

		// Perform the importHistoryDetails action
		$scope.importHistoryDetails = function(){			
			var importHistoryDetailsParam = {
				'importHistoryId' 	: $rootScope.importHistoryId,
		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id' 	: $cookies.get('admin_user_id')
	      	};
			ajaxService.ApiCall(importHistoryDetailsParam, CONFIG.ApiUrl+'transactions/importHistoryDetails', $scope.importHistoryDetailsSuccess, $scope.importHistoryDetailsError, 'post');
			}
		$scope.importHistoryDetailsSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage 			= result.raws.success_message;
            	$scope.importHistoryDetails 	= result.raws.data;
            	$scope.clearMessage();  
		    }		       
		}
		$scope.importHistoryDetailsError = function(result) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
		$scope.importHistoryDetails();

	}])

/* ---------------------*/
.controller('viewExportDownloadController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $rootScope){

	    $scope.filterByDate				= '';
	    $scope.orderByExportDownload	 	= 'export_request_timestamp';
	    $scope.allExportDownload		= {};
	    $scope.successMessage 		= '';
		$scope.errorMessage 		= '';
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage;			
	    $scope.order 				= 'desc';

		
		$scope.exportDownloadDetails = function(pageno, orderByExportDownload, order){		
			$scope.pageno 	= pageno ? pageno : $scope.pageno;
			$scope.orderByExportDownload = orderByExportDownload ? orderByExportDownload : $scope.orderByExportDownload;
			$scope.order 	= order ? order : $scope.order;	
			var exportDownloadParam = {
		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id' 	: $cookies.get('admin_user_id'),
	            'filterByDate'				: $scope.filterByDate,
	            'order_by'					: $scope.orderByExportDownload,
	            'order'						: $scope.order,
	            'page'						: $scope.pageno,
	            'page_size'					: $scope.itemsPerPage,
	      	};
			ajaxService.ApiCall(exportDownloadParam, CONFIG.ApiUrl+'transactions/exportDownloadDetails', $scope.exportexportDownloadParamSuccess, $scope.exportexportDownloadParamError, 'post');
			}
		$scope.exportexportDownloadParamSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage 			= result.raws.success_message;
            	$scope.allExportDownload 	= result.raws.data.dataset;
                $scope.total_count 		= result.raws.data.count;
            	$scope.clearMessage();  
		    }		       
		}
		$scope.exportexportDownloadParamError = function(result) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
		$scope.exportDownloadDetails();

	}])
/****************************/
	.controller('viewExportHistoryDetailsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', "$uibModalInstance", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $uibModalInstance, $rootScope){
		//var vbdc = this;

		$scope.cancel = function(){
			$uibModalInstance.dismiss('cancel');
		}

		// Perform the exportHistoryIdDetails action
		$scope.exportHistoryIdDetails = function(){			
			var exportHistoryIdDetailsParam = {
				'exportHistoryId' 	: $rootScope.exportHistoryId,
		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id' 	: $cookies.get('admin_user_id')
	      	};
			ajaxService.ApiCall(exportHistoryIdDetailsParam, CONFIG.ApiUrl+'transactions/exportHistoryIdDetails', $scope.exportHistoryIdDetailsSuccess, $scope.exportHistoryIdDetailsError, 'post');
			}
		$scope.exportHistoryIdDetailsSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage 			= result.raws.success_message;
            	$scope.exportHistoryIdDetails 	= result.raws.data;
            	$scope.clearMessage();  
		    }		       
		}
		$scope.exportHistoryIdDetailsError = function(result) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
		$scope.exportHistoryIdDetails();

	}]);

/********************************************************/
	