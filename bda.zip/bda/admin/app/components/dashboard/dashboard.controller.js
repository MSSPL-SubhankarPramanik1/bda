angular
	.module('bda')
	.controller('dashboardController', ["$scope", "$http", "$window", "$q", '$cookies', '$rootScope', function($scope, $http, $window, $q, $cookies, $rootScope){

		$rootScope.admin_level = 0;
		$rootScope.admin_level = $cookies.get('admin_level');
		//console.log($rootScope.admin_level);
			
	}]);