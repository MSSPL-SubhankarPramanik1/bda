angular.module('bda')
    /*
     * --------------------------------------------------------------------------
     * @ Directive Name           : dashboardHeader()
     * @ Added Date               : 14-04-2016
     * @ Added By                 : Subhankar
     * -----------------------------------------------------------------
     * @ Description              : admin dashboard header is managed from here
     * -----------------------------------------------------------------
     * @ return                   : array
     * -----------------------------------------------------------------
     * @ Modified Date            : 14-04-2016
     * @ Modified By              : Subhankar
     * 
     */
	.directive('dashboardHeader', function() {
        return {
        	controllerAs : 'dh',
        	controller : function($scope, $timeout, CONFIG, ajaxService, $location, $cookies){
        		var dh = this;
                
                // Retrieving a cookie
                var admin_user_id   = $cookies.get('admin_user_id');
                var pass_key        = $cookies.get('pass_key');
                var param = {};
                param.admin_user_id = admin_user_id;
                param.pass_key      = pass_key;

                dh.logout = function(){
                    ajaxService.ApiCall(param, CONFIG.ApiUrl+'admin/logOut', dh.logoutSuccess, dh.logoutError, 'post');                   
                }
                //login success function
                dh.logoutSuccess = function(result,status){
                    if(status == 200){

                        // Removing a cookie
                        $cookies.remove('admin_user_id');
                        $cookies.remove('pass_key');

                        //console.log($cookies.getAll());

                        $scope.successMessage = result.raws.success_message;
                        //$scope.errorMessage = result.raws.error_message;
                        $location.path('/home/login')   ;
                    }
                }                
                //login error function
                dh.logoutError = function(result){
                    $scope.errorMessage = result.raws.error_message;
                    $timeout(function() {
                        $scope.errorMessage = '';
                        $scope.successMessage = '';
                    }, CONFIG.TimeOut);
                } 
				return dh;
        	},
            templateUrl: 'app/components/dashboard/views/dashboard.header.html',
        };
    })



    /*
     * --------------------------------------------------------------------------
     * @ Directive Name           : dashboardHeaderSubadmin()
     * @ Added Date               : 14-04-2016
     * @ Added By                 : Subhankar
     * -----------------------------------------------------------------
     * @ Description              : admin dashboard header is managed from here
     * -----------------------------------------------------------------
     * @ return                   : array
     * -----------------------------------------------------------------
     * @ Modified Date            : 14-04-2016
     * @ Modified By              : Subhankar
     * 
     */
    .directive('dashboardHeaderSubadmin', function() {
        return {
            controllerAs : 'dhs',
            controller : function($scope, $timeout, CONFIG, ajaxService, $location, $cookies){
                var dhs = this;
                
                // Retrieving a cookie
                var admin_user_id   = $cookies.get('admin_user_id');
                var pass_key        = $cookies.get('pass_key');
                var param = {};
                param.admin_user_id = admin_user_id;
                param.pass_key      = pass_key;

                dhs.logout = function(){
                    ajaxService.ApiCall(param, CONFIG.ApiUrl+'admin/logOut', dhs.logoutSuccess, dhs.logoutError, 'post');                   
                }
                //login success function
                dhs.logoutSuccess = function(result,status){
                    if(status == 200){

                        // Removing a cookie
                        $cookies.remove('admin_user_id');
                        $cookies.remove('pass_key');

                        //console.log($cookies.getAll());

                        $scope.successMessage = result.raws.success_message;
                        //$scope.errorMessage = result.raws.error_message;
                        $location.path('/home/login')   ;
                    }
                }                
                //login error function
                dhs.logoutError = function(result){
                    $scope.errorMessage = result.raws.error_message;
                    $timeout(function() {
                        $scope.errorMessage = '';
                        $scope.successMessage = '';
                    }, CONFIG.TimeOut);
                } 


                return dhs;
            },
            templateUrl: 'app/components/dashboard/views/dashboard.header.subadmin.html',
        };
    })



    .directive('owlCarousel', function () {
        return function(scope, element, attrs) {

            element.owlCarousel({
                items: 6, //10 items above 1000px browser width
                itemsDesktop: [1199, 4], //5 items between 1000px and 901px
                itemsDesktopSmall: [900, 4], // betweem 900px and 601px
                itemsTablet: [600, 2], //2 items between 600 and 0
                itemsMobile: false, // itemsMobile disabled - inherit from itemsTablet option
                autoPlay: false,
                pagination: false
            });

            // Custom Navigation Events
            $(".next").click(function() {
                element.trigger('owl.next');
            })
            $(".prev").click(function() {
                element.trigger('owl.prev');
            })
        }
    })











    /*
     * --------------------------------------------------------------------------
     * @ Directive Name           : dashboardBreadcrumb()
     * @ Added Date               : 14-04-2016
     * @ Added By                 : Subhankar
     * -----------------------------------------------------------------
     * @ Description              : admin dashboard header is managed from here
     * -----------------------------------------------------------------
     * @ return                   : array
     * -----------------------------------------------------------------
     * @ Modified Date            : 14-04-2016
     * @ Modified By              : Subhankar
     * 
     */
    .directive('dashboardBreadcrumb', function() {
        return {
            controllerAs : 'dbc',
            controller : function($scope, $timeout, CONFIG, ajaxService, $location, $cookies){
                var dbc = this;
                return dbc;
            },
            templateUrl: 'app/components/dashboard/views/dashboard.breadcrumb.html'
        };
    })


    .directive('dashboardPageTitle', function() {
        return {
            controllerAs : 'dpt',
            controller : function($scope, $timeout, CONFIG, ajaxService, $location, $cookies){
                var dpt = this;
                return dpt;
            },
            templateUrl: 'app/components/dashboard/views/dashboard.pageTitle.html'
        };
    });    