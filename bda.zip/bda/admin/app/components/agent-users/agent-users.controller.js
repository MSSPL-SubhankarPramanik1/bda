angular
	.module('bda')
	.controller('agentUserController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "blockUI", '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, blockUI, $window){

		$scope.allAgentUsers 		= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= 100;   // CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'profile_update_timestamp';
	    $scope.order 				= 'desc';
	    $scope.searchByNameEmail	= '';
		
		// Perform to getAllAgentUsers action
		$scope.getAllAgentUsers = function(pageno, order_by, order)
		{ 
            blockUI.start();
	        $scope.pageno 	= pageno ? pageno : $scope.pageno;
	       	$scope.order_by = order_by ? order_by : $scope.order_by;
	        $scope.order 	= order ? order : $scope.order;

	        var getUserParam = {
	            'searchByNameEmail'	: $scope.searchByNameEmail,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage,
                'pass_key'          : $cookies.get('pass_key'),
                'admin_user_id'     : $cookies.get('admin_user_id'),
	        };
			ajaxService.ApiCall(getUserParam, CONFIG.ApiUrl+'agent_users/getAllAgentUsers', $scope.getAllAgentUsersSuccess, $scope.getAllAgentUsersError, 'post');
		}

		//getAllAgentUsers success function
		$scope.getAllAgentUsersSuccess = function(result,status){
		    if(status == 200){
                $scope.allAgentUsers = result.raws.data.dataset;
                $scope.total_count 	 = result.raws.data.count.count_user;
                blockUI.stop();
		    }
		}

		//getAllAgentUsers error function
		$scope.getAllAgentUsersError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		/****************Search START******************/
		$scope.$watch('searchByNameEmail', function(tmpStr){
		    if (angular.isUndefined(tmpStr)){		    	
		        return 0;
		    } else if(tmpStr=='') {
				$scope.getAllAgentUsers($scope.pageno, $scope.order_by, $scope.order, $scope.searchByNameEmail);
		    } else {
		    	$timeout(function() { 
			        if (tmpStr === $scope.searchByNameEmail) {
						$scope.getAllAgentUsers($scope.pageno, $scope.order_by, $scope.order, $scope.searchByNameEmail);
			        }
			    }, 1000);
		    }		    
		})
		/**************** Search END ******************/   
		

		$scope.clearMessage = function()
		{
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])

    .controller('refAgentUserController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "blockUI", '$window', '$stateParams', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, blockUI, $window, $stateParams){

        $scope.allRefUsers        = {};
        $scope.pageno               = 1; // initialize page no to 1
        $scope.itemsPerPage         = 100;   // CONFIG.itemsPerPage; 
        $scope.order_by             = 'profile_update_timestamp';
        $scope.order                = 'desc';
        $scope.searchByNameEmail    = '';
        
        // Perform to getAllRefUsers action
        $scope.getAllRefUsers = function(pageno, order_by, order)
        { 
            blockUI.start();
            $scope.pageno   = pageno ? pageno : $scope.pageno;
            $scope.order_by = order_by ? order_by : $scope.order_by;
            $scope.order    = order ? order : $scope.order;

            var getUserParam = {
                'searchByNameEmail' : $scope.searchByNameEmail,
                'order_by'          : $scope.order_by,
                'order'             : $scope.order,
                'page'              : $scope.pageno,
                'page_size'         : $scope.itemsPerPage,
                'refUserId'         : $stateParams.refUserId,
                'pass_key'          : $cookies.get('pass_key'),
                'admin_user_id'     : $cookies.get('admin_user_id'),
            };
            ajaxService.ApiCall(getUserParam, CONFIG.ApiUrl+'agent_users/getAllRefUsers', $scope.getAllRefUsersSuccess, $scope.getAllRefUsersError, 'post');
        }

        //getAllRefUsers success function
        $scope.getAllRefUsersSuccess = function(result,status){
            if(status == 200){
                $scope.allAgentUsers = result.raws.data.dataset;
                $scope.total_count   = result.raws.data.count.count_user;
                blockUI.stop();
            }
        }

        //getAllRefUsers error function
        $scope.getAllRefUsersError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
        }

        /****************Search START******************/
        $scope.$watch('searchByNameEmail', function(tmpStr){
            if (angular.isUndefined(tmpStr)){               
                return 0;
            } else if(tmpStr=='') {
                $scope.getAllRefUsers($scope.pageno, $scope.order_by, $scope.order, $scope.searchByNameEmail);
            } else {
                $timeout(function() { 
                    if (tmpStr === $scope.searchByNameEmail) {
                        $scope.getAllRefUsers($scope.pageno, $scope.order_by, $scope.order, $scope.searchByNameEmail);
                    }
                }, 1000);
            }           
        })
        /**************** Search END ******************/   
        

        $scope.clearMessage = function()
        {
            $timeout(function() {
                $scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
        }
    }])