angular
	.module('bda')
	.controller('dataCollectionsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "$uibModal", "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, $uibModal, helper, $rootScope, blockUI){
		$scope.successMessage 		= '';
		$scope.errorMessage 		= '';
		$scope.allDataCollections 	= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; //this could be a dynamic value from Pagination			
	    $scope.order_by 			= 'id';
	    $scope.order 				= 'desc';
	    $scope.filterByStatus 		= '';


		// Perform to getAllDataCollections action
		$scope.getAllDataCollections = function(pageno, order_by, order){ 
            blockUI.start();
	        $scope.pageno 	= pageno ? pageno : $scope.pageno;
	       	$scope.order_by = order_by ? order_by : $scope.order_by;
	        $scope.order 	= order ? order : $scope.order;

	        var getAgentCodeParam = {
	            'filterByStatus'	: $scope.filterByStatus,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage,

		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id'		: $cookies.get('admin_user_id')         
	        };

			ajaxService.ApiCall(getAgentCodeParam, CONFIG.ApiUrl+'admin_data_collections/getAllUserData', $scope.getAllDataCollectionsSuccess, $scope.getAllDataCollectionsError, 'post');
		}
		//getAllDataCollections success function
		$scope.getAllDataCollectionsSuccess = function(result,status) {
		    if(status == 200) {
                $scope.allDataCollections 	= result.raws.data.dataset;
                $scope.total_count 			= result.raws.data.count;	
		    }
		    $timeout(function() {
        		blockUI.stop();
            }, 1000);
		}
		//getAllDataCollections error function
		$scope.getAllDataCollectionsError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
	    }			

		if($state.$current.name == 'data-collections.list'){
			$scope.getAllDataCollections($scope.pageno, $scope.order_by, $scope.order);
		}
		/**************** **************** **************** **************** ******************/		
	

		// Perform the approveUser action
		$scope.doApproveUser = function(user_id, approveUserIndex) { 
			$scope.approveUserIndex 	= approveUserIndex;

	        var approveUserParam = {			
				'userId'		: user_id,
	        	'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }

			ajaxService.ApiCall(approveUserParam, CONFIG.ApiUrl+'admin_data_collections/updateApprovedStatus', $scope.approveUserSuccess, $scope.approveUserError, 'post');
		}
		//approveUser success function
		$scope.approveUserSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage = result.raws.success_message;
	            $scope.clearMessage();

	            var currentDate = new Date();
				var day = currentDate.getDate();
				var month = currentDate.getMonth() + 1;
				var year = currentDate.getFullYear();

	            $scope.allDataCollections[$scope.approveUserIndex].is_approved = 1 ;
                $scope.allDataCollections[$scope.approveUserIndex].approved_timestamp = (new Date()).toString().split(' ').splice(1,3).join(' ');
		    }		       
		}
		//approveUser error function
		$scope.approveUserError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		/**************** **************** **************** **************** ******************/		
	

		// Perform the sendInvitation action
		$scope.doSendInvitation = function(user_id, sendInvitationIndex) { 
			$scope.sendInvitationIndex 	= sendInvitationIndex;

	        var sendInvitationParam = {			
				'userId'		: user_id,
	        	'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }

			ajaxService.ApiCall(sendInvitationParam, CONFIG.ApiUrl+'admin_data_collections/sendMailToUser', $scope.sendInvitationSuccess, $scope.sendInvitationError, 'post');
		}
		//sendInvitation success function
		$scope.sendInvitationSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage = result.raws.success_message;
	            $scope.clearMessage();

	            /*var currentDate = new Date();
				var day = currentDate.getDate();
				var month = currentDate.getMonth() + 1;
				var year = currentDate.getFullYear();

	            $scope.allDataCollections[$scope.sendInvitationIndex].is_mail_sent = 1 ;
                $scope.allDataCollections[$scope.sendInvitationIndex].mail_sent_timestamp = (new Date()).toString().split(' ').splice(1,3).join(' ');*/
	            $scope.allDataCollections[$scope.sendInvitationIndex].is_mail_sent = result.raws.data.is_mail_sent ;
	            $scope.allDataCollections[$scope.sendInvitationIndex].mail_sent_timestamp = result.raws.data.mail_sent_timestamp ;
		    }		       
		}
		//sendInvitation error function
		$scope.sendInvitationError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		/**************** **************** **************** **************** ******************/		

		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, 3000);
		}
	}])


