angular
	.module('bda')
	.controller('editProfileController', ["$scope", "$rootScope", '$stateParams', '$timeout', "$uibModal", 'helper', 'CONFIG', 'ajaxService', '$location', '$cookies', function($scope, $rootScope, $stateParams, $timeout, $uibModal, helper, CONFIG, ajaxService, $location, $cookies){

		//var epc = this;
		$scope.editProfile={};

		// Perform the get User
		$scope.getAdminUser = function() { 
            var param = {
		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id'		: $cookies.get('admin_user_id')         
            };            

        	ajaxService.ApiCall(param, CONFIG.ApiUrl+'admin/getAdminUser', $scope.getAdminUserSuccess, $scope.getAdminUserError, 'post');
		}
		//getUser success function
		$scope.getAdminUserSuccess = function(result,status) {
		    if(status == 200) {
		    	$scope.editProfile = result.raws.data;
		    	//console.log($scope.editProfile);
		    }		       
		}
		//getUser error function
		$scope.getAdminUserError = function(result) {
            $scope.errorMessage = result.raws.error_message;
            //helper.showErrorMessage(result.raws.error_message);
            $scope.clearMessage();
		}
		$scope.getAdminUser();


		$scope.doupdateAdminUser = function(editProfile) { 
            var param = {
		        'f_name'			: editProfile.f_name,
	        	'l_name'			: editProfile.l_name,         
		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id'		: $cookies.get('admin_user_id')         
            };           
			
			//console.log(param);
        	ajaxService.ApiCall(param, CONFIG.ApiUrl+'admin/updateAdminUser', $scope.doupdateAdminUserSuccess, $scope.doupdateAdminUserError, 'post');
		}
		//updateAdminUser success function
		$scope.doupdateAdminUserSuccess = function(result,status) {
		    if(status == 200) {
				$scope.successMessage = result.raws.success_message;
				$scope.clearMessage();
		    }		       
		}
		//updateAdminUser error function
		$scope.doupdateAdminUserError = function(result) {
            $scope.errorMessage = result.raws.error_message;
			$scope.clearMessage();
		}

		$scope.clearMessage = function(){
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])


angular
	.module('bda')
	.controller('changePasswordController', ["$scope", "$rootScope", '$stateParams', '$timeout', "$uibModal", 'helper', 'CONFIG', 'ajaxService', '$location', '$cookies', function($scope, $rootScope, $stateParams, $timeout, $uibModal, helper, CONFIG, ajaxService, $location, $cookies){

		/*var cpc = this;*/
		$scope.changePassword = {};
		
		$scope.dochangePassword = function(changePassword) { 
            var param = {};
            var admin_user_id   	= $cookies.get('admin_user_id');
			param.old_password 		= changePassword.old_password;
			param.new_password 		= changePassword.new_password;
			param.confirm_password 	= changePassword.confirm_password;
			param.admin_user_id 	= admin_user_id;
			param.pass_key 			= $cookies.get('pass_key');
			//console.log(param);

        	ajaxService.ApiCall(param, CONFIG.ApiUrl+'admin/updateAdminPassword', $scope.dochangePasswordSuccess, $scope.dochangePasswordError, 'post');
		}
		//changePassword success function
		$scope.dochangePasswordSuccess = function(result,status) {
		    if(status == 200) {
				$scope.successMessage = result.raws.success_message;
				$scope.changePassword = {};
				$scope.clearMessage();
		    }		       
		}
		//changePassword error function
		$scope.dochangePasswordError = function(result) {
            $scope.errorMessage = result.raws.error_message;
			$scope.clearMessage();
		}

		$scope.clearMessage = function(){
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, 3000);
		}
	}])