angular
	.module('bda')
	.controller('kyc-documentController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, blockUI){

		//$scope.degreeData 			= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'id';
	    $scope.order 				= 'desc';
	    $scope.searchByDocumentName	= '';
		
		// Perform to getAllKYCDocument action
		$scope.getAllKYCDocument = function(pageno, order_by, order){
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : 'id';
	        $scope.order 	= order ? order : 'desc';

	        var getDegreeParam = {
	        	'pass_key' 				: $cookies.get('pass_key'),
	        	'admin_user_id'			: $cookies.get('admin_user_id'),
	            'searchByDocumentName'	: $scope.searchByDocumentName,
	            'order_by'				: $scope.order_by,
	            'order'					: $scope.order,
	            'page'					: $scope.pageno,
	            'page_size'				: $scope.itemsPerPage
	        };
			ajaxService.ApiCall(getDegreeParam, CONFIG.ApiUrl+'kyc_documents/getAllKYCDocument', $scope.getAllKYCDocumentSuccess, $scope.getAllKYCDocumentError, 'post');
		}

		//getAllKYCDocument success function
		$scope.getAllKYCDocumentSuccess = function(result, status){
		    if(status == 200) {
                $scope.allKYCDocuments 	= result.raws.data.dataset;
                $scope.total_count 		= result.raws.data.count;
                blockUI.stop();
		    }		       
		}

		//getAllKYCDocument error function
		$scope.getAllKYCDocumentError = function(result, status) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		/****************Search START******************/
		if($state.$current.name == 'kyc-document.list'){
			$scope.$watch('searchByDocumentName', function(tmpStr) {
			    if (angular.isUndefined(tmpStr)){		    	
			        return 0;
			    } else if(tmpStr=='') {
					$scope.getAllKYCDocument($scope.pageno,$scope.order_by,$scope.order,$scope.searchByDocumentName);
			    } else {
			    	$timeout(function() { 
				        if (tmpStr === $scope.searchByDocumentName) {
							$scope.getAllKYCDocument($scope.pageno, $scope.order_by, $scope.order, $scope.searchByDocumentName);
				        }
				    }, 1000);	
			    }		    
			});
		}
		/**************** Search END ******************/
		
		// Perform the addKYCDocument action
		$scope.doaddKYCDocument = function(kycDocumentData){
        	var kycDocumentDataParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(kycDocumentDataParam, kycDocumentData);

			ajaxService.ApiCall(kycDocumentDataParam, CONFIG.ApiUrl+'kyc_documents/addKYCDocument', $scope.addKYCDocumentSuccess, $scope.addKYCDocumentError, 'post');
		}

		//addKYCDocument success function
		$scope.addKYCDocumentSuccess = function(result, status){
		    if(status == 200){
		    	$scope.successMessage = result.raws.success_message;
		    	$scope.clearMessage();
		        $location.path('dashboard/kyc-document/list');
		    }		       
		}

		//addKYCDocument error function
		$scope.addKYCDocumentError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

		$scope.clearMessage = function(){
			$timeout(function(){
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, 3000);
		}
	}])	

	.controller('editKYC-DocumentController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', 'blockUI', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, blockUI){
		//var epc = this;
		$scope.kycDocumentData 	= {};
		$scope.documentNameId 		= $stateParams.documentNameId;
		$scope.successMessage 		= '';
        $scope.errorMessage 		= '';
        //alert($stateParams.documentNameId);

		// Perform to getDegreeTypeDetail action
		$scope.getDocumentNameDetail = function(){
			blockUI.start();
			var documentNameParam = {
				'documentNameId' 	: $scope.documentNameId,
				'pass_key' 			: $cookies.get('pass_key'),
				'admin_user_id' 	: $cookies.get('admin_user_id')
			};
			ajaxService.ApiCall(documentNameParam, CONFIG.ApiUrl+'kyc_documents/getDocumentNameDetail', $scope.getDocumentNameDetailSuccess, $scope.getDocumentNameDetailError, 'post');
		}

		//getDegreeTypeDetail success function
		$scope.getDocumentNameDetailSuccess = function(result, status) {
		    if(status == 200){
                $scope.kycDocumentData = result.raws.data.dataset;
                //console.log($scope.kycDocumentData);
                blockUI.stop();
		    }
		}

		//getDegreeTypeDetail error function
		$scope.getDocumentNameDetailError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if($state.$current.name == 'kyc-document.edit'){
			$scope.getDocumentNameDetail();
		}

		// Perform to updateDegreeTypeDetail action
		$scope.doeditKYCDocument = function(kycDocumentData){
			kycDocumentData.pass_key 		= $cookies.get('pass_key');
        	kycDocumentData.admin_user_id 	= $cookies.get('admin_user_id');
			ajaxService.ApiCall(kycDocumentData, CONFIG.ApiUrl+'kyc_documents/editKYCDocument', $scope.doeditKYCDocumentSuccess, $scope.doeditKYCDocumentError, 'post');
		}

		//updateDegreeTypeDetail success function
		$scope.doeditKYCDocumentSuccess = function(result,status){
		    if(status == 200){
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
		        	$location.path('dashboard/kyc-document/list');
		        }, 3000);
		    }
		}

		//updateDegreeTypeDetail error function
		$scope.doeditKYCDocumentError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}
		
		$scope.clearMessage = function() {
			$timeout(function(){
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])