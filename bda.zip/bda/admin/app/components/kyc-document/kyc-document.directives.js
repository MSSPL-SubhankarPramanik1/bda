angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : kycDocumentListLeftMenu()
    * @ Added Date               : 08-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : degree type list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 08-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('kycDocumentListLeftMenu', function() {
        return {
            controllerAs : 'kdllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var kdllm = this;
                return kdllm;
            },
            templateUrl: 'app/components/kyc-document/views/kyc-document.list.left.menu.html'
        };
    })
    