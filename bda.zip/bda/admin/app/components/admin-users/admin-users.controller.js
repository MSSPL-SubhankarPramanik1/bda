angular
	.module('bda')
	.controller('adminUserController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "blockUI", '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, blockUI, $window){

		$scope.allAdminUsers 		= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'id';
	    $scope.order 				= 'desc';
	    $scope.searchByNameEmail	= '';
		
		// Perform to getAllAdminUsers action
		$scope.getAllAdminUsers = function(pageno, order_by, order)
		{ 
            blockUI.start();
	        $scope.pageno 	= pageno ? pageno : $scope.pageno;
	       	$scope.order_by = order_by ? order_by : $scope.order_by;
	        $scope.order 	= order ? order : $scope.order;

	        var getUserParam = {
	            'searchByNameEmail'	: $scope.searchByNameEmail,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage,
                'pass_key'          : $cookies.get('pass_key'),
                'admin_user_id'     : $cookies.get('admin_user_id'),
	        };
			ajaxService.ApiCall(getUserParam, CONFIG.ApiUrl+'admin/getAllAdminUsers', $scope.getAllAdminUsersSuccess, $scope.getAllAdminUsersError, 'post');
		}

		//getAllAdminUsers success function
		$scope.getAllAdminUsersSuccess = function(result,status){
		    if(status == 200){
                $scope.allAdminUsers = result.raws.data.dataset;
                $scope.total_count 	 = result.raws.data.count;
                blockUI.stop();
		    }
		}

		//getAllAdminUsers error function
		$scope.getAllAdminUsersError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		/****************Search START******************/
		$scope.$watch('searchByNameEmail', function(tmpStr){
		    if (angular.isUndefined(tmpStr)){		    	
		        return 0;
		    } else if(tmpStr=='') {
				$scope.getAllAdminUsers($scope.pageno, $scope.order_by, $scope.order, $scope.searchByNameEmail);
		    } else {
		    	$timeout(function() { 
			        if (tmpStr === $scope.searchByNameEmail) {
						$scope.getAllAdminUsers($scope.pageno, $scope.order_by, $scope.order, $scope.searchByNameEmail);
			        }
			    }, 1000);
		    }		    
		})
		/**************** Search END ******************/



        // Perform the addAdminUser action
        $scope.doaddAdminUser = function(agentCodeData) { 
            var agentCodeDataParam = {          
                'pass_key'      : $cookies.get('pass_key'),
                'admin_user_id' : $cookies.get('admin_user_id')
            }
            angular.extend(agentCodeDataParam, agentCodeData);

            ajaxService.ApiCall(agentCodeDataParam, CONFIG.ApiUrl+'admin/addAdminUser', $scope.addAdminUserSuccess, $scope.addAdminUserError, 'post');
        }
        //addAdminUser success function
        $scope.addAdminUserSuccess = function(result,status) {
            if(status == 200) {
                $scope.successMessage = result.raws.success_message;
                $location.path('dashboard/admin-users/list');
            }              
        }
        //addAdminUser error function
        $scope.addAdminUserError = function(result) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage(); 
            }
        }



		/**************************************************************************************/

        // Perform the generateMpinHashing action
        $scope.dogenerateMpinHashing = function() { 
            var agentCodeDataParam = {          
                'pass_key'      : $cookies.get('pass_key'),
                'admin_user_id' : $cookies.get('admin_user_id')
            }

            ajaxService.ApiCall(agentCodeDataParam, CONFIG.ApiUrl+'admin/generateMpinHashing', $scope.generateMpinHashingSuccess, $scope.generateMpinHashingError, 'post');
        }
        //generateMpinHashing success function
        $scope.generateMpinHashingSuccess = function(result,status) {
            if(status == 200) {
                $scope.mPinHash = result.raws.data.mPinHash;
                alert('mPinHash=>>'+$scope.mPinHash);
            }              
        }
        //generateMpinHashing error function
        $scope.generateMpinHashingError = function(result) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage(); 
            }
        }
		
		/**************************************************************************************/

		$scope.clearMessage = function()
		{
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])