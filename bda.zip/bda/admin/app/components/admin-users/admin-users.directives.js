angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : adminUserListLeftMenu()
    * @ Added Date               : 09-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : user list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 09-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('adminUserListLeftMenu', function() {
        return {
            controllerAs : 'aullm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var aullm = this;
                return aullm;
            },
            templateUrl: 'app/components/admin-users/views/admin-users.list.left.menu.html'
        };
    })

    