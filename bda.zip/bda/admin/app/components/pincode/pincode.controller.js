angular
	.module('bda')
	.controller('pincodeController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "$uibModal", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $uibModal, blockUI)
	{
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'id';
	    $scope.order 				= 'ASC';
	    $scope.autoSuggestCity 		= '';
	    $scope.autoSuggestState 	= '';
	    $scope.searchByCity 		= '';
	    $scope.searchByState 		= '';
	    $scope.searchByPincode 		= '';
	    $scope.importPincodes 		= {};
	    $scope.autoSuggestCity		= '';
	    $scope.autoSuggestState		= '';
		
		// Perform to getAllPincodes action
		$scope.getAllPincodes = function(pageno, order_by, order)
		{ 
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : $scope.order_by;
	        $scope.order 	= order ? order : $scope.order;

	        var getPincodeParam = 
	        {
	            'searchByCity'		: $scope.searchByCity,
	            'searchByState'		: $scope.searchByState,
	            'searchByPincode'	: $scope.searchByPincode,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage,
	            'pass_key'          : $cookies.get('pass_key'),
                'admin_user_id'     : $cookies.get('admin_user_id'),
	        };
			ajaxService.ApiCall(getPincodeParam, CONFIG.ApiUrl+'pincode/getAllPincodes', $scope.getAllPincodesSuccess, $scope.getAllPincodesError, 'post');
		}

		//getAllPincodes success function
		$scope.getAllPincodesSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.allPincodes 	= result.raws.data.dataset;
                $scope.total_count 	= result.raws.data.count;
                //$scope.city_arr 	= result.raws.data.city;
                //$scope.state_arr 	= result.raws.data.state;
		    }		       
		}

		//getAllPincodes error function
		$scope.getAllPincodesError = function(result) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            } 
            else 
            {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		/****************Search START******************/
		if($state.$current.name == 'pincode.list')
		{
			$scope.$watch('searchByPincode', function(tmpStr) 
			{
			    if (angular.isUndefined(tmpStr))
			    {		    	
			        return 0;
			    }
			    else if(tmpStr=='')
			    {
					$scope.getAllPincodes($scope.pageno, $scope.order_by, $scope.order, $scope.searchByPincode);
			    }
			    else
			    {
			    	$timeout(function() 
			    	{ 
				        if (tmpStr === $scope.searchByPincode) 
				        {
							$scope.getAllPincodes($scope.pageno, $scope.order_by, $scope.order, $scope.searchByPincode);
				        }
				    }, 1000);	
			    }		    
			});
		}
		/**************** Search END ******************/


		// Perform to getAllCity action
		$scope.getAllCity = function(){ 
			blockUI.start();

	        var getAllCityParam = {
	            'autoSuggestCity'		: $scope.autoSuggestCity,
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(getAllCityParam, CONFIG.ApiUrl+'pincode/suggestPinListCity', $scope.getAllCitySuccess, $scope.getAllCityError, 'post');
		}
		$scope.getAllCitySuccess = function(result,status) {
		    if(status == 200) {
                $scope.city_arr 	= result.raws.data;	
                if($scope.city_arr.length == 0){
                	$scope.autoSuggestCity = $scope.searchByCity = '';
                	//$scope.getAllPincodes($scope.pageno, $scope.order_by, $scope.order);
                }

                blockUI.stop();
		    }
		}
		$scope.getAllCityError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}			

		// Perform to getAllState action
		$scope.getAllState = function(){ 
			blockUI.start();

	        var getAllStateParam = {
	            'autoSuggestState'		: $scope.autoSuggestState,
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(getAllStateParam, CONFIG.ApiUrl+'pincode/suggestPinListState', $scope.getAllStateSuccess, $scope.getAllStateError, 'post');
		}
		$scope.getAllStateSuccess = function(result,status) {
		    if(status == 200) {
				$scope.state_arr 	= result.raws.data;	
                if($scope.state_arr.length == 0){
                	$scope.autoSuggestState = $scope.searchByState = '';
                	//$scope.getAllPincodes($scope.pageno, $scope.order_by, $scope.order);
                }                
                blockUI.stop();
		    }
		}
		$scope.getAllStateError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}

		$scope.selectCity = function(city_name){
			$scope.autoSuggestCity = city_name;
			$scope.city_arr 	= {};

			$scope.searchByCity = city_name;
			//$scope.getAllPincodes($scope.pageno, $scope.order_by, $scope.order);
		}


		$scope.selectState = function(state_name){
			$scope.autoSuggestState = state_name;
			$scope.state_arr 		= {};

			$scope.searchByState = state_name;
			//$scope.getAllPincodes($scope.pageno, $scope.order_by, $scope.order);
		}




		$scope.viewPincodeDetailsPopup = function(pincode_id)
		{
			$rootScope.pincode_id = pincode_id ? pincode_id : '';
			$uibModal.open({
				animation: true,
				templateUrl: 'app/components/pincode/views/pincode.modal.details.view.html',
				controller: 'viewPincodeDetailsController',
				bindToController : true
			});
		}

		$scope.uploadCSV = function(element)
		{
			$scope.file_csv = element.files[0];
		}

		$scope.importPincodes = function() 
		{
			var formdata = new FormData();
			formdata.append('file_name', $scope.file_csv);
			formdata.append('pass_key', $cookies.get('pass_key'));
			formdata.append('admin_user_id', $cookies.get('admin_user_id'));

			ajaxService.ApiCallImagePost(formdata, CONFIG.ApiUrl+'pincode/importPincode', $scope.importPincodeSuccess, $scope.importPincodeError, 'post');
		}

		$scope.importPincodeSuccess = function(result, status)
		{
			if(status == 200)
			{
				$scope.successMessage 	= result.raws.success_message;
				$scope.importPincodes 	= result.raws.data.dataset;
				$scope.clearMessage();
			}
		}

		$scope.importPincodeError = function(result, status)
		{
			if(status == 403)
            {
                helper.unAuthenticate();
            } 
            else 
            {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		$scope.clearMessage = function()
		{
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])

	.controller('viewPincodeDetailsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "$uibModalInstance", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $uibModalInstance, blockUI)
	{
		$scope.cancel = function()
		{
			$uibModalInstance.dismiss('cancel');
		}

		// Perform the pincodeDetails action
		$scope.pincodeDetails = function()
		{			
			var pincodeDetailsParam = {
				'pincode_id' 	: $rootScope.pincode_id,
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	      	};
			ajaxService.ApiCall(pincodeDetailsParam, CONFIG.ApiUrl+'pincode/pincodeDetails', $scope.pincodeDetailsSuccess, $scope.pincodeDetailsError, 'post');
		}
		$scope.pincodeDetailsSuccess = function(result,status) 
		{
		    if(status == 200) {
            	$scope.successMessage = result.raws.success_message;
            	$scope.pincodeDetails 	= result.raws.data.dataset;
            	$scope.clearMessage();  
		        //$location.path('dashboard/banks/list');
		    }		       
		}

		$scope.pincodeDetailsError = function(result) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
	        //$scope.cancel();
		}

		// Perform the clearMessage action
		$scope.clearMessage = function() 
		{
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
		$scope.pincodeDetails();
	}])

.controller('editPincodeController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams',"$uibModal", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state,helper, $rootScope, $stateParams,$uibModal)
	{
		//var epc = this;
		$scope.pincodeDetail 	= {};
		$scope.pincodeId 		= $stateParams.pincodeId;
		$scope.successMessage 	= '';
        $scope.errorMessage 	= '';

		// Perform to collegeDetail action
		$scope.getPincodeDetail = function()
		{ 
			var pincodeParam = {'pincodeId' : $scope.pincodeId};
			ajaxService.ApiCall(pincodeParam, CONFIG.ApiUrl+'pincode/getPincodeDetail', $scope.getPincodeDetailSuccess, $scope.getPincodeDetailError, 'post');
		}

		//collegeDetail success function
		$scope.getPincodeDetailSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
		    	//console.log(result.raws.data.dataset);
                $scope.pincodeDetail = result.raws.data.dataset;
              
		    }
		}

		//collegeDetail error function
		$scope.getPincodeDetailError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}

		if($state.$current.name == 'pincode.edit')
		{
			$scope.getPincodeDetail();
		}

		// Perform to updateDegreeDetail action
		$scope.updatePincodeDetail = function(pincodeDetail)
		{
			ajaxService.ApiCall(pincodeDetail, CONFIG.ApiUrl+'pincode/updatePincodeDetail', $scope.updatePincodeDetailSuccess, $scope.updatePincodeDetailError, 'post');
		}

		//updateDegreeDetail success function
		$scope.updatePincodeDetailSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
		        	$location.path('dashboard/pincode/list');
		        }, CONFIG.TimeOut);
		    }
		}

		//updateDegreeDetail error function
		$scope.updatePincodeDetailError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}
		
		$scope.clearMessage = function()
		{
			$timeout(function() 
			{
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}



	}])