angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : pincodeListLeftMenu()
    * @ Added Date               : 21-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : pincode list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 21-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('pincodeListLeftMenu', function() {
        return {
            controllerAs : 'pllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var pllm = this;
                return pllm;
            },
            templateUrl: 'app/components/pincode/views/pincode.list.left.menu.html'
        };
    })
    