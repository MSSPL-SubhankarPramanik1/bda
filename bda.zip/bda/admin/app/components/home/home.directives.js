angular.module('bda')
	/*
     * --------------------------------------------------------------------------
     * @ Directive Name           : logIn()
     * @ Added Date               : 14-04-2016
     * @ Added By                 : Subhankar
     * -----------------------------------------------------------------
     * @ Description              : admin login functionality is managed from here
     * -----------------------------------------------------------------
     * @ return                   : array
     * -----------------------------------------------------------------
     * @ Modified Date            : 14-04-2016
     * @ Modified By              : Subhankar
     * 
     */

/*
* Modifiled By : Subhajit Singha Roy
* Modified Date : 27/04/2015
* ------------------------------------------
* Desciption : Custom directive for adding custom validation for matching password and confirm paasword
* ---------------------------------------------
* param : N/A
* return : N/A 
* */
