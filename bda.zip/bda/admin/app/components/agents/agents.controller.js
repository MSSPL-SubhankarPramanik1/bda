angular
	.module('bda')
	.controller('agentsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "$uibModal", "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, $uibModal, helper, $rootScope, blockUI){
		$scope.successMessage 		= '';
		$scope.errorMessage 		= '';
		$scope.agentCodeData 		= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; //this could be a dynamic value from Pagination			
	    $scope.order_by 			= 'is_active';
	    $scope.order 				= 'desc';
	    $scope.searchByCodeorName 	= '';
	    $rootScope.agent_code_id 	= '';
	    $rootScope.sendAgentCodeIndex 	= '';
		$rootScope.successMessage 	= '';
	    $scope.importAgentCode 		= {};

		
		// Perform to getAllAgentCode action
		$scope.getAllAgentCode = function(pageno, order_by, order){ 
            blockUI.start();
	        $scope.pageno 	= pageno ? pageno : $scope.pageno;
	       	$scope.order_by = order_by ? order_by : $scope.order_by;
	        $scope.order 	= order ? order : $scope.order;
    		//$scope.isActive = '';
    		//$scope.searchByCodeorName = searchByCodeorName ? searchByCodeorName : '';

	        var getAgentCodeParam = {
	            'searchByCodeorName': $scope.searchByCodeorName,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage,

		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id'		: $cookies.get('admin_user_id')         
	        };

			ajaxService.ApiCall(getAgentCodeParam, CONFIG.ApiUrl+'agents/getAllAgentCode', $scope.getAllAgentCodeSuccess, $scope.getAllAgentCodeError, 'post');
		}
		//forgetPassword success function
		$scope.getAllAgentCodeSuccess = function(result,status) {
		    if(status == 200) {
                $rootScope.allAgentCodes 	= result.raws.data.dataset;
                $scope.total_count 			= result.raws.data.count;	
		        //$location.path('dashboard/agents/list');
		    }
		    $timeout(function() {
        		blockUI.stop();
            }, 1000);
		}
		//forgetPassword error function
		$scope.getAllAgentCodeError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
	    }			

		/****************Search START******************/
		if($state.$current.name == 'agents.list'){
			$scope.$watch('searchByCodeorName', function(tmpStr) {
			    if (angular.isUndefined(tmpStr)){		    	
			        return 0;
			    }else if(tmpStr==''){
					$scope.getAllAgentCode($scope.pageno, $scope.order_by, $scope.order, $scope.searchByCodeorName);
			    }else{
			    	$timeout(function() { 
				        if (tmpStr === $scope.searchByCodeorName) {
							$scope.getAllAgentCode($scope.pageno, $scope.order_by, $scope.order, $scope.searchByCodeorName);
				        }
				    }, 1000);	
			    }		    
			});
		}
	/**************** Search END ******************/
		// Generate Agent Code
		$scope.dogenerateAgentCode = function() { 
	        var generateAgentCodeParam = {
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
	        }

			ajaxService.ApiCall(generateAgentCodeParam, CONFIG.ApiUrl+'agents/generateAgentCode', $scope.generateAgentCodeSuccess, $scope.generateAgentCodeError, 'post');
		}
		//addAgentCode success function
		$scope.generateAgentCodeSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.agentCodeData.agent_code = result.raws.data;
		        $location.path('dashboard/agents/add');
		    }		       
		}
		//addAgentCode error function
		$scope.generateAgentCodeError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		if($state.$current.name == 'agents.add'){
			$scope.dogenerateAgentCode();
		}



		// Perform the addAgentCode action
		$scope.doaddAgentCode = function(agentCodeData) { 
	        var agentCodeDataParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(agentCodeDataParam, agentCodeData);

			ajaxService.ApiCall(agentCodeDataParam, CONFIG.ApiUrl+'agents/addAgentCode', $scope.addAgentCodeSuccess, $scope.addAgentCodeError, 'post');
		}
		//addAgentCode success function
		$scope.addAgentCodeSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage = result.raws.success_message;
		        $location.path('dashboard/agents/list');
		    }		       
		}
		//addAgentCode error function
		$scope.addAgentCodeError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}


		$scope.agentCodeIndex = 0;
		$scope.deleteAgentCode = function(agentCodeId,agentCodeIndex){
			$scope.agentCodeIndex = agentCodeIndex;
			var agentCodeParam = {
				'agentCodeId' 	: agentCodeId,
			    'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
			};
			ajaxService.ApiCall(agentCodeParam, CONFIG.ApiUrl+'agents/deleteAgentCode', $scope.deleteAgentCodeSuccess, $scope.deleteAgentCodeError, 'post');
			}
		//addAgentCode success function
		$scope.deleteAgentCodeSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage = result.raws.success_message;
	            $scope.clearMessage(); 
		        $scope.allAgentCodes.splice($scope.agentCodeIndex, 1);
		    }		       
		}
		//addAgentCode error function
		$scope.deleteAgentCodeError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

			
		//open SendCodePopup
		$scope.doSendCodePopup = function(agent_code_id, sendAgentCodeIndex){
			$rootScope.agent_code_id 		= agent_code_id ? agent_code_id : '';
			$rootScope.sendAgentCodeIndex 	= sendAgentCodeIndex;

			$uibModal.open({
				animation: true,
				templateUrl: 'app/components/agents/views/agents.modal.sendAgentCode.view.html',
				controllerAs : 'sac',
				controller: 'sendAgentsController',
				bindToController : true
			});
		}


		// Perform the import agentCode action
		//$scope.agent_code_file = 'choose file';
		$scope.uploadCSV = function (element) {
			$scope.file_csv = element.files[0];
			$scope.agent_code_file = element.files[0]['name'];
			//console.log($scope.agent_code_file);
		}
		$scope.doimportAgentCode = function(agent_code_file) { 
			//console.log(agent_code_file);
			var formdata = new FormData();
			formdata.append('file_name', $scope.file_csv);
			formdata.append('pass_key', $cookies.get('pass_key'));
			formdata.append('admin_user_id', $cookies.get('admin_user_id'));

			ajaxService.ApiCallImagePost(formdata, CONFIG.ApiUrl+'agents/importAgentCode', $scope.importAgentCodeSuccess, $scope.importAgentCodeError, 'post');
		}
		//addAgentCode success function
		$scope.importAgentCodeSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage 	= result.raws.success_message;
                $scope.importAgentCode 	= result.raws.data.dataset;
                $scope.importCount 		= result.raws.data.count;
            	$scope.clearMessage(); 
            	//$location.path('dashboard/agents/list');
		    }		       
		}
		//addAgentCode error function
		$scope.importAgentCodeError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, 3000);
		}
	}])



	.controller('sendAgentsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "$uibModalInstance","helper", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, $uibModalInstance, helper, $rootScope){
		var sac = this;
		sac.successMessage 	= '';
		sac.errorMessage 	= '';

		sac.cancel = function(){
			$uibModalInstance.dismiss('cancel');
			//$state.reload();
		}

		// Perform the addAgentCode action
		sac.doSendCode = function(sendCode) { 
	        var sendCodeParam = {			
				'agent_code_id'	: $rootScope.agent_code_id,
	        	'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(sendCodeParam, sendCode);

			ajaxService.ApiCall(sendCodeParam, CONFIG.ApiUrl+'agents/sendCode', sac.sendCodeSuccess, sac.sendCodeError, 'post');
		}
		//addAgentCode success function
		sac.sendCodeSuccess = function(result,status) {
		    if(status == 200) {
            	sac.successMessage = result.raws.success_message;
	            sac.clearMessage();
	            $rootScope.allAgentCodes[$rootScope.sendAgentCodeIndex].is_sent = 1 ;

	            var currentDate = new Date();
				var day = currentDate.getDate();
				var month = currentDate.getMonth() + 1;
				var year = currentDate.getFullYear();

	            $rootScope.allAgentCodes[$rootScope.sendAgentCodeIndex].added_on_timestamp = (new Date()).toString().split(' ').splice(1,3).join(' ');
		    }		       
		}
		//addAgentCode error function
		sac.sendCodeError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            sac.errorMessage = result.raws.error_message;
	            sac.clearMessage(); 
	        }
		}

		// Perform the clearMessage action
		sac.clearMessage = function() {
			$timeout(function() {
        		sac.successMessage = '';
                sac.errorMessage = '';
            }, 3000);
		}		
		return sac;
	}]);
