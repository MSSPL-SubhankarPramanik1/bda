angular
	.module('bda')
	.controller('banksController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "$uibModal", "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, $uibModal, helper, $rootScope, blockUI){
		$scope.successMessage 		= '';
		$scope.errorMessage 		= '';
		$scope.allBanks 			= {};
		$scope.city_arr 			= {};
		$scope.state_arr 			= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= 50; //CONFIG.itemsPerPage;			
	    $scope.order_by 			= 'ifsc_code';
	    $scope.order 				= 'desc';
	    $scope.searchByCity			= '';
	    $scope.searchByState		= '';
	    $scope.searchByIfscNameCity = '';
	    $scope.importBanks 			= {};
	    $scope.autoSuggestCity		= '';
	    $scope.autoSuggestState		= '';

		
		// Perform to getAllBank action
		$scope.getAllBank = function(pageno, order_by, order){ 
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : 'ifsc_code';
	        $scope.order 	= order ? order : 'desc';

	        var getAllBankParam = {
	            'searchByCity'			: $scope.searchByCity,
	            'searchByState'			: $scope.searchByState,
	            'searchByIfscNameCity'	: $scope.searchByIfscNameCity,
	            'order_by'				: $scope.order_by,
	            'order'					: $scope.order,
	            'page'					: $scope.pageno,
	            'page_size'				: $scope.itemsPerPage,
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(getAllBankParam, CONFIG.ApiUrl+'banks/getAllBank', $scope.getAllBankSuccess, $scope.getAllBankError, 'post');
		}
		$scope.getAllBankSuccess = function(result,status) {
		    if(status == 200) {
                $scope.allBanks 	= result.raws.data.dataset;
                $scope.total_count 	= result.raws.data.count;	
                blockUI.stop();
		    }
		}
		$scope.getAllBankError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}			

		/****************Search START******************/
		if($state.$current.name == 'banks.list'){
			$scope.$watch('searchByIfscNameCity', function(tmpStr) {
			    if (angular.isUndefined(tmpStr)){		    	
			        return 0;
			    }else if(tmpStr==''){
					$scope.getAllBank($scope.pageno, $scope.order_by, $scope.order, $scope.searchByIfscNameCity);
			    }else{
			    	$timeout(function() { 
				        if (tmpStr === $scope.searchByIfscNameCity) {
							$scope.getAllBank($scope.pageno, $scope.order_by, $scope.order, $scope.searchByIfscNameCity);
				        }
				    }, 1000);	
			    }		    
			});
		}
		/**************** Search END ******************/		

		// Perform to getAllCity action
		$scope.getAllCity = function(){ 
			blockUI.start();

	        var getAllCityParam = {
	            'autoSuggestCity'		: $scope.autoSuggestCity,
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(getAllCityParam, CONFIG.ApiUrl+'banks/suggestListCity', $scope.getAllCitySuccess, $scope.getAllCityError, 'post');
		}
		$scope.getAllCitySuccess = function(result,status) {
		    if(status == 200) {
                $scope.city_arr 	= result.raws.data;	
                if($scope.city_arr.length == 0){
                	$scope.autoSuggestCity = $scope.searchByCity = '';
                	//$scope.getAllBank($scope.pageno, $scope.order_by, $scope.order);
                }
                blockUI.stop();
		    }
		}
		$scope.getAllCityError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}			

		// Perform to getAllState action
		$scope.getAllState = function(){ 
			blockUI.start();

	        var getAllStateParam = {
	            'autoSuggestState'		: $scope.autoSuggestState,
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(getAllStateParam, CONFIG.ApiUrl+'banks/suggestListState', $scope.getAllStateSuccess, $scope.getAllStateError, 'post');
		}
		$scope.getAllStateSuccess = function(result,status) {
		    if(status == 200) {
				$scope.state_arr 	= result.raws.data;	
                if($scope.state_arr.length == 0){
                	$scope.autoSuggestState = $scope.searchByState = '';
                	//$scope.getAllBank($scope.pageno, $scope.order_by, $scope.order);
                }                
                blockUI.stop();
		    }
		}
		$scope.getAllStateError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}

		$scope.selectCity = function(bank_city){
			$scope.autoSuggestCity = bank_city;
			$scope.city_arr 	= {};

			$scope.searchByCity = bank_city;
			//$scope.getAllBank($scope.pageno, $scope.order_by, $scope.order);
		}


		$scope.selectState = function(bank_state){
			$scope.autoSuggestState = bank_state;
			$scope.state_arr 		= {};

			$scope.searchByState = bank_state;
			//$scope.getAllBank($scope.pageno, $scope.order_by, $scope.order);
		}


		//open SendCodePopup
		$scope.viewBankDetailsPopup = function(bank_id){
			$rootScope.bank_id = bank_id ? bank_id : '';

			$uibModal.open({
				animation: true,
				templateUrl: 'app/components/banks/views/banks.modal.details.view.html',
				controllerAs : 'vbdc',
				controller: 'viewBankDetailsController',
				bindToController : true
			});
		}


		// Perform the import agentCode action
		$scope.uploadCSV = function (element) {
			$scope.file_csv = element.files[0];
			//console.log($scope.file_csv);
		}
		$scope.doimportBank = function() { 
			//console.log(agentCodeData);
			var formdata = new FormData();
			formdata.append('file_name', $scope.file_csv);
			formdata.append('pass_key', $cookies.get('pass_key'));
			formdata.append('admin_user_id', $cookies.get('admin_user_id'));

			ajaxService.ApiCallImagePost(formdata, CONFIG.ApiUrl+'banks/importBank', $scope.importBankSuccess, $scope.importBankError, 'post');
		}
		//addAgentCode success function
		$scope.importBankSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage 	= result.raws.success_message;
                $scope.importBanks 		= result.raws.data.dataset;
                $scope.importCount 		= result.raws.data.count;
            	$scope.clearMessage();  
		        //$location.path('dashboard/banks/list');
		    }		       
		}
		//addAgentCode error function
		$scope.importBankError = function(result) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }  
		}

		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}

	}])

	.controller('viewBankDetailsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', "$uibModalInstance", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $uibModalInstance, $rootScope){
		//var vbdc = this;

		$scope.cancel = function(){
			$uibModalInstance.dismiss('cancel');
		}

		// Perform the bankDetails action
		$scope.bankDetails = function(){			
			var bankDetailsParam = {
				'bank_id' 		: $rootScope.bank_id,
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	      	};
			ajaxService.ApiCall(bankDetailsParam, CONFIG.ApiUrl+'banks/bankDetails', $scope.bankDetailsSuccess, $scope.bankDetailsError, 'post');
			}
		$scope.bankDetailsSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage = result.raws.success_message;
            	$scope.bankDetails 	= result.raws.data.dataset;
            	$scope.clearMessage();  
		        //$location.path('dashboard/banks/list');
		    }		       
		}
		$scope.bankDetailsError = function(result) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
	        //$scope.cancel();
		}

		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
		$scope.bankDetails();

	}]);

