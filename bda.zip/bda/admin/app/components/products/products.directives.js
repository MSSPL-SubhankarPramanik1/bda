angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : productsListLeftMenu()
    * @ Added Date               : 14-04-2016
    * @ Added By                 : Subhankar
    * -----------------------------------------------------------------
    * @ Description              : product list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 14-04-2016
    * @ Modified By              : Subhankar
    * 
    */
    .directive('productsListLeftMenu', function() {
        return {
            controllerAs : 'pllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var pllm = this;
                return pllm;
            },
            templateUrl: 'app/components/products/views/products.list.left.menu.html'
        };
    })
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : productsListLeftMenu()
    * @ Added Date               : 14-04-2016
    * @ Added By                 : Subhankar
    * -----------------------------------------------------------------
    * @ Description              : product detail left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 14-04-2016
    * @ Modified By              : Subhankar
    * 
    */
    .directive('productsDetailLeftMenu', function() {
        return {
            controllerAs : 'pdlm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var pdlm = this;
                return pdlm;
            },
            templateUrl: 'app/components/products/views/products.detail.left.menu.html'
        };
    })