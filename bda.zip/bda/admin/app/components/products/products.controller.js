angular
	.module('bda')
	.controller('productsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $window){

		$scope.productData 				= {};
		$scope.productData.product_type = 'P';
	    $scope.pageno 					= 1; // initialize page no to 1
	    $scope.itemsPerPage 			= CONFIG.itemsPerPage; 
	    $scope.order_by 				= 'id';
	    $scope.order 					= 'desc';
	    $scope.searchByProfession 		= '';
		helper.getAllProfession();
		
		// Perform to getAllProduct action
		$scope.getAllProduct = function(pageno, order_by, order){ 
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : 'id';
	        $scope.order 	= order ? order : 'desc';

	        var getProductParam = {
	            'searchByProfession': $scope.searchByProfession,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage,
		        
		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id'		: $cookies.get('admin_user_id')         
	        };

			ajaxService.ApiCall(getProductParam, CONFIG.ApiUrl+'products/getAllProduct', $scope.getAllProductSuccess, $scope.getAllProductError, 'post');
		}
		$scope.getAllProductSuccess = function(result,status) {
		    if(status == 200) {
                $scope.allProducts 	= result.raws.data.dataset;
                $scope.total_count 	= result.raws.data.count;	        
		    }		       
		}
		$scope.getAllProductError = function(result, status) {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}		
		

		// Call to getAllProduct
		if($state.$current.name == 'products.list'){
			$scope.getAllProduct($scope.pageno, $scope.order_by, $scope.order);
		}

		//Delete Unused Product
		/*$scope.deleteProduct = function(pid)
		{
			var deleteParamas = {
				'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id'		: $cookies.get('admin_user_id'),
	        	'product_id'		: pid
			};

			ajaxService.ApiCall(deleteParamas, CONFIG.ApiUrl+'products/deleteProduct', $scope.deleteProductSuccess, $scope.deleteProductError, 'post');
		}

		$scope.deleteProductSuccess = function(result, status)
		{
			if(status == 200)
			{
				$scope.successMessage = "Delete Product Succfully";
			}
		}

		$scope.deleteProductError = function(result, status)
		{
			if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}*/


		// Call to getAllPaymentType
		if($state.$current.name == 'products.add'){
			helper.getAllPaymentType();
		}


		// Perform the addProduct action
		$scope.doaddProduct = function(productData) {
			var base_price = 1.00; 
			//alert(productData.product_type+'<===>'+productData.range_fixed+'<===>'+productData.range_from+'<===>'+productData.range_to);	
			var flag = false;
			if(productData.product_type == 'P'){
				if(parseFloat(productData.range_fixed) >= parseFloat(base_price)){
					flag = true;
				} else {
					flag = false;
					$scope.errorMessage = 'Product price must be greater than 0';
		            $scope.clearMessage();
					return false;
				}
			} else {

				if(parseFloat(productData.range_from) >= parseFloat(base_price)){
					flag = true;
				} else {
					flag = false;
					$scope.errorMessage = 'Product price range from must be greater than 0';
		            $scope.clearMessage();
					return false;
				}

				if(parseFloat(productData.range_to) >= parseFloat(base_price)){
					flag = true;
				} else {
					flag = false;
					$scope.errorMessage = 'Product price range to must be greater than 0';
		            $scope.clearMessage();
					return false;
				}

				if(parseFloat(productData.range_from) < parseFloat(productData.range_to)){
					flag = true;
				} else {
					flag = false;
					$scope.errorMessage = 'Product price range to must be greater than range from';
		            $scope.clearMessage();
					return false;
				}
			}					

			if(flag){
				var productDataParam = {			
			        'pass_key'		: $cookies.get('pass_key'),
		        	'admin_user_id' : $cookies.get('admin_user_id')
		        }
		        angular.extend(productDataParam, productData);

				ajaxService.ApiCall(productDataParam, CONFIG.ApiUrl+'products/addProduct', $scope.addProductSuccess, $scope.addProductError, 'post');
			}
			
		}
		$scope.addProductSuccess = function(result,status) {
		    if(status == 200) {
		    	$window.scrollTo(0, 100);
		    	$scope.successMessage = result.raws.success_message; 
            	$scope.clearMessage();
		        $timeout(function() {
                    $location.path('dashboard/products/payment_interest/'+result.raws.data.id);
                }, CONFIG.TimeOut);
		    }		       
		}
		$scope.addProductError = function(result, status) {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }  
		}


		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, 3000);
		}		
	}])

	.controller('editProductsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, $window){

		$rootScope.productDetail = {};

		// Perform to getProductDetail action
		$scope.getProductDetail = function(current_state){ 
			var productDataParam = {
				'productId' 	: $stateParams.productId,
				'state' 		: current_state,
						
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }

			ajaxService.ApiCall(productDataParam, CONFIG.ApiUrl+'products/getProductDetail', $scope.getProductDetailSuccess, $scope.getProductDetailError, 'post');
		}
		$scope.getProductDetailSuccess = function(result,status) {
		    if(status == 200) {
                $rootScope.productDetail = result.raws.data;
                $rootScope.coin_earning_max_value = {};
                $rootScope.activityFlag = 0;
                if($state.$current.name == 'products.coin_earning')
                {
                	for(var i=0; i < $rootScope.productDetail.coin_earning.length; ++i)
                	{
                		if($rootScope.productDetail.coin_earning[i].fk_mcoin_activity_id == 3)
                		{
                			$rootScope.activityFlag = 1;
                			$rootScope.coin_earning_max_value.non_referred_connections_limit = ($rootScope.productDetail.coin_earning[i].non_referred_connections_limit == null)?0:$rootScope.productDetail.coin_earning[i].non_referred_connections_limit;

                			$rootScope.coin_earning_max_value.referred_connections_limit = ($rootScope.productDetail.coin_earning[i].referred_connections_limit == null)?0:$rootScope.productDetail.coin_earning[i].referred_connections_limit;
                		}
                	}
                }
                if(result.raws.data.state_name == 'payment_interest'){
                	$window.scrollTo(0, 100);
                	var calculate_field = {
                		'pl' 	: '0',
                		'ra_wp' : '0',
                		'pl_wp' : '0',
                		'fpf' 	: '0',
                		'pfd' 	: '0',
                		'tpf' 	: '0',
                		'prm' 	: '0.00',
                		'strp' 	: '0.00',
                		'rrp' 	: '0.00',
                	};
					angular.extend($rootScope.productDetail.payment_interest, calculate_field);
                }                                
		    }		       
		}
		$scope.getProductDetailError = function(result, status) {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            } 
		}		


		// Call to All Calculation
		$scope.calcInput = function($type){ 
			($type == 'EMI') ? helper.emiCalcInput() : helper.oneTimeCalcInput();
		}

		$scope.calcDisbursement = function($type){ 
			($type == 'EMI') ? helper.emiCalcDisbursement() : helper.oneTimeCalcDisbursement();
		}

		$scope.calcLenderFee = function($type){ 
			($type == 'EMI') ? helper.emiCalcLenderFee() : helper.oneTimeCalcLenderFee();
		}

		$scope.penaltyCalc = function($type){
			($type == 'EMI') ? helper.emiPenaltyCalc() : helper.oneTimePenaltyCalc();
		}
		

		// Perform the doAllCalculation action
		$scope.doAllCalculation = function($type){
			var flag = false;
			if($type == 'EMI' && $rootScope.productDetail.payment_interest.input_air > 0 && $rootScope.productDetail.payment_interest.input_npm > 0 && $rootScope.productDetail.payment_interest.input_emi_lty > 0){
				flag = true;
			} else if($type == 'One-time' && $rootScope.productDetail.payment_interest.input_npm > 0){
				flag = true;
			}

			if(flag){
				$scope.calcInput($type);
				$scope.calcDisbursement($type);
				$scope.calcLenderFee($type);
				$scope.penaltyCalc($type);
				//$window.scrollTo(0, 100);
			}
		}


		// Call to All Calculation
		$scope.getProductDetail($state.$current.name);

		// Perform the doeditPaymentInterest action
		$scope.doeditPaymentInterest = function(productDetails) { 
			var productDetail = {};
			//var productDetail.payment_interest = {};

			productDetail.id 				= productDetails.id;
			productDetail.is_available 		= productDetails.is_available;

			productDetail.input_principle 	= productDetails.payment_interest.input_principle;
			productDetail.input_air 		= productDetails.payment_interest.input_air;
			productDetail.input_npm 		= productDetails.payment_interest.input_npm;
			productDetail.input_lpfp 		= productDetails.payment_interest.input_lpfp;
			productDetail.input_ufp 		= productDetails.payment_interest.input_ufp;
			productDetail.input_lfr 		= productDetails.payment_interest.input_lfr;
			productDetail.input_pfpd 		= productDetails.payment_interest.input_pfpd;
			productDetail.input_dpd 		= productDetails.payment_interest.input_dpd;
			productDetail.input_pprm 		= productDetails.payment_interest.input_pprm;
			productDetail.input_emi_lty 	= productDetails.payment_interest.input_emi_lty;
			productDetail.input_emi_obfpf 	= productDetails.payment_interest.input_emi_obfpf;
			productDetail.calc_mir 			= productDetails.payment_interest.calc_mir;
			productDetail.calc_emi_amount 	= productDetails.payment_interest.calc_emi_amount;
			productDetail.calc_emi_tp 		= productDetails.payment_interest.calc_emi_tp;
			productDetail.calc_arl 			= productDetails.payment_interest.calc_arl;
			productDetail.calc_lpfa 		= productDetails.payment_interest.calc_lpfa;
			productDetail.calc_ufa 			= productDetails.payment_interest.calc_ufa;
			productDetail.calc_tst 			= productDetails.payment_interest.calc_tst;
			productDetail.calc_stufa 		= productDetails.payment_interest.calc_stufa;
			productDetail.calc_rufa 		= productDetails.payment_interest.calc_rufa;
			productDetail.calc_tfdb 		= productDetails.payment_interest.calc_tfdb;
			productDetail.calc_da 			= productDetails.payment_interest.calc_da;
			productDetail.calc_lfa 			= productDetails.payment_interest.calc_lfa;
			productDetail.calc_stlf 		= productDetails.payment_interest.calc_stlf;
			productDetail.calc_rlf 			= productDetails.payment_interest.calc_rlf;
			productDetail.calc_ra 			= productDetails.payment_interest.calc_ra;

			var productDetailParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(productDetailParam, productDetail);

			ajaxService.ApiCall(productDetailParam, CONFIG.ApiUrl+'products/editPaymentInterest', $scope.editPaymentInterestSuccess, $scope.editPaymentInterestError, 'post');
		}
		
		$scope.editPaymentInterestSuccess = function(result,status) {
		    if(status == 200) {
		    	$window.scrollTo(0, 100);
		    	$scope.successMessage = result.raws.success_message;
		    	//console.log($scope.successMessage);
               	$scope.clearMessage();
               	$timeout(function() {
               		$location.path('dashboard/products/coin_earning/'+result.raws.data.id);
               	}, CONFIG.TimeOut);
		    }		       
		}
		
		$scope.editPaymentInterestError = function(result, status) {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }          
		}

		/*$scope.stateChanged = function (qId) {
		    	alert('test==>>>'+qId);
		   	if($scope.answers[qId]){ //If it is checked
		    	alert('test');
		   	}
		}*/


		// Perform the doeditCoinEarning action
		$scope.doeditCoinEarning = function(productDetails) {
			for(var i=0; i < productDetails.coin_earning.length; ++i)
        	{
        		if(productDetails.coin_earning[i].fk_mcoin_activity_id == 3)
        		{
        			productDetails.coin_earning[i].non_referred_connections_limit = $rootScope.coin_earning_max_value.non_referred_connections_limit;

        			productDetails.coin_earning[i].referred_connections_limit = $rootScope.coin_earning_max_value.referred_connections_limit;
        		}
        	}
			var jsonString = JSON.stringify(productDetails.coin_earning);
			productDetails.coin_earning_str = jsonString;
			
			var productDetailsParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(productDetailsParam, productDetails);

			ajaxService.ApiCall(productDetailsParam, CONFIG.ApiUrl+'products/editCoinEarning', $scope.editCoinEarningSuccess, $scope.editCoinEarningError, 'post');
		}
		$scope.editCoinEarningSuccess = function(result,status) {
		    if(status == 200) {
		    	$window.scrollTo(0, 100);
		    	$scope.successMessage = result.raws.success_message; 
            	$scope.clearMessage();
            	$timeout(function() {
                    $location.path('dashboard/products/rewards/'+result.raws.data.id);
                }, CONFIG.TimeOut);
		    }		       
		}
		$scope.editCoinEarningError = function(result, status) {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}


		// Perform the doeditRewards action
		$scope.doeditRewards = function(productDetails) {
			var jsonString = JSON.stringify(productDetails.rewards);
			productDetails.rewards_str = jsonString;

			var productDetailsParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(productDetailsParam, productDetails);

			ajaxService.ApiCall(productDetailsParam, CONFIG.ApiUrl+'products/editRewards', $scope.editRewardsSuccess, $scope.editRewardsError, 'post');
		}
		$scope.editRewardsSuccess = function(result,status) {
		    if(status == 200) {
		    	$window.scrollTo(0, 100);
		    	$scope.successMessage = result.raws.success_message;
            	$scope.clearMessage();
            	$timeout(function() {
                    $location.path('dashboard/products/credit_rating_benefits/'+result.raws.data.id);
                }, CONFIG.TimeOut);
		    }		       
		}
		$scope.editRewardsError = function(result, status) {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}


		// Perform the doaddCreditRatingBenefits action
		$scope.doaddCreditRatingBenefits = function(creditRatingBenefits) { 

			var creditRatingBenefitsParam = {			
		        'fk_product_id'		: $rootScope.productDetail.id,
		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id' 	: $cookies.get('admin_user_id')
	        }
	        angular.extend(creditRatingBenefitsParam, creditRatingBenefits);

			ajaxService.ApiCall(creditRatingBenefitsParam, CONFIG.ApiUrl+'products/addCreditRatingBenefits', $scope.addCreditRatingBenefitsSuccess, $scope.addCreditRatingBenefitsError, 'post');
		}
		$scope.addCreditRatingBenefitsSuccess = function(result,status) {
		    if(status == 200) {
		    	$window.scrollTo(0, 100);
		    	$scope.successMessage = result.raws.success_message; 
		        creditRatingBenefits = {
		        	'credit_rating_from' 	: result.raws.data.credit_rating_from,
		        	'credit_rating_to' 		: result.raws.data.credit_rating_to,
		        	'interest_adjustment' 	: result.raws.data.interest_adjustment,
		        	'usage_fee_discount' 	: result.raws.data.usage_fee_discount,
		        	'id' 					: result.raws.data.id,
		        };		        
		        $rootScope.productDetail.credit_rating_benefits.splice(0, 0, creditRatingBenefits);
	           	$scope.clearMessage();
	           	$scope.creditRatingBenefits = {};
		    }		       
		}
		$scope.addCreditRatingBenefitsError = function(result, status) {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}


		// Perform the deleteCreditRatingBenefits action
		$scope.creditRatingBenefitsIndex = 0;
		$scope.deleteCreditRatingBenefits = function(creditRatingBenefitsId,creditRatingBenefitsIndex){
			$scope.creditRatingBenefitsIndex = creditRatingBenefitsIndex;
			var creditRatingBenefitsParam = {
				'creditRatingBenefitsId' 	: creditRatingBenefitsId,
		        'pass_key'					: $cookies.get('pass_key'),
	        	'admin_user_id' 			: $cookies.get('admin_user_id')
			};
			ajaxService.ApiCall(creditRatingBenefitsParam, CONFIG.ApiUrl+'products/deleteCreditRatingBenefits', $scope.deleteCreditRatingBenefitsSuccess, $scope.deleteCreditRatingBenefitsError, 'post');
			}
		$scope.deleteCreditRatingBenefitsSuccess = function(result,status) {
		    if(status == 200) {
		    	$window.scrollTo(0, 100);
            	$scope.successMessage = result.raws.success_message;
		        $rootScope.productDetail.credit_rating_benefits.splice($scope.creditRatingBenefitsIndex, 1);
            	$scope.clearMessage();
		    }		       
		}
		$scope.deleteCreditRatingBenefitsError = function(result, status) {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}


		// Perform the doeditTierBenefits action
		$scope.doeditTierBenefits = function(productDetails) {
			var jsonString = JSON.stringify(productDetails.tier_benefits);
			productDetails.tier_benefits_str = jsonString;

			var productDetailsParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(productDetailsParam, productDetails);

			ajaxService.ApiCall(productDetailsParam, CONFIG.ApiUrl+'products/editTierBenefits', $scope.editTierBenefitsSuccess, $scope.editTierBenefitsError, 'post');
		}
		$scope.editTierBenefitsSuccess = function(result,status) {
		    if(status == 200) {
		    	$window.scrollTo(0, 100);
		    	$scope.successMessage = result.raws.success_message;
            	$scope.clearMessage();
            	$timeout(function() {
                    $location.path('dashboard/products/tier_benefits/'+result.raws.data.id);
                }, CONFIG.TimeOut);
		    }		       
		}
		$scope.editTierBenefitsError = function(result, status) {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}
		

		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, 3000);
		}

	}])