angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : virtualAccountListLeftMenu()
    * @ Added Date               : 21-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : virtual-account list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 21-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('virtualAccountListLeftMenu', function() {
        return {
            controllerAs : 'pllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var pllm = this;
                return pllm;
            },
            templateUrl: 'app/components/virtual-account/views/virtual-account.list.left.menu.html'
        };
    })
    