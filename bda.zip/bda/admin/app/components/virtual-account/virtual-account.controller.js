angular
	.module('bda')
	.controller('maccountController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope)
	{

		$scope.degreeData 			= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'mact.id';
	    $scope.order 				= 'ASC';
	    $scope.searchByAccNo 		= '';
	    $scope.importAccountNo 		= {};
		
		// Perform to getAllAccounts action
		$scope.getAllAccounts = function(pageno, order_by, order)
		{ 
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : $scope.order_by;
	        $scope.order 	= order ? order : $scope.order;

	        var getDegreeParam = 
	        {
	            'searchByAccNo'		: $scope.searchByAccNo,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage,
	            'pass_key'          : $cookies.get('pass_key'),
                'admin_user_id'     : $cookies.get('admin_user_id'),
	        };
			ajaxService.ApiCall(getDegreeParam, CONFIG.ApiUrl+'virtual_account/getAllAccounts', $scope.getAllAccountsSuccess, $scope.getAllAccountsError, 'post');
		}

		//getAllAccounts success function
		$scope.getAllAccountsSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.allAccounts 	= result.raws.data.dataset;
                $scope.total_count 	= result.raws.data.count;	        
		    }		       
		}

		//getAllAccounts error function
		$scope.getAllAccountsError = function(result) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            } 
            else 
            {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		/****************Search START******************/
		if($state.$current.name == 'virtual-account.list')
		{
			$scope.$watch('searchByAccNo', function(tmpStr) 
			{
			    if (angular.isUndefined(tmpStr))
			    {		    	
			        return 0;
			    }
			    else if(tmpStr=='')
			    {
					$scope.getAllAccounts($scope.pageno, $scope.order_by, $scope.order, $scope.searchByAccNo);
			    }
			    else
			    {
			    	$timeout(function() 
			    	{ 
				        if (tmpStr === $scope.searchByAccNo) 
				        {
							$scope.getAllAccounts($scope.pageno, $scope.order_by, $scope.order, $scope.searchByAccNo);
				        }
				    }, 1000);	
			    }		    
			});
		}
		/**************** Search END ******************/

		$scope.uploadCSV = function(element)
		{
			$scope.file_csv = element.files[0];
		}

		$scope.importAccountNumbers = function() 
		{
			var formdata = new FormData();
			formdata.append('file_name', $scope.file_csv);
			formdata.append('pass_key', $cookies.get('pass_key'));
			formdata.append('admin_user_id', $cookies.get('admin_user_id'));

			ajaxService.ApiCallImagePost(formdata, CONFIG.ApiUrl+'virtual_account/importAccountNumber', $scope.importAccountNumberSuccess, $scope.importAccountNumberError, 'post');
		}

		$scope.importAccountNumberSuccess = function(result, status)
		{
			if(status == 200)
			{
				$scope.successMessage 	= result.raws.success_message;
				$scope.importAccountNo 	= result.raws.data.dataset;
				$scope.clearMessage();
			}
		}

		$scope.importAccountNumberError = function(result, status)
		{
			if(status == 403)
            {
                helper.unAuthenticate();
            } 
            else 
            {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		$scope.deleteAccountNumber = function(accountId, accountIndex)
		{
			$scope.accountIndex = accountIndex;
			var accountNumberParam = {
				'accountId' 	: accountId,
			    'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
			};
			ajaxService.ApiCall(accountNumberParam, CONFIG.ApiUrl+'virtual_account/deleteAccountNumber', $scope.deleteAccountNumberSuccess, $scope.deleteAccountNumberError, 'post');
		}

		$scope.deleteAccountNumberSuccess = function(result, status)
		{
			if(status == 200)
			{
				$scope.successMessage = result.raws.success_message;
	            $scope.clearMessage(); 
		        $scope.allAccounts.splice($scope.accountIndex, 1);
			}
		}

		$scope.deleteAccountNumberError = function(result, status)
		{
			if(status == 403)
            {
                helper.unAuthenticate();
            } 
            else 
            {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		$scope.clearMessage = function()
		{
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])

