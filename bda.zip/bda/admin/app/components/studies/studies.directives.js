angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : studiesListLeftMenu()
    * @ Added Date               : 08-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : degree type list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 08-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('studiesListLeftMenu', function() {
        return {
            controllerAs : 'pllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var pllm = this;
                return pllm;
            },
            templateUrl: 'app/components/studies/views/studies.list.left.menu.html'
        };
    })
    