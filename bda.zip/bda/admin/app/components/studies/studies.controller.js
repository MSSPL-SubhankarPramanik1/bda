angular
	.module('bda')
	.controller('studiesController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, blockUI)
	{

		$scope.studiesData 			= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'id';
	    $scope.order 				= 'desc';
	    $scope.searchByStudy 		= '';
		
		// Perform to getAllStudies action
		$scope.getAllStudies = function(pageno, order_by, order)
		{
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : 'id';
	        $scope.order 	= order ? order : 'desc';

	        var getDegreeParam = 
	        {
	        	'pass_key' 			: $cookies.get('pass_key'),
	        	'admin_user_id'		: $cookies.get('admin_user_id'),
	            'searchByStudy'		: $scope.searchByStudy,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage
	        };
			ajaxService.ApiCall(getDegreeParam, CONFIG.ApiUrl+'studies/getAllStudies', $scope.getAllStudiesSuccess, $scope.getAllStudiesError, 'post');
		}

		//getAllStudies success function
		$scope.getAllStudiesSuccess = function(result, status) 
		{
		    if(status == 200) 
		    {
                $scope.allStudies 	= result.raws.data.dataset;
                $scope.total_count 	= result.raws.data.count;
                blockUI.stop();
		    }		       
		}

		//getAllStudies error function
		$scope.getAllStudiesError = function(result, status) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		/****************Search START******************/
		$scope.$watch('searchByStudy', function(tmpStr) 
		{
		    if (angular.isUndefined(tmpStr))
		    {		    	
		        return 0;
		    }
		    else if(tmpStr=='')
		    {
				$scope.getAllStudies($scope.pageno,$scope.order_by,$scope.order,$scope.searchByStudy);
		    }
		    else
		    {
		    	$timeout(function() 
		    	{ 
			        if (tmpStr === $scope.searchByStudy) 
			        {
						$scope.getAllStudies($scope.pageno, $scope.order_by, $scope.order, $scope.searchByStudy);
			        }
			    }, 1000);	
		    }		    
		});
		/**************** Search END ******************/
		
		// Perform the addStudies action
		$scope.doaddStudies = function(studiesData) 
		{
			studiesData.pass_key 		= $cookies.get('pass_key');
        	studiesData.admin_user_id 	= $cookies.get('admin_user_id');
			ajaxService.ApiCall(studiesData, CONFIG.ApiUrl+'studies/addStudies', $scope.addStudiesSuccess, $scope.addStudiesError, 'post');
		}

		//addStudies success function
		$scope.addStudiesSuccess = function(result, status) 
		{
		    if(status == 200) 
		    {
		    	$scope.successMessage = result.raws.success_message;
		    	$scope.clearMessage();
		    	$timeout(function() {
		        	$location.path('dashboard/studies/list');
		        }, CONFIG.TimeOut);
		    }		       
		}

		//addStudies error function
		$scope.addStudiesError = function(result, status) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

		$scope.clearMessage = function()
		{
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])

	.controller('editStudiesController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', 'blockUI', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, blockUI)
	{
		$scope.studyDetail 	= {};
		$scope.studyId 			= $stateParams.studyId;
		$scope.successMessage 	= '';
        $scope.errorMessage 	= '';

		// Perform to getStudyDetails action
		$scope.getStudyDetails = function()
		{
			blockUI.start();
			var degreeParam = {
				'studyId' 		: $scope.studyId,
				'pass_key' 		: $cookies.get('pass_key'),
				'admin_user_id' : $cookies.get('admin_user_id')
			};
			ajaxService.ApiCall(degreeParam, CONFIG.ApiUrl+'studies/getStudyDetails', $scope.getStudyDetailsSuccess, $scope.getStudyDetailsError, 'post');
		}

		//getStudyDetails success function
		$scope.getStudyDetailsSuccess = function(result, status) 
		{
		    if(status == 200) 
		    {
                $scope.studyDetail = result.raws.data.dataset;
                //console.log($scope.studyDetail);
                blockUI.stop();
		    }
		}

		//getStudyDetails error function
		$scope.getStudyDetailsError = function(result, status) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if($state.$current.name == 'studies.edit')
		{
			$scope.getStudyDetails();
		}

		// Perform to updateStudiesDetail action
		$scope.updateStudiesDetail = function(degreeDetail)
		{
			degreeDetail.pass_key 		= $cookies.get('pass_key');
        	degreeDetail.admin_user_id 	= $cookies.get('admin_user_id');
			ajaxService.ApiCall(degreeDetail, CONFIG.ApiUrl+'studies/updateStudiesDetail', $scope.updateStudiesDetailSuccess, $scope.updateStudiesDetailError, 'post');
		}

		//updateStudiesDetail success function
		$scope.updateStudiesDetailSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
		        	$location.path('dashboard/studies/list');
		        }, CONFIG.TimeOut);
		    }
		}

		//updateStudiesDetail error function
		$scope.updateStudiesDetailError = function(result, status) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}
		
		$scope.clearMessage = function()
		{
			$timeout(function() 
			{
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])