angular
	.module('bda')
	.controller('userController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "blockUI", '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, blockUI, $window)
	{

		$scope.allUsers 			= {};
		$scope.professions 			= {};
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'profile_update_timestamp';
	    $scope.order 				= 'desc';
	    $scope.searchByNameEmail	= '';
	    $scope.searchUserMode 		= '';
	    $scope.searchProfession	    = '';
        $scope.searchStatus         = '';
        $scope.isBlock              = '';
		
		// Perform to getAllUsers action
		$scope.getAllUsers = function(pageno, order_by, order)
		{ 
            blockUI.start();
	        $scope.pageno 	= pageno ? pageno : $scope.pageno;
	       	$scope.order_by = order_by ? order_by : $scope.order_by;
	        $scope.order 	= order ? order : $scope.order;

	        var getUserParam = 
	        {
	            'searchByNameEmail'	: $scope.searchByNameEmail,
	            'searchUserMode'	: $scope.searchUserMode,
                'searchStatus'      : $scope.searchStatus,
	            'searchProfession'	: $scope.searchProfession,
	            'order_by'			: $scope.order_by,
	            'order'				: $scope.order,
	            'page'				: $scope.pageno,
	            'page_size'			: $scope.itemsPerPage,
                'pass_key'          : $cookies.get('pass_key'),
                'admin_user_id'     : $cookies.get('admin_user_id'),
	        };
			ajaxService.ApiCall(getUserParam, CONFIG.ApiUrl+'user/getAllUsers', $scope.getAllUsersSuccess, $scope.getAllUsersError, 'post');
		}

		//getAllUsers success function
		$scope.getAllUsersSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.allUsers 	= result.raws.data.dataset;
                //console.log($scope.allUsers);
                $scope.professions 	= result.raws.data.professions;
                $scope.total_count  = result.raws.data.count;
                $scope.total_user_count  = result.raws.data.total_user_count;
                $scope.approved_user_count  = result.raws.data.approved_user_count;
                blockUI.stop();
		    }
		}

		//getAllUsers error function
		$scope.getAllUsersError = function(result, status) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

        if($state.$current.name == 'users.list')
        {
            $scope.getAllUsers();
        }

		/****************Search START******************/
		/*$scope.$watch('searchByNameEmail', function(tmpStr) 
		{
		    if (angular.isUndefined(tmpStr))
		    {		    	
		        return 0;
		    }
		    else if(tmpStr=='')
		    {
				$scope.getAllUsers($scope.pageno, $scope.order_by, $scope.order, $scope.searchByNameEmail);
		    }
		    else
		    {
		    	$timeout(function() 
		    	{ 
			        if (tmpStr === $scope.searchByNameEmail) 
			        {
						$scope.getAllUsers($scope.pageno, $scope.order_by, $scope.order, $scope.searchByNameEmail);
			        }
			    }, 1000);
		    }		    
		})*/
		/**************** Search END ******************/

        $scope.updateBlock = function(user_id, status)
        { 
            blockUI.start();
            
            var getUserParam = 
            {
                'userId'            : user_id,
                'is_block'          : status,
                'pass_key'          : $cookies.get('pass_key'),
                'admin_user_id'     : $cookies.get('admin_user_id')
            };
            ajaxService.ApiCall(getUserParam, CONFIG.ApiUrl+'user/updateIsBlock', $scope.updateBlockSuccess, $scope.updateBlockError, 'post');
        }

        //updateBlock success function
        $scope.updateBlockSuccess = function(result,status){
            if(status == 200){
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                blockUI.stop();
            }
        }

        //updateBlock error function
        $scope.updateBlockError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
        }
     

        $scope.userEditBasicInfo = function(userId)
        {
            var real_path = '#/dashboard/users/basic/'+userId;
            $window.open(real_path, '_blank'); 
        }

		$scope.clearMessage = function()
		{
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])

	.controller('userEditController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', '$window', 'blockUI',"$uibModal", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, $window, blockUI,$uibModal)
	{
		$rootScope.userId 		= $stateParams.userId;
		$scope.degreeDetail 	= {};
		$scope.basicDetails 	= {};
		$scope.successMessage 	= '';
        $scope.errorMessage 	= '';
        $scope.profileStatus 	= "A";
        $scope.residenceStatus 	= 'A';
        $scope.permanentStatus 	= 'A';
        $scope.personalStatus 	= 'A';
        $scope.statusClass 		= {'A' : 'approve', 'P' : 'pending', 'R' : 'decline'};

        $scope.getUserBasic = function()
        {
            blockUI.start();
        	var basicParam = {
        		'userId' 		: $rootScope.userId,
        		'pass_key'		: $cookies.get('pass_key'),
        		'admin_user_id' : $cookies.get('admin_user_id'),
        	}
        	ajaxService.ApiCall(basicParam, CONFIG.ApiUrl+'user/getUserBasic', $scope.getUserBasicSuccess, $scope.getUserBasicError, 'post');
        }

        $scope.getUserBasicSuccess = function(result, status)
        {
        	if(status == 200)
        	{
                $window.scrollTo(0, 100);
        		$scope.basicDetails 	= result.raws.data;
                 //console.log($scope.basicDetails);
        		$scope.profileStatus 	= ($scope.basicDetails == null)?'A':$scope.basicDetails.admin_status_profile_name;
        		$scope.residenceStatus 	= ($scope.basicDetails == null)?'A':$scope.basicDetails.admin_status_residence_address;
        		$scope.permanentStatus 	= ($scope.basicDetails == null)?'A':$scope.basicDetails.admin_status_permanent_address;
        		$scope.personalStatus 	= ($scope.basicDetails == null)?'A':$scope.basicDetails.admin_status_other_info;

        		$scope.profileClass 	= $scope.statusClass[$scope.profileStatus];
        		$scope.residenceClass 	= $scope.statusClass[$scope.residenceStatus];
        		$scope.permanentClass 	= $scope.statusClass[$scope.permanentStatus];
        		$scope.personalClass 	= $scope.statusClass[$scope.personalStatus];
                if($scope.basicDetails.dob) 
                {
                    var date = $scope.basicDetails.date_of_birth;
                    var ageDifMs = Date.now() - new Date(date);
                    var ageDate = new Date(ageDifMs); // miliseconds from epoch
                    //var year = Math.abs(ageDate.getUTCFullYear() - 1970);
                    //  var datse = Math.abs(ageDate.getUTCDate() - );
                    // var month = Math.abs(ageDate.getUTCMonth() - 0);
                    $scope.age = Math.abs(ageDate.getUTCFullYear() - 1970);
                }
                else
                {
                    $scope.age =  0;
                }                
                blockUI.stop();             
        	}
        }

        $scope.getUserBasicError = function(result, status)
        {
        	if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
        }

        if($state.$current.name == 'users.basic')
        {
        	$scope.getUserBasic();
        }

        $scope.approveField = function(fldName, allowed, statusFldName)
        {
        	if(allowed != 0)
        	{
                $window.scrollTo(0, 100);
        		$scope.errorMessage = 'Already Approved this field';
        		$scope.clearMessage();
        	}
        	else
        	{
        		$scope.basicDetails[fldName] = 1;
        	}
        }

        $scope.declineField = function(fldName, allowed, statFldName)
        {
        	if(allowed != 0 && $scope.basicDetails.utp_id != null)
        	{
        		$scope.basicDetails[fldName]        = 0;
                $scope.basicDetails[statFldName]    = 'P';
                if(statFldName == 'admin_status_profile_name')
                {
                    $scope.profileStatus    = $scope.basicDetails[statFldName];
                    $scope.profileClass     = $scope.statusClass[$scope.profileStatus];
                }
                if(statFldName == 'admin_status_residence_address')
                {
                    $scope.residenceStatus  = $scope.basicDetails[statFldName];
                    $scope.residenceClass   = $scope.statusClass[$scope.residenceStatus];
                }
                if(statFldName == 'admin_status_permanent_address')
                {
                    $scope.permanentStatus  = $scope.basicDetails[statFldName];
                    $scope.permanentClass   = $scope.statusClass[$scope.permanentStatus];
                }
        	}
        	else
        	{
                $window.scrollTo(0, 100);
        		if($scope.basicDetails.utp_id == null)
        		{
        			$scope.errorMessage = "Can't decline this field";
        		}
        		else
        		{
        			$scope.errorMessage = "Already decline this field";
        		}
        		$scope.clearMessage();
        	}
        }

        $scope.changeStatusBasicInfo = function()
        {
        	if($scope.basicDetails.utp_id != null)
        	{
        		if(($scope.profileStatus == 'A' && $scope.basicDetails.profile_picture_allowed != 0 && $scope.basicDetails.f_name_allowed != 0 && $scope.basicDetails.m_name_allowed != 0 && $scope.basicDetails.l_name_allowed != 0) || $scope.profileStatus == 'R' || $scope.profileStatus == 'P')
        		{
        			$scope.profileClass = $scope.statusClass[$scope.profileStatus];
        		}
        		else
        		{
                    $window.scrollTo(0, 100);
        			$scope.errorMessage 	= 'Please approve all field at first in this section';
        			$scope.profileStatus 	= $scope.basicDetails.admin_status_profile_name;
        			$scope.profileClass 	= $scope.statusClass[$scope.profileStatus];
        			$scope.clearMessage();
        		}
        	}
        	else
        	{
                $window.scrollTo(0, 100);
        		$scope.errorMessage 	= "Can't change the status for this section";
        		$scope.profileStatus 	= $scope.basicDetails.admin_status_profile_name;
        		$scope.profileClass 	= $scope.statusClass[$scope.profileStatus];
        		$scope.clearMessage();
        	}
        }

        $scope.changeStatusResidence = function()
        {
        	if($scope.basicDetails.utp_id != null)
        	{
        		if(($scope.residenceStatus == 'A' && $scope.basicDetails.residence_street1_allowed != 0 && $scope.basicDetails.residence_street2_allowed != 0 && $scope.basicDetails.residence_street3_allowed != 0 && $scope.basicDetails.residence_zipcode_allowed != 0) || $scope.residenceStatus == 'R' || $scope.residenceStatus == 'P')
        		{
        			$scope.residenceClass = $scope.statusClass[$scope.residenceStatus];
        		}
        		else
        		{
                    $window.scrollTo(0, 100);
        			$scope.errorMessage 	= 'Please approve all field at first in this section';
        			$scope.residenceStatus 	= $scope.basicDetails.admin_status_residence_address;
        			$scope.residenceClass 	= $scope.statusClass[$scope.residenceStatus];
        			$scope.clearMessage();
        		}
        	}
        	else
        	{
                $window.scrollTo(0, 100);
        		$scope.errorMessage 	= "Can't change the status for this section";
        		$scope.residenceStatus 	= $scope.basicDetails.admin_status_residence_address;
        		$scope.residenceClass 	= $scope.statusClass[$scope.residenceStatus];
        		$scope.clearMessage();
        	}
        }

        $scope.changeStatusPermanent = function()
        {
        	if($scope.basicDetails.utp_id != null)
        	{
        		if(($scope.permanentStatus == 'A' && $scope.basicDetails.permanent_street1_allowed != 0 && $scope.basicDetails.permanent_street2_allowed != 0 && $scope.basicDetails.permanent_street3_allowed != 0 && $scope.basicDetails.permanent_zipcode_allowed != 0) || $scope.permanentStatus == 'R' || $scope.permanentStatus == 'P')
        		{
        			$scope.permanentClass = $scope.statusClass[$scope.permanentStatus];
        		}
        		else
        		{
                    $window.scrollTo(0, 100);
        			$scope.errorMessage 	= 'Please approve all field at first in this section';
        			$scope.permanentStatus 	= $scope.basicDetails.admin_status_permanent_address;
        			$scope.permanentClass 	= $scope.statusClass[$scope.permanentStatus];
        			$scope.clearMessage();
        		}
        	}
        	else
        	{
                $window.scrollTo(0, 100);
        		$scope.errorMessage 	= "Can't change the status for this section";
        		$scope.permanentStatus 	= $scope.basicDetails.admin_status_permanent_address;
        		$scope.permanentClass 	= $scope.statusClass[$scope.permanentStatus];
        		$scope.clearMessage();
        	}
        }

        $scope.changeStatusOtherInfo = function()
        {
        	if($scope.basicDetails.utp_id != null)
        	{
    			$scope.personalClass = $scope.statusClass[$scope.personalStatus];
        	}
        	else
        	{
                $window.scrollTo(0, 100);
        		$scope.errorMessage 	= "Can't change the status for this section";
        		$scope.personalStatus 	= $scope.basicDetails.admin_status_other_info;
        		$scope.personalClass 	= $scope.statusClass[$scope.personalStatus];
        		$scope.clearMessage();
        	}
        }


       

        $scope.saveBasicEditInfo = function(saveParam)
        {
            if(saveParam.admin_notes == '' || saveParam.admin_notes == null){
                alert('Please add Admin Notes');
                return false;

            } else {

                if (saveParam.is_email_id_verified != '1'){
                    alert('Please verify the email first !!' );
                    return false;
                } else {

                	var updateParam                             = saveParam;
                    updateParam.admin_status_profile_name       = $scope.profileStatus;
                    updateParam.admin_status_residence_address  = $scope.residenceStatus;
                    updateParam.admin_status_permanent_address  = $scope.permanentStatus;
                    updateParam.admin_status_other_info         = $scope.personalStatus;
                	updateParam.userId                          = $rootScope.userId;
                	updateParam.pass_key                        = $cookies.get('pass_key');
                	updateParam.admin_user_id                   = $cookies.get('admin_user_id');
                	ajaxService.ApiCall(updateParam, CONFIG.ApiUrl+'user/saveBasicEditInfo', $scope.saveBasicEditInfoSuccess, $scope.saveBasicEditInfoError, 'post');
                }
            }
        }

        $scope.saveBasicEditInfoSuccess = function(result, status)
        {
        	if(status == 200)
        	{
                $window.scrollTo(0, 100);
        		$scope.successMessage = result.raws.success_message;
        		$scope.clearMessage();
                $timeout(function() {
                    $scope.getUserBasic();
                }, 5000);
        	}
        }

        $scope.saveBasicEditInfoError = function(result, status)
        {
        	if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $window.scrollTo(0, 100);
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
                //$scope.getUserBasic();
            }
        }

        $scope.cancelBasicEdit = function()
        {
            $location.path('dashboard/users/list');
        }

        $scope.clearMessage = function()
        {
        	$timeout(function() {
        		$scope.successMessage = '';
        		$scope.errorMessage = '';
        	}, CONFIG.TimeOut);
        }

        $scope.viewImagePopup = function(image)
        {   //console.log(image);
            $rootScope.image = image ? image : '';
            $uibModal.open({
                animation: true,
                templateUrl: 'app/components/users/views/user.modal.details.view.html',
                controllerAs : 'vic',
                controller: 'viewUserImageController',
                bindToController : true
            });
        }


        $rootScope.type = '';
        $scope.doSearchPincode = function(type){
            blockUI.start();
            $rootScope.type = type;
            var pin_code = (type == 'residence') ? $scope.basicDetails.residence_zipcode : $scope.basicDetails.permanent_zipcode;

            var pincodeDataParam = {            
                'pin_code'      : pin_code,
            }
            ajaxService.ApiCall(pincodeDataParam, CONFIG.ApiUrl+'user/getPincodeData', $scope.searchPincodeSuccess, $scope.searchPincodeError, 'post');
        }
        //searchPincode success function
        $scope.searchPincodeSuccess = function(result,status) {
            if(status == 200) {
                blockUI.stop();
                if($rootScope.type == 'residence'){
                    $scope.basicDetails.residence_city = result.raws.data.city_name;
                    $scope.basicDetails.residence_state = result.raws.data.state_name;
                } else {
                    $scope.basicDetails.permanent_city = result.raws.data.city_name;
                    $scope.basicDetails.permanent_state = result.raws.data.state_name;
                }

            }              
        }
        //searchPincode error function
        $scope.searchPincodeError = function(result,status) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                alert(result.raws.error_message);
                if($rootScope.type == 'residence'){
                    $scope.basicDetails.residence_city = '';
                    $scope.basicDetails.residence_state = '';
                } else {
                    $scope.basicDetails.permanent_city = '';
                    $scope.basicDetails.permanent_state = '';
                }
            }
            blockUI.stop();
        }









	}])

    .controller('userEducationController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', "blockUI", '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, blockUI, $window)
    {
        $rootScope.userId       = $stateParams.userId;
        $rootScope.educationId  = $stateParams.educationId;
        $rootScope.eduStatus    = $stateParams.eduStatus;
        $scope.userEducationDetails = {};
        $scope.educationStatus  = 'A';
        $scope.educationClass   = 'approve';
        $scope.statusClass      = {'A' : 'approve', 'P' : 'pending', 'R' : 'decline'};
        $scope.order_by         = 'ed.id';
        $scope.order            = 'desc';
        $scope.workStatus       = {'P' : 'Part Time', 'F' : 'Full Time', 'N' : 'Not Employeed'};

        $scope.getUserEducation = function(order_by, order)
        {
            blockUI.start();
            var basicParam = {
                'userId'        : $rootScope.userId,
                'pass_key'      : $cookies.get('pass_key'),
                'admin_user_id' : $cookies.get('admin_user_id'),
                'order_by'      : order_by ? order_by : $scope.order_by,
                'order'         : order ? order : $scope.order
            }
            ajaxService.ApiCall(basicParam, CONFIG.ApiUrl+'user/getUserEducationLists', $scope.getUserEducationSuccess, $scope.getUserEducationError, 'post');
        }

        $scope.getUserEducationSuccess = function(result, status)
        {
            if(status == 200)
            {
                $scope.userEducationList = result.raws.data.dataset;
                //$scope.total_counted    = result.raws.data.count;
                blockUI.stop();
            }
        }

        $scope.getUserEducationError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
        }

        if($state.$current.name == 'users.education')
        {
            $scope.getUserEducation();
        }

        $scope.getUserEducationDetails = function()
        {
            var basicParam = {
                'userId'        : $rootScope.userId,
                'pass_key'      : $cookies.get('pass_key'),
                'admin_user_id' : $cookies.get('admin_user_id'),
                'educationId'   : $rootScope.educationId,
                'eduStatus'     : $rootScope.eduStatus
            }
            ajaxService.ApiCall(basicParam, CONFIG.ApiUrl+'user/getUserEducationDetails', $scope.getUserEducationDetailsSuccess, $scope.getUserEducationDetailsError, 'post');
        }

        $scope.getUserEducationDetailsSuccess = function(result, status)
        {
            if(status == 200)
            {
                $scope.userEducationDetails = result.raws.data.dataset;
                //console.log($scope.userEducationDetails);
                $scope.percentage = ($scope.userEducationDetails.marks == 0) ? 0 : (($scope.userEducationDetails.marks / $scope.userEducationDetails.out_of_range) * 100);
                //console.log($scope.percentage+' ::marks:: '+$scope.userEducationDetails.marks+' ::out of range:: '+$scope.userEducationDetails.out_of_range);
                $scope.userEducationDetails.grades_marks = $scope.userEducationDetails.marks+' out of '+$scope.userEducationDetails.out_of_range+' ('+(Math.round($scope.percentage * 100) / 100)+'%)';
                $scope.educationStatus  = $scope.userEducationDetails.education_status;
                $scope.educationClass   = $scope.statusClass[$scope.educationStatus];
                $scope.userEducationDetails.work_status = ($scope.userEducationDetails.work_status == null)?'N':$scope.userEducationDetails.work_status;
                $scope.userWorkStatus  = $scope.workStatus[$scope.userEducationDetails.work_status];
                $scope.show_in_profile = ($scope.userEducationDetails.show_in_profile == 0)?'No':'Yes';
            }
        }

        $scope.getUserEducationDetailsError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
        }

        if($state.$current.name == 'users.education-edit')
        {
            $scope.getUserEducationDetails();
        }

        $scope.saveEducationInfo = function(userEducationDetails)
        {
            if(userEducationDetails.admin_notes == '' || userEducationDetails.admin_notes == null){
                alert('Please add Admin Notes');
                return false;
            } else{

                if(userEducationDetails.year_of_joining > userEducationDetails.year_of_graduation) {
                    alert('Graduation Year must be greater than Joining Year.');
                } else{

                    userEducationDetails.Neweducation_status= $scope.educationStatus;
                    userEducationDetails.userId             = $rootScope.userId;
                    userEducationDetails.pass_key           = $cookies.get('pass_key');
                    userEducationDetails.admin_user_id      = $cookies.get('admin_user_id');
                    userEducationDetails.educationId        = $rootScope.educationId;
                    ajaxService.ApiCall(userEducationDetails, CONFIG.ApiUrl+'user/saveEducationInfo', $scope.saveEducationInfoSuccess, $scope.saveEducationInfoError, 'post');
                }
            }
        }

        $scope.saveEducationInfoSuccess = function(result, status)
        {
            if(status == 200)
            {
                $window.scrollTo(0, 100);
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
                    $scope.path = "dashboard/users/education/"+$rootScope.userId;
                    $location.path($scope.path);
                }, CONFIG.TimeOut);
            }
        }

        $scope.saveEducationInfoError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
        }

        $scope.changeStatusEducation = function()
        {
            $scope.educationClass = $scope.statusClass[$scope.educationStatus];
        }

        $scope.cancelEducationEdit = function()
        {
            $location.path('dashboard/users/education/'+$rootScope.userId);
        }



        $scope.searchAutoDegree = function(degreeName)
        {
            var degreeParam = {'degree' : degreeName};
            ajaxService.ApiCall(degreeParam, CONFIG.ApiUrl+'user/getDegreeSearch', $scope.searchAutoDegreeSuccess, $scope.searchAutoDegreeError, 'post');        
        }
        $scope.searchAutoDegreeSuccess = function(result,status) 
        {
            if(status == 200){ 
                $scope.degreeSearchDetail = result.raws.data.dataset;
                $scope.degreeSearchCount = result.raws.data.total_count;
            }
        }
        $scope.searchAutoDegreeError = function(result) 
        {
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
        }
        $scope.selectDegree = function(degreeId, degreeName)
        {
            $scope.degreeSearchCount = 0;
            $scope.userEducationDetails.fk_degree_id = degreeId;
            $scope.userEducationDetails.degree_name = degreeName;
        }


        $scope.searchAutoSpecialisation = function(specialisationName)
        {
            var specialisationParam = {'specialisation' : specialisationName};
            ajaxService.ApiCall(specialisationParam, CONFIG.ApiUrl+'user/getSpecialisationSearch', $scope.searchAutoSpecialisationSuccess, $scope.searchAutoSpecialisationError, 'post');        
        }
        $scope.searchAutoSpecialisationSuccess = function(result,status) 
        {
            if(status == 200){ 
                $scope.specialisationSearchDetail = result.raws.data.dataset;
                $scope.specialisationSearchCount = result.raws.data.total_count;
            }
        }
        $scope.searchAutoSpecialisationError = function(result) 
        {
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
        }
        $scope.selectSpecialisation = function(specialisationId, specialisationName)
        {
            $scope.specialisationSearchCount = 0;
            $scope.userEducationDetails.fk_field_of_study_id = specialisationId;
            $scope.userEducationDetails.field_of_study = specialisationName;
        }



        $scope.searchAutoCollege = function(collegeName)
        {
            if(collegeName.length > 2){
                var collegeParam = {'college' : collegeName};
                ajaxService.ApiCall(collegeParam, CONFIG.ApiUrl+'user/getCollegeSearch', $scope.searchAutoCollegeSuccess, $scope.searchAutoCollegeError, 'post');
            }      
        }
        $scope.searchAutoCollegeSuccess = function(result,status) 
        {
            if(status == 200){ 
                $scope.collegeSearchDetail = result.raws.data.dataset;
                $scope.collegeSearchCount = result.raws.data.total_count;
            }
        }
        $scope.searchAutoCollegeError = function(result) 
        {
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
        }
        $scope.selectCollege = function(collegeId, collegeName)
        {
            $scope.collegeSearchCount = 0;
            $scope.userEducationDetails.fk_college_id = collegeId;
            $scope.userEducationDetails.name_of_institution = collegeName;
        }


        

        $scope.doSearchPincode = function(pin_code){            
            var pincodeDataParam = {            
                'pin_code'      : pin_code,
            }
            ajaxService.ApiCall(pincodeDataParam, CONFIG.ApiUrl+'user/getPincodeData', $scope.searchPincodeSuccess, $scope.searchPincodeError, 'post');
        }
        //searchPincode success function
        $scope.searchPincodeSuccess = function(result,status) {
            if(status == 200) {
                blockUI.stop();
                $scope.userEducationDetails.city_name = result.raws.data.city_name;
                $scope.userEducationDetails.state_name = result.raws.data.state_name;
                $scope.userEducationDetails.fk_pincode_id = result.raws.data.id;
            }              
        }
        //searchPincode error function
        $scope.searchPincodeError = function(result,status) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                alert(result.raws.error_message);
                $scope.userEducationDetails.city_name = '';
                $scope.userEducationDetails.state_name = '';
                $scope.userEducationDetails.fk_pincode_id = '';
            }
            blockUI.stop();
        }

        $scope.clearMessage = function()
        {
            $timeout(function() {
                $scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
        }

    }])

    .controller('userKycController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', 'blockUI','$window',"$uibModal", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, blockUI, $window,$uibModal)
    {
        $rootScope.userId   = $stateParams.userId;
        $rootScope.kycId    = $stateParams.kycId;
        $rootScope.kycStatus= $stateParams.kycStatus;
        $scope.kycClass     = 'approve';
        $scope.kycLists     = {};
        $scope.order_by     = "kyc.id";
        $scope.order        = "DESC";
        $scope.documentType = {"A" : "Address Proof", "F" : "Financial Proof", "I" : "Identity Proof", "D" : "Date of birth proof"};
        $scope.statusClass  = {'A' : 'approve', 'P' : 'pending', 'R' : 'decline'};

        $scope.getUserKycLists = function(order_by, order)
        {
            blockUI.start();
            var basicParam = {
                'userId'        : $rootScope.userId,
                'pass_key'      : $cookies.get('pass_key'),
                'admin_user_id' : $cookies.get('admin_user_id'),
                'order_by'      : order_by ? order_by : $scope.order_by,
                'order'         : order ? order : $scope.order
            }
            ajaxService.ApiCall(basicParam, CONFIG.ApiUrl+'user/getUserKycLists', $scope.getUserKycListsSuccess, $scope.getUserKycListsError, 'post');
        }

        $scope.getUserKycListsSuccess = function(result, status)
        {
            if(status == 200)
            {
                $scope.kycLists = result.raws.data.dataset;
                blockUI.stop();
            }
        }

        $scope.getUserKycListsError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
        }

        if($state.$current.name == 'users.kyc')
        {
            $scope.getUserKycLists();
        }

        $scope.getUserKycDetails = function()
        {
            var basicParam = {
                'userId'        : $rootScope.userId,
                'pass_key'      : $cookies.get('pass_key'),
                'admin_user_id' : $cookies.get('admin_user_id'),
                'kycId'         : $rootScope.kycId,
                'kycStatus'     : $rootScope.kycStatus
            }
            ajaxService.ApiCall(basicParam, CONFIG.ApiUrl+'user/getUserKycDetails', $scope.getUserKycDetailsSuccess, $scope.getUserKycDetailsError, 'post');
        }

        $scope.getUserKycDetailsSuccess = function(result, status)
        {
            if(status == 200)
            {
                $scope.userKycDetails = result.raws.data.dataset;
                $scope.userKycDetails.documentType = $scope.documentType[$scope.userKycDetails.document_type];
                $scope.kyccStatus = $scope.userKycDetails.kyc_status;
                $scope.kycClass = $scope.statusClass[$scope.kyccStatus];
            }
        }

        $scope.getUserKycDetailsError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
        }

        if($state.$current.name == 'users.kyc-edit')
        {
            $scope.getUserKycDetails();
        }

        $scope.changeStatusKyc = function()
        {
            $scope.kycClass = $scope.statusClass[$scope.kyccStatus];
        }

        $scope.saveKycInfo = function(userKycDetails)
        {
            if(userKycDetails.admin_notes == '' || userKycDetails.admin_notes == null){
                alert('Please add Admin Notes');
                return false;
            } else {

                if (userKycDetails.existing_count > 0 && $scope.kyccStatus == 'A'){
                    alert('Duplicate KYC ID found in ' + userKycDetails.existing_count + ' record(s)' );
                    return false;
                } else {

                    userKycDetails.Newkyc_status    = $scope.kyccStatus;
                    userKycDetails.userId           = $rootScope.userId;
                    userKycDetails.pass_key         = $cookies.get('pass_key');
                    userKycDetails.admin_user_id    = $cookies.get('admin_user_id');
                    userKycDetails.kycId            = $rootScope.kycId;
                    ajaxService.ApiCall(userKycDetails, CONFIG.ApiUrl+'user/saveKycInfo', $scope.saveKycInfoSuccess, $scope.saveKycInfoError, 'post');
                }
            }
        }

        $scope.saveKycInfoSuccess = function(result, status)
        {
            if(status == 200)
            {
                $window.scrollTo(0, 100);
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
                    $scope.path = "dashboard/users/kyc/"+$rootScope.userId;
                    $location.path($scope.path);
                }, CONFIG.TimeOut);
            }
        }

        $scope.saveKycInfoError = function(result, status)
        {
            $window.scrollTo(0, 100);
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
        }

        $scope.cancelKycEdit = function()
        {
            $location.path('dashboard/users/kyc/'+$rootScope.userId);
        }

        $scope.clearMessage = function()
        {
            $timeout(function() {
                $scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
        }

       $scope.viewImagePopup = function(image)
        {   //console.log(image);
            $rootScope.image = image ? image : '';
            $uibModal.open({
                animation: true,
                templateUrl: 'app/components/users/views/user.modal.details.view.html',
                controllerAs : 'vic',
                controller: 'viewUserImageController',
                bindToController : true
            });
        }

        //open showUserListModalPopup
        $scope.showDuplicateKycListUserModal = function(userKycDetails){
            $rootScope.kycUserId = userKycDetails.fk_user_id;
            $rootScope.searchKey = userKycDetails.kyc_data;

            if(userKycDetails.fk_user_id != '' && userKycDetails.kyc_data != ''){
                $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/users/views/user.duplicate.user.list.modal.view.html',
                    controllerAs : 'dklc',
                    controller: 'duplicateKycListController',
                    bindToController : true
                });
            }
        }


        $scope.checkKYCId = function(userKycDetails)
        {
            var basicParam = {
                'pass_key'      : $cookies.get('pass_key'),
                'admin_user_id' : $cookies.get('admin_user_id'),
                'kyc_data'      : userKycDetails.kyc_data,
                'user_id'       : userKycDetails.fk_user_id
            }
            ajaxService.ApiCall(basicParam, CONFIG.ApiUrl+'user/checkDuplicateKYC', $scope.checkDuplicateKYCSuccess, $scope.checkDuplicateKYCError, 'post');
        }

        $scope.checkDuplicateKYCSuccess = function(result, status)
        {
            if(status == 200)
            {
                $scope.userKycDetails.existing_count = result.raws.data;
            }
        }

        $scope.checkDuplicateKYCError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
        }


    }])

    .controller('userBankController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', 'blockUI', '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, blockUI, $window)
    {
        $rootScope.userId    = $stateParams.userId;
        $rootScope.bankId    = $stateParams.bankId;
        $rootScope.bankStatus= $stateParams.bankStatus;
        $scope.bankClass     = 'approve';
        $scope.bankLists     = {};
        $scope.order_by      = "b.id";
        $scope.order         = "DESC";
        $scope.statusClass   = {'A' : 'approve', 'P' : 'pending', 'R' : 'decline'};

        $scope.getUserBankLists = function(order_by, order)
        {
            blockUI.start();
            var basicParam = {
                'userId'        : $rootScope.userId,
                'pass_key'      : $cookies.get('pass_key'),
                'admin_user_id' : $cookies.get('admin_user_id'),
                'order_by'      : order_by ? order_by : $scope.order_by,
                'order'         : order ? order : $scope.order
            }
            ajaxService.ApiCall(basicParam, CONFIG.ApiUrl+'user/getUserBankLists', $scope.getUserBankListsSuccess, $scope.getUserBankListsError, 'post');
        }

        $scope.getUserBankListsSuccess = function(result, status)
        {
            if(status == 200)
            {
                $scope.bankLists = result.raws.data.dataset;
                blockUI.stop();
            }
        }

        $scope.getUserBankListsError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
        }

        if($state.$current.name == 'users.bank')
        {
            $scope.getUserBankLists();
        }

        $scope.getUserBankDetails = function()
        {
            var basicParam = {
                'userId'        : $rootScope.userId,
                'pass_key'      : $cookies.get('pass_key'),
                'admin_user_id' : $cookies.get('admin_user_id'),
                'bankId'         : $rootScope.bankId,
                'bankStatus'     : $rootScope.bankStatus
            }
            ajaxService.ApiCall(basicParam, CONFIG.ApiUrl+'user/getUserBankDetails', $scope.getUserBankDetailsSuccess, $scope.getUserBankDetailsError, 'post');
        }

        $scope.getUserBankDetailsSuccess = function(result, status)
        {
            if(status == 200)
            {
                $scope.userBankDetails  = result.raws.data.dataset;
                $scope.bankcStatus      = $scope.userBankDetails.bank_status;
                $scope.bankClass        = $scope.statusClass[$scope.bankcStatus];
            }
        }

        $scope.getUserBankDetailsError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
        }

        if($state.$current.name == 'users.bank-edit')
        {
            $scope.getUserBankDetails();
        }

        $scope.changeStatusBank = function()
        {
            $scope.bankClass = $scope.statusClass[$scope.bankcStatus];
        }

        $scope.saveBankInfo = function(userBankDetails)
        {
            userBankDetails.Newbank_status   = $scope.bankcStatus;
            userBankDetails.userId           = $rootScope.userId;
            userBankDetails.pass_key         = $cookies.get('pass_key');
            userBankDetails.admin_user_id    = $cookies.get('admin_user_id');
            userBankDetails.bankId           = $rootScope.bankId;
            ajaxService.ApiCall(userBankDetails, CONFIG.ApiUrl+'user/saveBankInfo', $scope.saveBankInfoSuccess, $scope.saveBankInfoError, 'post');
        }

        $scope.saveBankInfoSuccess = function(result, status)
        {
            if(status == 200)
            {
                $window.scrollTo(0, 100);
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
                    $scope.path = "dashboard/users/bank/"+$rootScope.userId;
                    $location.path($scope.path);
                }, CONFIG.TimeOut);
            }
        }

        $scope.saveBankInfoError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
        }

        $scope.cancelBankEdit = function()
        {
            $location.path('dashboard/users/bank/'+$rootScope.userId);
        }

        $scope.clearMessage = function()
        {
            $timeout(function() {
                $scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
        }
    }])

    .controller('userInterestController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams', '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $stateParams, $window)
    {
        $rootScope.userId = $stateParams.userId;
        $scope.adjustmentDetails = {};

        $scope.getAdjustmentDetails = function()
        {
            var basicParam = {
                'userId'        : $rootScope.userId,
                'pass_key'      : $cookies.get('pass_key'),
                'admin_user_id' : $cookies.get('admin_user_id'),
            };
            ajaxService.ApiCall(basicParam, CONFIG.ApiUrl+'user/getAdjustmentDetails', $scope.getAdjustmentDetailsSuccess, $scope.getAdjustmentDetailsError, 'post');
        }

        $scope.getAdjustmentDetailsSuccess = function(result, status)
        {
            if(status == 200)
            {
                $scope.adjustmentDetails = result.raws.data.dataset;
            }
        }

        $scope.getAdjustmentDetailsError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
        }

        if($state.$current.name == 'users.interest')
        {
            $scope.getAdjustmentDetails();
        }

        $scope.updateInterestDetails = function(adjustmentDetails)
        {
            adjustmentDetails.userId           = $rootScope.userId;
            adjustmentDetails.pass_key         = $cookies.get('pass_key');
            adjustmentDetails.admin_user_id    = $cookies.get('admin_user_id');
            ajaxService.ApiCall(adjustmentDetails, CONFIG.ApiUrl+'user/updateAdjustmentDetails', $scope.updateInterestDetailsSuccess, $scope.updateInterestDetailsError, 'post');
        }

        $scope.updateInterestDetailsSuccess = function(result, status)
        {
            if(status == 200)
            {
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
                    $scope.path = "dashboard/users/interest/"+$rootScope.userId;
                    $location.path($scope.path);
                }, CONFIG.TimeOut);
            }
        }

        $scope.updateInterestDetailsError = function(result, status)
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
        }

        $scope.cancelAdjust = function()
        {
            $location.path('dashboard/users/list');
        }

        $scope.clearMessage = function()
        {
            $timeout(function() {
                $scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
        }

    }])

    .controller('viewUserImageController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "$uibModalInstance","helper", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, $uibModalInstance, helper, $rootScope){
        var vic = this;
        vic.successMessage  = '';
        vic.errorMessage    = '';

        vic.cancel = function(){
            $uibModalInstance.dismiss('cancel');
            //$state.reload();
        }
        $scope.getPopImage = function() 
        {
            $scope.image = $rootScope.image;  
        }
        if($state.$current.name == 'users.basic')
        {
            $scope.getPopImage();
        } 

        
      ///---------------------------    
        return vic;
    }])


    .controller('userFriendsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', '$stateParams', "helper", "$rootScope", "blockUI", '$window', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, $stateParams, helper, $rootScope, blockUI, $window){

        $rootScope.userId           = $stateParams.userId;
        $scope.allUserFriends       = {};
        $scope.pageno               = 1; // initialize page no to 1
        $scope.itemsPerPage         = CONFIG.itemsPerPage; 
        $scope.order_by             = 'profile_update_timestamp';
        $scope.order                = 'desc';
        
        // Perform to getAllUsers action
        $scope.getAllUserFriends = function(pageno, order_by, order)
        { 
            blockUI.start();
            $scope.pageno   = pageno ? pageno : $scope.pageno;
            $scope.order_by = order_by ? order_by : $scope.order_by;
            $scope.order    = order ? order : $scope.order;

            var getUserFriendsParam = 
            {
                'order_by'          : $scope.order_by,
                'order'             : $scope.order,
                'page'              : $scope.pageno,
                'page_size'         : $scope.itemsPerPage,
                'user_id'           : $rootScope.userId,
                'pass_key'          : $cookies.get('pass_key'),
                'admin_user_id'     : $cookies.get('admin_user_id'),
            };
            ajaxService.ApiCall(getUserFriendsParam, CONFIG.ApiUrl+'user/getAllUserFriends', $scope.getAllUserFriendsSuccess, $scope.getAllUserFriendsError, 'post');
        }

        //getAllUserFriends success function
        $scope.getAllUserFriendsSuccess = function(result,status) 
        {
            if(status == 200) 
            {
                $scope.allUserFriends       = result.raws.data.dataset;
                console.log($scope.allUserFriends);
                $scope.total_count          = result.raws.data.count;
                blockUI.stop();
            }
        }

        //getAllUserFriends error function
        $scope.getAllUserFriendsError = function(result, status) 
        {
            if(status == 403)
            {
                helper.unAuthenticate();
            }
            else
            {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
        }

        if($state.$current.name == 'users.friend-list')
        {
            $scope.getAllUserFriends();
        }

        /****************Search START*****************
        /*$scope.$watch('searchByNameEmail', function(tmpStr) 
        {
            if (angular.isUndefined(tmpStr))
            {               
                return 0;
            }
            else if(tmpStr=='')
            {
                $scope.getAllUsers($scope.pageno, $scope.order_by, $scope.order, $scope.searchByNameEmail);
            }
            else
            {
                $timeout(function() 
                { 
                    if (tmpStr === $scope.searchByNameEmail) 
                    {
                        $scope.getAllUsers($scope.pageno, $scope.order_by, $scope.order, $scope.searchByNameEmail);
                    }
                }, 1000);
            }           
        })
        /**************** Search END ******************/

        $scope.clearMessage = function()
        {
            $timeout(function() {
                $scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
        }
    }])


    .controller('duplicateKycListController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', "$uibModalInstance", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $uibModalInstance, $rootScope){
        //var vbdc = this;

        $scope.cancel = function(){
            $uibModalInstance.dismiss('cancel');
        }

        // Perform the exportHistoryIdDetails action
        $scope.duplicateUserList = function(){         

            var duplicateUserListParam = {
                'user_id'           : $rootScope.kycUserId,
                'kyc_data'          : $rootScope.searchKey,
                'pass_key'          : $cookies.get('pass_key'),
                'admin_user_id'     : $cookies.get('admin_user_id')
            };

            ajaxService.ApiCall(duplicateUserListParam, CONFIG.ApiUrl+'user/duplicateUserList', $scope.duplicateUserListSuccess, $scope.duplicateUserListError, 'post');
        }
        $scope.duplicateUserListSuccess = function(result,status) {
            if(status == 200) {
                $scope.successMessage      = result.raws.success_message;
                $scope.duplicateUserList   = result.raws.data.dataset;
                $scope.total_count          = result.raws.data.count;
                
                $scope.clearMessage();  
            }              
        }
        $scope.duplicateUserListError = function(result) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage(); 
            }
        }

        // Perform the clearMessage action
        $scope.clearMessage = function() {
            $timeout(function() {
                $scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
        }
        $scope.duplicateUserList();

    }]);





    ;