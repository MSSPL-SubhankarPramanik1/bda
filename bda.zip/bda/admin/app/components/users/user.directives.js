angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : userListLeftMenu()
    * @ Added Date               : 09-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : user list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 09-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('userListLeftMenu', function() {
        return {
            controllerAs : 'pllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var pllm = this;
                return pllm;
            },
            templateUrl: 'app/components/users/views/user.list.left.menu.html'
        };
    })

    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : userEditLeftMenu()
    * @ Added Date               : 09-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : user list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 09-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('userEditLeftMenu', function() {
        return {
            controllerAs : 'pllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var pllm = this;
                return pllm;
            },
            templateUrl: 'app/components/users/views/user.edit.left.menu.html'
        };
    })
    