angular
	.module('bda')
	.controller('configurationController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, blockUI){

		$scope.allConfigBasicData = {};
		$scope.allConfigMcoinsData = {};
		$scope.allConfigRewardsData = {};
		$scope.allConfigTierUserLevelData = {};
		$scope.allConfigCreditLimitData = {};
		$scope.allConfigCreditScoreData = {};
		
		// Perform to getConfigBasic action
		$scope.getConfigBasic = function(){
			blockUI.start();
	        var getConfigBasicParam = {
	        	'pass_key' 				: $cookies.get('pass_key'),
	        	'admin_user_id'			: $cookies.get('admin_user_id'),	            
	        };
			ajaxService.ApiCall(getConfigBasicParam, CONFIG.ApiUrl+'master_config/getConfigBasic', $scope.getConfigBasicSuccess, $scope.getConfigBasicError, 'post');
		}

		//getConfigBasic success function
		$scope.getConfigBasicSuccess = function(result, status){
		    if(status == 200) {
                $scope.allConfigBasicData 	= result.raws.data;
                blockUI.stop();
		    }		       
		}

		//getConfigBasic error function
		$scope.getConfigBasicError = function(result, status) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if($state.$current.name == 'configuration.basic'){
			$scope.getConfigBasic();
		}

		// Perform the doeditConfigBasic action
		$scope.doeditConfigBasic = function(allConfigBasicData){
        	var allConfigBasicDataParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(allConfigBasicDataParam, allConfigBasicData);

			ajaxService.ApiCall(allConfigBasicDataParam, CONFIG.ApiUrl+'master_config/ediConfigBasic', $scope.editConfigBasicSuccess, $scope.editConfigBasicError, 'post');
		}

		//ediConfigBasic success function
		$scope.editConfigBasicSuccess = function(result, status){
		    if(status == 200){
		    	$scope.successMessage = result.raws.success_message;		    	
				$scope.clearMessage();                
		    }		       
		}

		//ediConfigBasic error function
		$scope.editConfigBasicError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

		/******************************************************************************/

		// Perform to getConfigMcoins action
		$scope.getConfigMcoins = function(){
			blockUI.start();
	        var getConfigBasicParam = {
	        	'pass_key' 				: $cookies.get('pass_key'),
	        	'admin_user_id'			: $cookies.get('admin_user_id'),	            
	        };
			ajaxService.ApiCall(getConfigBasicParam, CONFIG.ApiUrl+'master_config/getConfigMcoins', $scope.getConfigMcoinsSuccess, $scope.getConfigMcoinsError, 'post');
		}

		//getConfigMcoins success function
		$scope.getConfigMcoinsSuccess = function(result, status){
		    if(status == 200) {
                $scope.allConfigMcoinsData 	= result.raws.data;
                blockUI.stop();
		    }		       
		}

		//getConfigMcoins error function
		$scope.getConfigMcoinsError = function(result, status) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if($state.$current.name == 'configuration.mcoins'){
			$scope.getConfigMcoins();
		}


		// Perform the doeditConfigMcoins action
		$scope.doeditConfigMcoins = function(allConfigMcoinsData){
        	var allConfigMcoinsDataParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(allConfigMcoinsDataParam, allConfigMcoinsData);

			ajaxService.ApiCall(allConfigMcoinsDataParam, CONFIG.ApiUrl+'master_config/ediConfigMcoins', $scope.ediConfigMcoinsSuccess, $scope.editConfigMcoinsError, 'post');
		}

		//ediConfigMcoins success function
		$scope.ediConfigMcoinsSuccess = function(result, status){
		    if(status == 200){
		    	$scope.successMessage = result.raws.success_message;		    	
                $scope.clearMessage();
		    }		       
		}

		//ediConfigMcoins error function
		$scope.editConfigMcoinsError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

		/******************************************************************************/

		// Perform to getConfigRewards action
		$scope.getConfigRewards = function(){
			blockUI.start();
	        var getConfigBasicParam = {
	        	'pass_key' 				: $cookies.get('pass_key'),
	        	'admin_user_id'			: $cookies.get('admin_user_id'),	            
	        };
			ajaxService.ApiCall(getConfigBasicParam, CONFIG.ApiUrl+'master_config/getConfigRewards', $scope.getConfigRewardsSuccess, $scope.getConfigRewardsError, 'post');
		}

		//getConfigRewards success function
		$scope.getConfigRewardsSuccess = function(result, status){
		    if(status == 200) {
                $scope.allConfigRewardsData 	= result.raws.data;
                blockUI.stop();
		    }		       
		}

		//getConfigRewards error function
		$scope.getConfigRewardsError = function(result, status) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if($state.$current.name == 'configuration.rewards'){
			$scope.getConfigRewards();
		}


		// Perform the doeditConfigRewards action
		$scope.doeditConfigRewards = function(allConfigRewardsData){
        	var allConfigRewardsDataParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(allConfigRewardsDataParam, allConfigRewardsData);

			ajaxService.ApiCall(allConfigRewardsDataParam, CONFIG.ApiUrl+'master_config/ediConfigRewards', $scope.ediConfigRewardsSuccess, $scope.editConfigRewardsError, 'post');
		}

		//ediConfigRewards success function
		$scope.ediConfigRewardsSuccess = function(result, status){
		    if(status == 200){
		    	$scope.successMessage = result.raws.success_message;		    	
                $scope.clearMessage();
		    }		       
		}

		//ediConfigRewards error function
		$scope.editConfigRewardsError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

		/******************************************************************************/

		// Perform to getConfigTierUserLevel action
		$scope.getConfigTierUserLevel = function(){
			blockUI.start();
	        var getConfigTierUserLevelParam = {
	        	'pass_key' 				: $cookies.get('pass_key'),
	        	'admin_user_id'			: $cookies.get('admin_user_id'),	            
	        };
			ajaxService.ApiCall(getConfigTierUserLevelParam, CONFIG.ApiUrl+'master_config/getConfigTierUserLevel', $scope.getConfigTierUserLevelSuccess, $scope.getConfigTierUserLevelError, 'post');
		}

		//getConfigTierUserLevel success function
		$scope.getConfigTierUserLevelSuccess = function(result, status){
		    if(status == 200) {
                $scope.allConfigTierUserLevelData = result.raws.data;
                blockUI.stop();
		    }		       
		}

		//getConfigTierUserLevel error function
		$scope.getConfigTierUserLevelError = function(result, status) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if($state.$current.name == 'configuration.tier-user-level'){
			$scope.getConfigTierUserLevel();
		}

		// Perform the doeditConfigTierUserLevel action
		$scope.doeditConfigTierUserLevel = function(allConfigTierUserLevelData){

			var jsonString = JSON.stringify(allConfigTierUserLevelData);
			allConfigTierUserLevelData.allConfigTierUserLevelData_str = jsonString;

        	var allConfigTierUserLevelDataParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }

	        angular.extend(allConfigTierUserLevelDataParam, allConfigTierUserLevelData);

			ajaxService.ApiCall(allConfigTierUserLevelDataParam, CONFIG.ApiUrl+'master_config/editConfigTierUserLevel', $scope.editConfigTierUserLevelSuccess, $scope.editConfigTierUserLevelError, 'post');
		}

		//editConfigTierUserLevel success function
		$scope.editConfigTierUserLevelSuccess = function(result, status){
		    if(status == 200){
		    	$scope.successMessage = result.raws.success_message;		    	
                $scope.clearMessage();
		    }		       
		}

		//editConfigTierUserLevelError error function
		$scope.editConfigTierUserLevelError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

	/*************************CREDIT LIMIT*************************************/
	$scope.getConfigCreditlimit = function(){
			blockUI.start();
	        var getConfigCreditlimitParam = {
	        	'pass_key' 				: $cookies.get('pass_key'),
	        	'admin_user_id'			: $cookies.get('admin_user_id'),	            
	        };
			ajaxService.ApiCall(getConfigCreditlimitParam, CONFIG.ApiUrl+'master_config/getCreditLimit', $scope.getConfigCreditlimitSuccess, $scope.getConfigCreditlimitError, 'post');
		}

		//getConfigCreditlimit success function
		$scope.getConfigCreditlimitSuccess = function(result, status){
		    if(status == 200) {
                $scope.allConfigCreditLimitData 	= result.raws.data;
                //console.log($scope.allConfigCreditLimitData);
                blockUI.stop();
		    }		       
		}

		//getConfigCreditlimit error function
		$scope.getConfigCreditlimitError = function(result, status) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if($state.$current.name == 'configuration.creditlimit'){
			$scope.getConfigCreditlimit();
		}

		// Perform the doeditCreditLimit action
		$scope.doeditCreditLimit = function(allConfigCreditLimitData){
        	var allCreditLimitDataParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(allCreditLimitDataParam, allConfigCreditLimitData);

			ajaxService.ApiCall(allCreditLimitDataParam, CONFIG.ApiUrl+'master_config/ediCreditLimit', $scope.editCreditLimitSuccess, $scope.editCreditLimitError, 'post');
		}

		//ediConfigBasic success function
		$scope.editCreditLimitSuccess = function(result, status){
		    if(status == 200){
		    	$scope.successMessage = result.raws.success_message;		    	
				$scope.clearMessage();                
		    }		       
		}

		//ediConfigBasic error function
		$scope.editCreditLimitError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {

                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

	/************************************************************************/

	/*************************CREDIT Score*************************************/
	$scope.getConfigCreditScore = function(){
			blockUI.start();
	        var getConfigCreditScoreParam = {
	        	'pass_key' 				: $cookies.get('pass_key'),
	        	'admin_user_id'			: $cookies.get('admin_user_id'),	            
	        };
			ajaxService.ApiCall(getConfigCreditScoreParam, CONFIG.ApiUrl+'master_config/getCreditScore', $scope.getConfigCreditScoreSuccess, $scope.getConfigCreditScoreError, 'post');
		}

		//getConfigCreditlimit success function
		$scope.getConfigCreditScoreSuccess = function(result, status){
		    if(status == 200) {
                $scope.allConfigCreditScoreData 	= result.raws.data;
                //console.log($scope.allConfigCreditLimitData);
                blockUI.stop();
		    }		       
		}

		//getConfigCreditlimit error function
		$scope.getConfigCreditScoreError = function(result, status) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
            blockUI.stop();
		}

		if($state.$current.name == 'configuration.creditscore'){
			$scope.getConfigCreditScore();
		}

		// Perform the doeditCreditLimit action
		$scope.doeditCreditScore = function(allConfigCreditScoreData){
        	var allCreditScoreDataParam = {			
		        'pass_key'		: $cookies.get('pass_key'),
	        	'admin_user_id' : $cookies.get('admin_user_id')
	        }
	        angular.extend(allCreditScoreDataParam, allConfigCreditScoreData);

			ajaxService.ApiCall(allCreditScoreDataParam, CONFIG.ApiUrl+'master_config/ediCreditScore', $scope.editCreditScoreSuccess, $scope.editCreditScoreError, 'post');
		}

		//ediConfigBasic success function
		$scope.editCreditScoreSuccess = function(result, status){
		    if(status == 200){
		    	$scope.successMessage = result.raws.success_message;		    	
				$scope.clearMessage();                
		    }		       
		}

		//ediConfigBasic error function
		$scope.editCreditScoreError = function(result, status){
            if(status == 403){
                helper.unAuthenticate();
            } else {

                $scope.errorMessage = result.raws.error_message;
                $scope.clearMessage();
            }
		}

	/************************************************************************/



		$scope.clearMessage = function(){
			$timeout(function(){
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, 3000);
		}

	}])	