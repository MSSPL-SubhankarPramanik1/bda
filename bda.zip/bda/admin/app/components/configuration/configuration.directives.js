angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : configurationLeftMenu()
    * @ Added Date               : 08-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : degree type list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 08-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('configurationLeftMenu', function() {
        return {
            controllerAs : 'clm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var clm = this;
                return clm;
            },
            templateUrl: 'app/components/configuration/views/configuration.list.left.menu.html'
        };
    })
    