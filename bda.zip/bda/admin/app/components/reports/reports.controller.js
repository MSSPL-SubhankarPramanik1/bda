angular
	.module('bda')
	.controller('reportsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$window', 'blockUI', function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $window, blockUI){

		/*************** **************** **************** **************** ******************/

		$scope.doExportOpenLoans = function(){ 
			blockUI.start();	        

	        var exportOpenLoansParam = {
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(exportOpenLoansParam, CONFIG.ApiUrl+'reports/getAllOpenLoansList', $scope.exportOpenLoansSuccess, $scope.exportOpenLoansError, 'post');
		}
		$scope.exportOpenLoansSuccess = function(result,status) {
		    if(status == 200) {
		    	window.open(result.raws.data);
            	$scope.successMessage = result.raws.success_message;
            	$scope.clearMessage();  
                blockUI.stop();
		    }
		}
		$scope.exportOpenLoansError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}

		/*************** **************** **************** **************** ******************/

		$scope.doExportVirtualAccounts = function(){ 
			blockUI.start();	        

	        var exportVirtualAccountParam = {
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(exportVirtualAccountParam, CONFIG.ApiUrl+'reports/getAllVirtualAccountList', $scope.exportVirtualAccountSuccess, $scope.exportVirtualAccountError, 'post');
		}
		$scope.exportVirtualAccountSuccess = function(result,status) {
		    if(status == 200) {
		    	window.open(result.raws.data);
            	$scope.successMessage = result.raws.success_message;
            	$scope.clearMessage();  
                blockUI.stop();
		    }
		}
		$scope.exportVirtualAccountError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}
		
		/*************** **************** **************** **************** ******************/

		$scope.doExportLoanTransactions = function(){ 
			blockUI.start();	        

	        var exportLoanTransactionParam = {
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(exportLoanTransactionParam, CONFIG.ApiUrl+'reports/getAllLoanTransactionList', $scope.exportLoanTransactionSuccess, $scope.exportLoanTransactionError, 'post');
		}
		$scope.exportLoanTransactionSuccess = function(result,status) {
		    if(status == 200) {
		    	window.open(result.raws.data);
            	$scope.successMessage = result.raws.success_message;
            	$scope.clearMessage();  
                blockUI.stop();
		    }
		}
		$scope.exportLoanTransactionError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}
		
		/*************** **************** **************** **************** ******************/

		$scope.doExportUsers = function(){ 
			blockUI.start();	        

	        var exportUsersParam = {
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(exportUsersParam, CONFIG.ApiUrl+'reports/getAllUsersList', $scope.exportUsersSuccess, $scope.exportUsersError, 'post');
		}
		$scope.exportUsersSuccess = function(result,status) {
		    if(status == 200) {
		    	window.open(result.raws.data);
            	$scope.successMessage = result.raws.success_message;
            	$scope.clearMessage();  
                blockUI.stop();
		    }
		}
		$scope.exportUsersError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}

		/*************** **************** **************** **************** ******************/

		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, 3000);
		}		
	}])