angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : reportsListLeftMenu()
    * @ Added Date               : 14-04-2016
    * @ Added By                 : Subhankar
    * -----------------------------------------------------------------
    * @ Description              : report list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 01-03-2016
    * @ Modified By              : Subhankar
    * 
    */
    .directive('reportsListLeftMenu', function() {
        return {
            controllerAs : 'rllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var pllm = this;
                return pllm;
            },
            templateUrl: 'app/components/reports/views/reports.list.left.menu.html'
        };
    })
