angular
	.module('bda')
	.controller('collegeController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", "$uibModal", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, helper, $rootScope, $uibModal, blockUI)
	{
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage; 
	    $scope.order_by 			= 'id';
	    $scope.order 				= 'DESC';
	    $scope.searchByCollege 		= '';
	   
	   
		// Perform to getAllCollege action
		$scope.getAllCollege = function(pageno, order_by, order)
		{ // console.log('hhh');
	        $scope.pageno 	= pageno ? pageno : 1;
	       	$scope.order_by = order_by ? order_by : $scope.order_by;
	        $scope.order 	= order ? order : $scope.order;

	        var getPincodeParam = 
	        {
	
	            'searchByCollegeName': $scope.searchByCollege,
	            'order_by'			 : $scope.order_by,
	            'order'				 : $scope.order,
	            'page'				 : $scope.pageno,
	            'page_size'			 : $scope.itemsPerPage,
	            'pass_key'           : $cookies.get('pass_key'),
                'admin_user_id'      : $cookies.get('admin_user_id'),
	        };
			ajaxService.ApiCall(getPincodeParam, CONFIG.ApiUrl+'college/getAllCollege', $scope.getAllCollegeSuccess, $scope.getAllCOllegeError, 'post');
		}

		//getAllPincodes success function
		$scope.getAllCollegeSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.allCollege 	= result.raws.data.dataset;
               // console.log($scope.allCollege);
                $scope.total_count 	= result.raws.data.count;
                //$scope.city_arr 	= result.raws.data.city;
                //$scope.state_arr 	= result.raws.data.state;
		    }		       
		}

		//getAllPincodes error function
		$scope.getAllCollegeError = function(result) 
		{
            if(status == 403)
            {
                helper.unAuthenticate();
            } 
            else 
            {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		/****************Search START******************/
		if($state.$current.name == 'college.list')
		{
			$scope.$watch('searchByCollege', function(tmpStr) 
			{
			    if (angular.isUndefined(tmpStr))
			    {		    	
			        return 0;
			    }
			    else if(tmpStr=='')
			    {
					$scope.getAllCollege($scope.pageno, $scope.order_by, $scope.order, $scope.searchByCollege);
			    }
			    else
			    {
			    	$timeout(function() 
			    	{ 
				        if (tmpStr === $scope.searchByCollege) 
				        {
							$scope.getAllCollege($scope.pageno, $scope.order_by, $scope.order, $scope.searchByCollege);
				        }
				    }, 1000);	
			    }		    
			});
		}
		/**************** Search END ******************/

		
		$scope.clearMessage = function()
		{
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])


	.controller('editCollegeController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "helper", "$rootScope", '$stateParams',"$uibModal", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state,helper, $rootScope, $stateParams,$uibModal)
	{
		//var epc = this;
		$scope.collegeDetail 	= {};
		$scope.collegeId 		= $stateParams.collegeId;
		$scope.successMessage 	= '';
        $scope.errorMessage 	= '';

		// Perform to collegeDetail action
		$scope.getCollegeDetail = function()
		{ 
			var degreeParam = {'collegeId' : $scope.collegeId};
			ajaxService.ApiCall(degreeParam, CONFIG.ApiUrl+'college/getCollegeDetail', $scope.getCollegeDetailSuccess, $scope.getCollegeDetailError, 'post');
		}

		//collegeDetail success function
		$scope.getCollegeDetailSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
		    	//console.log(result.raws.data.dataset);
                $scope.collegeDetail = result.raws.data.dataset;
              
		    }
		}

		//collegeDetail error function
		$scope.getCollegeDetailError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}

		if($state.$current.name == 'college.edit')
		{
			$scope.getCollegeDetail();
		}

		// Perform to updateDegreeDetail action
		$scope.updateCollegeDetail = function(collegeDetail)
		{
			ajaxService.ApiCall(collegeDetail, CONFIG.ApiUrl+'college/updateCollegeDetail', $scope.updateCollegeDetailSuccess, $scope.updateCollegeDetailError, 'post');
		}

		//updateDegreeDetail success function
		$scope.updateCollegeDetailSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                $timeout(function() {
		        	$location.path('dashboard/college/list');
		        }, CONFIG.TimeOut);
		    }
		}

		//updateDegreeDetail error function
		$scope.updateCollegeDetailError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}
		
		$scope.clearMessage = function()
		{
			$timeout(function() 
			{
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}

		//open MergePOPUP
		$scope.doMergePopup = function(college_id){
			$rootScope.college_id 		= college_id ? college_id : '';
			
			$uibModal.open({
				animation: true,
				templateUrl: 'app/components/college/views/college.modal.details.view.html',
				controllerAs : 'cmc',
				controller: 'collegeMergeController',
				bindToController : true
			});
		}


	}])


.controller('collegeMergeController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "$uibModalInstance","helper", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, $uibModalInstance, helper, $rootScope){
		var cmc = this;
		cmc.successMessage 	= '';
		cmc.errorMessage 	= '';

		cmc.cancel = function(){
			$uibModalInstance.dismiss('cancel');
			//$state.reload();
		}

		$scope.getCollegePoPDetail = function()
		{ 
			var collegeParam = {'collegeId' : $rootScope.college_id};
			ajaxService.ApiCall(collegeParam, CONFIG.ApiUrl+'college/getCollegeDetail', $scope.getCollegeDetailPopSuccess, $scope.getCollegePopDetailError, 'post');
		}
		//collegeDetail success function
		$scope.getCollegeDetailPopSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
		    	//console.log(result.raws.data.dataset);
                $scope.collegePopDetail = result.raws.data.dataset;
              
		    }
		}

		//collegeDetail error function
		$scope.getCollegePopDetailError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}
		if($state.$current.name == 'college.edit')
		{
			$scope.getCollegePoPDetail();
		} 
		//console.log($rootScope.college_id); 

		$scope.searchauto = function(a)
		{
			var collegeParam = {'college' : a};
			ajaxService.ApiCall(collegeParam, CONFIG.ApiUrl+'college/getCollegeSearch', $scope.getCollegeSearchSuccess, $scope.getCollegeSearchError, 'post');
		
		}

		$scope.getCollegeSearchSuccess = function(result,status) 
		{
		    if(status == 200) 
		    { 
		    	//console.log(result.raws.data.dataset);
                $scope.collegeSearchDetail = result.raws.data.dataset;
                $scope.collegeSearchCount = result.raws.data.total_count;
              
		    }
		}

		//collegeDetail error function
		$scope.getCollegeSearchError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}
		if($state.$current.name == 'college.edit')
		{
			$scope.getCollegePoPDetail();
		} 

		$scope.selectCollege = function(collegeName)
		{
			$scope.collegeMerge.mergeCollege=collegeName;
			$scope.collegeSearchCount = 0;
		}

		// Update College Merge Details
		$scope.updateMergeDetail = function(collegeDetailMerge)
		{	
			var collegeDetailsId = {};
			collegeDetailsId.college_id = $rootScope.college_id;
			collegeDetailsId.college_name = collegeDetailMerge.mergeCollege;
			ajaxService.ApiCall(collegeDetailsId, CONFIG.ApiUrl+'college/updateCollegeDetailMerge', $scope.updateCollegeMergeDetailSuccess, $scope.updateCollegeMergeDetailError, 'post');
		}
		//updateDegreeDetail success function
		$scope.updateCollegeMergeDetailSuccess = function(result,status) 
		{
		    if(status == 200) 
		    {
                $scope.successMessage = result.raws.success_message;
                $scope.clearMessage();
                cmc.cancel();
                $timeout(function() {
		        	$location.path('dashboard/college/list');
		        }, CONFIG.TimeOut);
		    }
		}

		//updateDegreeDetail error function
		$scope.updateCollegeMergeDetailError = function(result) 
		{
            $scope.errorMessage = result.raws.error_message;
            $scope.clearMessage();
		}
		
		$scope.clearMessage = function()
		{
			$timeout(function() 
			{
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		} 
		
	  ///---------------------------	
		return cmc;
	}]);