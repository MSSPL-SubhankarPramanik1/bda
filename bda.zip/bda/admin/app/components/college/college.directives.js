angular.module('bda')
    /*
    * --------------------------------------------------------------------------
    * @ Directive Name           : pincodeListLeftMenu()
    * @ Added Date               : 21-09-2016
    * @ Added By                 : Piyalee
    * -----------------------------------------------------------------
    * @ Description              : pincode list left menu
    * -----------------------------------------------------------------
    * @ return                   : array
    * -----------------------------------------------------------------
    * @ Modified Date            : 21-09-2016
    * @ Modified By              : Piyalee
    * 
    */
    .directive('collegeListLeftMenu', function() {
        return {
            controllerAs : 'cllm',
            controller : function($timeout, CONFIG, ajaxService, $location){
                var cllm = this;
                return cllm;
            },
            templateUrl: 'app/components/college/views/college.list.left.menu.html'
        };
    })
    