angular
	.module('bda')
	.controller('cash-requestController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', '$state', "$uibModal", "helper", "$rootScope", "blockUI", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $state, $uibModal, helper, $rootScope, blockUI){
		$scope.successMessage 		= '';
		$scope.errorMessage 		= '';
	    $scope.filterByTransferType	= '';
	    $scope.searchByACNoName 	= '';
	    $scope.pageno 				= 1; // initialize page no to 1
	    $scope.itemsPerPage 		= CONFIG.itemsPerPage;			
	    $scope.order_by 			= 'loan_offered_by_user_id';
	    $scope.order 				= 'asc';
	    $scope.allCashRequest 		= {};
	    $scope.search               ={};
		//cashRequestDetailsId ? cashRequestDetailsId : '';
		// Perform to getAllCashRequest action
		$scope.getAllCashRequest = function(pageno, order_by, order){ 
			blockUI.start();
	        $scope.pageno 	= pageno ? pageno : $scope.pageno;
	       	$scope.order_by = order_by ? order_by : $scope.order_by;
	        $scope.order 	= order ? order : $scope.order;
	    
	        $scope.filterByReqStartDate = $scope.search.filterByReqStartDate ? $scope.search.filterByReqStartDate : '';
	        $scope.filterByReqEndDate = $scope.search.filterByReqEndDate ? $scope.search.filterByReqEndDate : '';
	        $scope.profession_type = $scope.search.profession_type ? $scope.search.profession_type : '';
	        $scope.type = $scope.search.type ? $scope.search.type : '';
	        $scope.status = $scope.search.status ? $scope.search.status : '';
	        $scope.transactionIdLenderBorrowerPrinicpalAmount = $scope.search.transactionIdLenderBorrowerPrinicpalAmount ? $scope.search.transactionIdLenderBorrowerPrinicpalAmount : '';

	        //console.log($scope.filterByReqStartDate);
	       // return false;
	        var getAllCashRequestParam = {
	            'filterByTransferType'	: $scope.filterByTransferType,
	            'searchByACNoName'		: $scope.searchByACNoName,
	            'order_by'				: $scope.order_by,
	            'order'					: $scope.order,
	            'page'					: $scope.pageno,
	            'page_size'				: $scope.itemsPerPage,
	            'filterByReqStartDate'  : $scope.filterByReqStartDate,
	            'filterByReqEndDate'    : $scope.filterByReqEndDate,
	            'profession_type'    	: $scope.profession_type,
	            'type'    				: $scope.type,
	            'status'    		    : $scope.status,
	            'transactionIdLenderBorrowerPrinicpalAmount'    : $scope.transactionIdLenderBorrowerPrinicpalAmount,
		        'pass_key'				: $cookies.get('pass_key'),
	        	'admin_user_id' 		: $cookies.get('admin_user_id')
        	}

			ajaxService.ApiCall(getAllCashRequestParam, CONFIG.ApiUrl+'cash_request/getAllCashRequest', $scope.getAllCashRequestSuccess, $scope.getAllCashRequestError, 'post');
		}
		$scope.getAllCashRequestSuccess = function(result,status) {
		    if(status == 200) {
                $scope.allCashRequest 	= result.raws.data.dataset;
                $scope.allProfession 	= result.raws.data.professiona;
               // console.log($scope.allCashRequest);
                $scope.total_count 		= result.raws.data.count;	
                blockUI.stop();
		    }
		}
		$scope.getAllCashRequestError = function(result,status) {
			if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
   			blockUI.stop();
		}			

		if($state.$current.name == 'cash-request.list'){
			$scope.$watch('searchByACNoName', function(tmpStr) {
			    if (angular.isUndefined(tmpStr)){		    	
			        return 0;
			    }else if(tmpStr==''){
					$scope.getAllCashRequest($scope.pageno, $scope.order_by, $scope.order, $scope.searchByACNoName);
			    }else{
			    	$timeout(function() { 
				        if (tmpStr === $scope.searchByACNoName) {
							$scope.getAllCashRequest($scope.pageno, $scope.order_by, $scope.order, $scope.searchByACNoName);
				        }
				    }, 1000);	
			    }		    
			});
		}
		/*************** **************** **************** **************** ******************/

		//open viewExportHistoryPopup
		$scope.CashRequestDetails = function(cashRequestDetailsId){
			$rootScope.cashRequestDetailsId = cashRequestDetailsId ? cashRequestDetailsId : '';

			$uibModal.open({
				animation: true,
				templateUrl: 'app/components/cash-request/views/cash-request.modal.details.view.html',
				controllerAs : 'crdc',
				controller: 'cashRequestDetailsController',
				bindToController : true
			});
		}
		/*************** **************** **************** **************** ******************/


		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
	}])


	.controller('cashRequestDetailsController', ["$scope", 'ajaxService', 'CONFIG', '$location', '$timeout', '$cookies', "$uibModalInstance", "$rootScope", function($scope, ajaxService, CONFIG, $location, $timeout, $cookies, $uibModalInstance, $rootScope){
		//var vbdc = this;

		$scope.cancel = function(){
			$uibModalInstance.dismiss('cancel');
		}

		// Perform the exportHistoryIdDetails action
		$scope.cashRequestIdDetails = function(){			
			var cashIdDetailsParam = {
				'cashrequestId' 	: $rootScope.cashRequestDetailsId,
		        'pass_key'			: $cookies.get('pass_key'),
	        	'admin_user_id' 	: $cookies.get('admin_user_id')
	      	};
			ajaxService.ApiCall(cashIdDetailsParam, CONFIG.ApiUrl+'cash_request/CashRequestDetails', $scope.cashIdDetailsSuccess, $scope.cashIdDetailsError, 'post');
			}
		$scope.cashIdDetailsSuccess = function(result,status) {
		    if(status == 200) {
            	$scope.successMessage 			= result.raws.success_message;
            	$scope.cashRequestDetails 	= result.raws.data;
            	
            	$scope.clearMessage();  
		    }		       
		}
		$scope.cashIdDetailsError = function(result) {
            if(status == 403){
                helper.unAuthenticate();
            } else {
	            $scope.errorMessage = result.raws.error_message;
	            $scope.clearMessage(); 
	        }
		}

		// Perform the clearMessage action
		$scope.clearMessage = function() {
			$timeout(function() {
        		$scope.successMessage = '';
                $scope.errorMessage = '';
            }, CONFIG.TimeOut);
		}
		$scope.cashRequestIdDetails();

	}]);