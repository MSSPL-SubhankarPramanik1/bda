jQuery(function($){

$('a.backToTop').on('click', function(e){
	  e.preventDefault();
	     $('html, body').animate({
	         scrollTop: $("#masthead").offset().top
	     }, 2000);
	 });

		$('a').click(function(e){
			if($(this).attr('href')==''){
				e.preventDefault();
			}
	});



		$('#menuicon').click(function(e){
				


				if($(this).hasClass('activemenu')){
					
						$('#overlay').slideUp(400,function(){

						$('#menu-main-menu').removeAttr('style');
						$('#menuicon').removeClass('activemenu');
						});

				}
				else{

					$('#overlay').css({
									'position':'absolute',
									'top':0,'width':'100%','height':'350px'
								}).slideDown('show');

				$('#menu-main-menu').animate({ "right": "20%",},"slow").css({"position":"absolute",});
				$(this).addClass('activemenu');
				}
		});
	/*	$('#closemenu').click(function(e){
			e.preventDefault();
			
			
		});*/

});
