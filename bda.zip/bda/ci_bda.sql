-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 15, 2017 at 05:30 PM
-- Server version: 5.6.30-0ubuntu0.14.04.1
-- PHP Version: 5.6.23-1+deprecated+dontuse+deb.sury.org~trusty+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci_bda`
--

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `access_token` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `client_id` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `scope` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`access_token`, `client_id`, `user_id`, `expires`, `scope`) VALUES
('50a634cc71495001c4fcc98649969246b8104ece', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:30:23', NULL),
('5c40abd77b63246d066fcca19254977f841c9878', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:30:14', NULL),
('5e89a1c32fe94ef9fbe79713d851489480c67446', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:30:23', NULL),
('626cfdfba792a80eeef106511d489a10e13ab292', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:14:49', NULL),
('68a6f5f875a3cc00b525747b3efb1d414121697d', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:30:14', NULL),
('6f71ce47bfbf7102a3f8b3eb44ee4fbc5d2db9ab', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:14:54', NULL),
('73709cfea75823c51728c15e8ecd1c0078bbf3ac', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:30:18', NULL),
('8c7d72dbc1096d6004fd2e283cc9697f82401aca', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:14:54', NULL),
('c02c77d1ef7ad23dd178d567a4c751bf4b40a641', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:26:12', NULL),
('dae3047b74572fbc29df5018581e8caa1d9b5a92', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:14:36', NULL),
('db021202a4f1513c5094eca2c023cf3ba4138b2e', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:26:11', NULL),
('e0a9ad5fc7e036d8ea05de1cae2fed8aa12f0c9d', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:30:18', NULL),
('eeca325f8a1d5452afe5edc7a56517a58948688d', '9d911a9a00ef11e48aff0019d114582', NULL, '2017-03-15 07:12:34', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_authorization_codes`
--

CREATE TABLE `oauth_authorization_codes` (
  `authorization_code` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `client_id` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `redirect_uri` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `scope` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `client_id` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `client_secret` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `redirect_uri` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `grant_types` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `scope` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`client_id`, `client_secret`, `redirect_uri`, `grant_types`, `scope`, `user_id`) VALUES
('9d911a9a00ef11e48aff0019d114582', '463ceaeab4db11e3aa520019d119645', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_jwt`
--

CREATE TABLE `oauth_jwt` (
  `client_id` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `public_key` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `refresh_token` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `client_id` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `scope` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_scopes`
--

CREATE TABLE `oauth_scopes` (
  `scope` text COLLATE utf8_unicode_ci,
  `is_default` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_sessions`
--

CREATE TABLE `oauth_sessions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `redirect_uri` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type_id` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` enum('user','auto') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user',
  `code` text COLLATE utf8_unicode_ci,
  `access_token` varchar(50) COLLATE utf8_unicode_ci DEFAULT '',
  `stage` enum('request','granted') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'request',
  `first_requested` int(10) UNSIGNED NOT NULL,
  `last_updated` int(10) UNSIGNED NOT NULL,
  `limited_access` tinyint(1) NOT NULL DEFAULT '0'COMMENT
) ;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_session_scopes`
--

CREATE TABLE `oauth_session_scopes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `access_token` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `scope` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_users`
--

CREATE TABLE `oauth_users` (
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admins`
--

CREATE TABLE `tbl_admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `login_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `login_pwd` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `f_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `l_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `has_profile_picture` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'COMMENT
) ;

--
-- Dumping data for table `tbl_admins`
--

INSERT INTO `tbl_admins` (`id`, `login_email`, `login_pwd`, `f_name`, `l_name`, `has_profile_picture`, `file_extension`, `admin_level`, `is_active`, `last_activity_timestamp`, `last_login_timestamp`, `admin_since_timestamp`) VALUES
(1, 'admin@mpokket.com', 'e10adc3949ba59abbe56e057f20f883e', 'Super', 'Admin', 0, 'jpg', 1, 1, '2017-03-15 06:14:54', '2017-03-15 06:14:54', '2016-08-09 14:23:12'),
(2, 'jradmin@mpokket.com', 'e10adc3949ba59abbe56e057f20f883e', 'Jr.', 'Admin', 0, NULL, 2, 1, '2017-02-01 20:00:59', '2017-02-01 20:00:59', '2016-11-03 07:44:32');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_loginsessions`
--

CREATE TABLE `tbl_admin_loginsessions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `fk_admin_id` bigint(20) UNSIGNED NOT NULL,
  `ip_address` varchar(100) NOT NULL COMMENT 'IPv4 or IPv6',
  `browser_session_id` varchar(100) NOT NULL,
  `user_agent` varchar(300) NOT NULL,
  `login_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gps_location` point DEFAULT NULL COMMENT AS `Optional`
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='User Browser Login Session';

--
-- Dumping data for table `tbl_admin_loginsessions`
--

INSERT INTO `tbl_admin_loginsessions` (`id`, `fk_admin_id`, `ip_address`, `browser_session_id`, `user_agent`, `login_timestamp`, `gps_location`) VALUES
(1, 1, '192.168.0.63', '611fb513f435f7b31ecb5cb60542ccdb8de82f82', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:51.0) Gecko/20100101 Firefox/51.0', '2017-03-15 11:44:54', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`access_token`);

--
-- Indexes for table `oauth_authorization_codes`
--
ALTER TABLE `oauth_authorization_codes`
  ADD PRIMARY KEY (`authorization_code`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `oauth_jwt`
--
ALTER TABLE `oauth_jwt`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`refresh_token`);

--
-- Indexes for table `oauth_session_scopes`
--
ALTER TABLE `oauth_session_scopes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `session_id` (`session_id`),
  ADD KEY `scope` (`scope`),
  ADD KEY `access_token` (`access_token`);

--
-- Indexes for table `oauth_users`
--
ALTER TABLE `oauth_users`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `tbl_admin_loginsessions`
--
ALTER TABLE `tbl_admin_loginsessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_session` (`fk_admin_id`,`browser_session_id`),
  ADD KEY `current_timezone_id` (`gps_location`(25));

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `oauth_sessions`
--
ALTER TABLE `oauth_sessions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oauth_session_scopes`
--
ALTER TABLE `oauth_session_scopes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_admins`
--
ALTER TABLE `tbl_admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_admin_loginsessions`
--
ALTER TABLE `tbl_admin_loginsessions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
