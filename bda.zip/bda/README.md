bda Build on 21-Dec-2016

Android Build:
Version code: 100022
Version name: 1.0.6

iOS Build:
Version name: 1.0.6
Build: 1
