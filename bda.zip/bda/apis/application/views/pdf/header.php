<div class="header_sec">			
	<div class="header_sec_part logo_header"><a href="#"><img src="<?php echo base_url(); ?>assets/images/email_logo.png"></a></div>
	
	
</div>