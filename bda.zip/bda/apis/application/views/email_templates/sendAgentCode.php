<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>.:Agent code:bda:.</title>
</head>

<body>
	<table width="600" border="0" cellspacing="0" cellpadding="0" align="center" style="border:1px solid #995A30;">
	<tr>
		<td  width="100%"  style="background:#000; padding:5px; height:70px;vertical-align:middle;">
                    <img src="https://apis.finzo.in/assets/images/emailLogo.png" alt="logo" border="0"/> </td>
	  </tr>
	  <tr>
		<td width="100%"  style="padding:10px;font-family:Arial; font-size:14px; color:#444444;">&nbsp;
			<h2 style="margin:0;padding:0;font-size:14px;">Hi </h2>
			
                        <p>
                    
                            Please check your Agent code for registration. <br />
                           
                            Agent code - {agent_code}
                        </p>
                        
		</td>
	  </tr>
	  
	    <tr>
		<td  width="100%"  style="background:#000; color:#fff; padding:10px;font-family:Arial; font-size:14Px; height:60px;padding-top:30px;">
		&nbsp;Regards,<br />
		&nbsp;bda Team
		</td>
	  </tr>
	</table>

</body>
</html>

