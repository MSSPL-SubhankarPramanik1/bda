<?php
$config['test_api_ver'] = '2_0_0';
$config['admin_email'] = 'noreply@bda.com';
$config['info_email'] = 'info@bda.com';
$config['contact_email'] = 'subhankar.pramanik@massoftind.com';	//'admin@bda.com';
$config['admin_email_from'] = 'bda';
$config['site_title'] = 'bda';
$config['http_response_bad_request']='400';
$config['http_response_invalid_login']='403';
$config['http_response_unauthorized']='401';
$config['http_response_not_found']='404';
$config['http_response_ok']='200';
$config['http_response_ok_no_content']='204';
$config['passcode_validity']='15';
$config['oauth_db_host']='localhost';
$config['oauth_db_database']='ci_bda';
$config['oauth_db_username']='root';
$config['oauth_db_password']='Mass4Pass';
$config['site_mode']='staging';
$config['temp_upload_file_path']='/var/www/html/bda/apis/assets/tmp_uploads/';
$config['upload_file_url'] = '/var/www/html/apis/assets/resources/';
$config['bucket_url']='https://bdalive.s3.ap-south-1.amazonaws.com/resources/';
$config['export_url']='https://bdalive.s3.ap-south-1.amazonaws.com/export';
$config['file_url'] = "http://".$_SERVER['SERVER_NAME']."/apis/assets/resources/";
$config['protocol']    = 'smtp';
$config['smtp_host']    = 'email-smtp.us-west-2.amazonaws.com';
$config['smtp_port']    = '587';
$config['smtp_crypto']='tls';
$config['smtp_user']    = 'AKIAJ77XL2KI7GIA3KAQ';
$config['smtp_pass']    = 'Ah64mE19mUZVBxIHYFKy+Z0mjTYxVFDCphWZ0d0W45nS';
$config['charset']         = 'utf-8';
$config['wordwrap']        = TRUE;
$config['mailtype']        = 'html';
$config['newline']      = "\r\n"; 

?>