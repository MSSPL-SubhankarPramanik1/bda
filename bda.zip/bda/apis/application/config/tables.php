<?php
//all the table sare define here
$config['tables'] = array();
$config['tables']['master_tbl_timezones'] 	= 'master_tbl_timezones';
$config['tables']['tbl_users'] 				= 'tbl_users';
$config['tables']['tbl_user_blocks']   		= 'tbl_user_blocks';
$config['tables']['tbl_user_friends']    	= 'tbl_user_friends';
$config['tables']['tbl_user_loginkeys']		= 'tbl_user_loginkeys';
$config['tables']['tbl_user_mobile_devices']= 'tbl_user_mobile_devices';
$config['tables']['tbl_user_notifications'] = 'tbl_user_notifications';
$config['tables']['tbl_user_passcodes'] 	= 'tbl_user_passcodes';
$config['tables']['tbl_user_push_messages'] = 'tbl_user_push_messages';
$config['tables']['tbl_user_requests'] 		= 'tbl_user_requests';









// For Admin Website
$config['tables']['tbl_admins'] 				= 'tbl_admins';
$config['tables']['tbl_admin_pwd_reset_codes'] 	= 'tbl_admin_pwd_reset_codes';
$config['tables']['tbl_admin_loginsessions'] 	= 'tbl_admin_loginsessions';
$config['tables']['master_agent_codes'] 		= 'master_agent_codes';
$config['tables']['tbl_user_agent_codes'] 		= 'tbl_user_agent_codes';
$config['tables']['tbl_user_profile_basics'] 	= 'tbl_user_profile_basics';
$config['tables']['master_profession_types'] 	= 'master_profession_types';
$config['tables']['master_payment_types'] 		= 'master_payment_types';
$config['tables']['master_products'] 			= 'master_products';
$config['tables']['master_product_variants'] 	= 'master_product_variants';
$config['tables']['master_mcoin_activities'] 	= 'master_mcoin_activities';
$config['tables']['master_mcoin_earnings'] 		= 'master_mcoin_earnings';
$config['tables']['master_reward_activities'] 	= 'master_reward_activities';
$config['tables']['master_reward_earnings'] 	= 'master_reward_earnings';
$config['tables']['master_user_levels'] 		= 'master_user_levels';
$config['tables']['master_tier_usage_fee_discounts'] 		= 'master_tier_usage_fee_discounts';
$config['tables']['master_product_credit_rating_benefits'] 	= 'master_product_credit_rating_benefits';
$config['tables']['master_degrees'] 			= 'master_degrees';
$config['tables']['tbl_user_tmp_profile_basics']= 'tbl_user_tmp_profile_basics';
$config['tables']['tbl_history_user_profile_basics'] 		= 'tbl_history_user_profile_basics';
$config['tables']['tbl_user_types'] 			= 'tbl_user_types';
$config['tables']['master_banks'] 				= 'master_banks';



?>