<?php
/* * ******************************************************************
 * User model for Mobile Api 
  ---------------------------------------------------------------------
 * @ Added by                 : Mousumi Bakshi 
 * @ Framework                : CodeIgniter
 * @ Added Date               : 01-09-2016
  ---------------------------------------------------------------------
 * @ Details                  : It Cotains all the api related mcoins
  ---------------------------------------------------------------------
 ***********************************************************************/
class Creditscore_model extends CI_Model
{

    public $_table_user = 'tbl_users';
    public $_tbl_user_profile_education = 'tbl_user_profile_educations';
    public $_tbl_master_degree = 'master_degrees';
    public $_table = 'master_configurations';
    public $_tbl_degree_credit_score = 'tbl_credit_scores';
    public $_tbl_user_credit_score = 'tbl_user_credit_scores';
    public $_tbl_user_social_login = 'tbl_user_social_logins';
    
    public $_tbl_user_profile_basics = 'tbl_user_profile_basics';
    public $_master_city_credit_scores = 'master_city_credit_scores';
    public $_master_pincodes = 'master_pincodes';
    public $_master_colleges = 'master_colleges';
    
    public $_master_genders = 'master_genders';
    public $_tbl_user_credit_scores = 'tbl_user_credit_scores';

    public $_tbl_user_loan_repayment_schedule = 'tbl_user_loan_repayment_schedules';
    public $_tbl_user_loan = 'tbl_user_loans';
    public $_tbl_user_loan_disbursement = 'tbl_user_loan_disbursement'; 
    public $_tbl_cron_credit_limit = 'tbl_cron_credit_limit'; 
    public $_tbl_user_credit_rating = 'tbl_user_credit_ratings'; 

    
     
    function __construct()
    {
       
        //load the parent constructor
        parent::__construct();        
         
    }
    
    public function update($table = '', $where = array(), $param = array())
   {  
        $this->db->where($where);
        $this->db->update($table, $param);
       // echo $this->db->last_query(); exit;
        $affected_rows = $this->db->affected_rows(); 

        return $affected_rows;
    }

    public function getMasterCreditScore()
    {
        $credit_score=array();
        $configurationDTl=$this->db->get($this->_table)->row_array();
      
        if(is_array($configurationDTl) && count($configurationDTl)){
            $credit_score_json=$configurationDTl['credit_score_json'];
            $credit_score=json_decode($credit_score_json,true);
        }

        return $credit_score;
        
    }

    public function getCreditScoreMaster()
    {
       
        $credit_score=$this->db->get($this->_table)->row_array();
        return $credit_score;
        
    }
    
    public function getUserCreditScore($user_id)
    {
        $credit_user_score=array();
        if($user_id>0){
            $this->db->where('fk_user_id',$user_id);
            $credit_user_score=$this->db->get($this->_tbl_user_credit_score)->row_array();
        }
        return $credit_user_score;
    }

    public function getUserSocialLoginDetails($user_id){
        $user_social_login=array();
        $this->db->where('fk_user_id',$user_id);
        $user_social_login=$this->db->get($this->_tbl_user_social_login)->row_array();
        return $user_social_login;
    }

    

    public function getusercity($user_id)
    {
        $this->db->select($this->_master_pincodes.'.*');
        $this->db->join($this->_tbl_user_profile_basics,$this->_master_pincodes.'.city_name='.$this->_tbl_user_profile_basics.'.permanent_city');
        $this->db->where($this->_tbl_user_profile_basics.'.fk_user_id =',$user_id);
        $cityScore = $this->db->get($this->_master_pincodes)->row_array();
         return $cityScore;
    }

    public function getuserGender($user_id)
    {
        $this->db->select($this->_master_genders.'.*');
        $this->db->join($this->_tbl_user_profile_basics,$this->_master_genders.'.id='.$this->_tbl_user_profile_basics.'.fk_gender_id');
        $this->db->where($this->_tbl_user_profile_basics.'.fk_user_id =',$user_id);
        $Getgender = $this->db->get($this->_master_genders)->row_array();

        return $Getgender;
    }

    public function getnoTimesLoanRepaymentBeforDueDate($user_id){
        $this->db->select('id');
        $this->db->where('payment_status','4-P');
        $this->db->where($this->_tbl_user_loan.'.fk_user_id',$user_id);
        $this->db->where('actual_payment_date <=','scheduled_payment_date');
        $this->db->join($this->_tbl_user_loan_repayment_schedule,$this->_tbl_user_loan.'.id='.$this->_tbl_user_loan_repayment_schedule.'.fk_user_loan_id');
        $this->db->from($this->_tbl_user_loan);
        return $this->db->count_all_results(); 
    }

    public function getnoOfClosedLoans($user_id){

        $this->db->select('id');
        $this->db->where('payment_status','4-P');
        $this->db->where($this->_tbl_user_loan.'.fk_user_id',$user_id);
        $this->db->join($this->_tbl_user_loan_repayment_schedule,$this->_tbl_user_loan.'.id='.$this->_tbl_user_loan_repayment_schedule.'.fk_user_loan_id');
        $this->db->from($this->_tbl_user_loan);
        return $this->db->count_all_results(); 

    }

    public function getnoOfOpenLoasPastDue($user_id){
        $this->db->select('id');
        $this->db->where('payment_status','1_O');
        $this->db->where($this->_tbl_user_loan.'.fk_user_id',$user_id);
        $this->db->join($this->_tbl_user_loan_repayment_schedule,$this->_tbl_user_loan.'.id='.$this->_tbl_user_loan_repayment_schedule.'.fk_user_loan_id');
        $this->db->from($this->_tbl_user_loan);
        return $this->db->count_all_results(); 

    }

    public function getvalueoftransactionmultiplier($userid)
    {
        $this->db->select('sum(borrower_da) as borrower');
        $this->db->join($this->_tbl_user_loan.' as loanuser','loanuser.id = loanvariants.fk_user_loan_id');
        $this->db->where('loanuser.fk_user_id',$userid);
        $res=$this->db->get($this->_tbl_user_loan_disbursement.' as loanvariants');
        return $res->row_array();    
    }

    public function isAddedCronCredit($user_id){
        $this->db->select('id');
        $this->db->where('cron_status','U');
        $this->db->where('fk_user_id',$user_id);
           $this->db->from($this->_tbl_cron_credit_limit);
        return $this->db->count_all_results(); 
    }

    public function addCronCredit($params){
  
        $this->db->insert($this->_tbl_cron_credit_limit,$params);
        $insert_id = $this->db->insert_id();
        return $insert_id;
       
    }

    public function getCronvalue()
    {
        $this->db->select('*');
        $this->db->where('cron_status','U');
        $res=$this->db->get($this->_tbl_cron_credit_limit);
        return $res->result_array();     
    }


    // -----------------------------------main methods ------------------------------------

    public function updateCronCredit($user_id){
        $is_add=$this->isAddedCronCredit($user_id);
        if($is_add==0){
            $cron_credit=array();
            $cron_credit['fk_user_id']=$user_id;
            $cron_credit['cron_status']='U';
            $this->addCronCredit($cron_credit);
        }

    }

    public function updateEducationScore($user_id,$education_id)
    {
        $user_credit_score=$this->getUserCreditScore($user_id);

        $this->db->select($this->_tbl_master_degree.'.degree_name, '.$this->_tbl_user_profile_education.'.*');
        $this->db->join($this->_tbl_master_degree,$this->_tbl_user_profile_education.'.fk_degree_id='.$this->_tbl_master_degree.'.id');
        $this->db->where('fk_user_id',$user_id);
        $this->db->from($this->_tbl_user_profile_education);
        $educationdetails= $this->db->get()->row_array();

        $degree=$educationdetails['degree_name'];
        $grades_marks=$educationdetails['grades_marks'];
        $name_of_institution=$educationdetails['name_of_institution'];

        $credit_score=$this->getMasterCreditScore();
        //degree/ professional education
        $weg_pe_cat1=$credit_score['professional_education']['w1'];
        $weg_pe_cat2=$credit_score['professional_education']['w2'];

        $this->db->where('degree_name',$degree);
        $isDegree=$this->db->get($this->_tbl_master_degree)->row_array();
        $pe=0;
        if($user_credit_score['ph']>0){
            $pe=$user_credit_score['ph'];
        }
        if(is_array($isDegree) && count($isDegree)>0){
            $degree_category=$isDegree['category'];
            //checking category
            if($degree_category=='CAT1' && $weg_pe_cat1>0){
                $wegpecat1=($weg_pe_cat1*1000)/100;
                $pe=$pe+$wegpecat1;
            }else if($degree_category=='CAT2' && $weg_pe_cat2>0){
                $wegpecat2=($weg_pe_cat2*1000)/100;
                $pe=$pe+$wegpecat2;
            }

        }
        //Grades
        $weg_gr_1=$credit_score['grades']['w1'];
        $weg_gr_2=$credit_score['grades']['w2'];
        $weg_gr_3=$credit_score['grades']['w3'];

        $gr=0;
        if($user_credit_score['gr']>0){
            $gr=$user_credit_score['gr'];
        }

        
        if($grades_marks>80 && $weg_gr_1>0){
            $weggr1=($weg_gr_1*1000)/100;
            $gr=$gr+$weggr1;
        }else if($grades_marks>50 && $grades_marks<80 && $weg_gr_2>0){
            $weggr2=($weg_gr_2 * 1000)/100;
            $gr=$gr+$weggr2;
        }else{
            $weggr3=($weg_gr_3 * 1000)/100;
            $gr=$gr+$weggr3;
        }
        //college
        $weg_colg_cate1=$credit_score['college']['w1'];
        $weg_colg_cate2=$credit_score['college']['w2'];
        $weg_colg_cate3=$credit_score['college']['w3'];

        $col=0;
        if($user_credit_score['col']>0){
            $col=$user_credit_score['col'];
        }

        $this->db->where('college_name',$name_of_institution);
        $isCollege=$this->db->get($this->_master_colleges)->row_array();
        if(is_array($isDegree) && count($isDegree)>0){
            $college_category=$isDegree['category'];

            if($college_category=='CAT1'){
                $wegcolgcate1=($weg_colg_cate1*1000)/100;
                $col=$col+$wegcolgcate1;
            }
            if($college_category=='CAT2'){
                $wegcolgcate2=($weg_colg_cate2*1000)/100;
                $col=$col+$wegcolgcate2;
            }
            if($college_category=='CAT3'){
                $wegcolgcate3=($weg_colg_cate3*1000)/100;
                $col=$col+$wegcolgcate3;
            }
        }
        //update credit ph
        if(($pe!=$user_credit_score['ph']) || ($col!=$user_credit_score['col']) || ($gr!=$user_credit_score['gr'])){

            $update_cs['pf']=$pe;
            $update_cs['col']=$col;
            $update_cs['gr']=$gr;


            $update = $this->update($this->_tbl_user_credit_scores,array('fk_user_id'=>$user_id),$update_cs);

            $getUpdateMain = $this->updateMainCreditScore($user_id);
            //update cron table
            $is_added=$this->isAddedCronCredit($user_id);
            if($is_added==0){
                $cron_credit=array();
                $cron_credit['fk_user_id']=$user_id;
                $cron_credit['cron_status']='U';
                $this->addCronCredit($cron_credit);
            }
        }

    }

    public function updateSocialLoginDetails($user_id){
        $user_credit_score=$this->getUserCreditScore($user_id);

        $social_details=$this->getUserSocialLoginDetails($user_id);
        $sl=0;
        if(is_array($social_details) && count($social_details))
        {

            $facebook_login_id=$social_details['facebook_login_id'];
            $twitter_account_id=$social_details['twitter_account_id'];
            $linkedin_account_id=$social_details['linkedin_account_id'];
            $googleplus_account_id=$social_details['googleplus_account_id'];
            $no_sl=0;

            if($facebook_login_id!='' && $facebook_login_id!=NULL){
                $no_sl++;
            }else if($googleplus_account_id!='' && $googleplus_account_id!=NULL){
                $no_sl++;
            }else if($linkedin_account_id!='' && $linkedin_account_id!=NULL){
                $no_sl++;
            }else if($twitter_account_id!='' && $twitter_account_id!=NULL){
                $no_sl++;
            }
            
            if($no_sl>1)
            {
                $sl=1000;
            }
            else
            {
                if($facebook_login_id!='' && $facebook_login_id!=NULL)
                {
                    $sl=500;
                }else if($googleplus_account_id!='' && $googleplus_account_id!=NULL)
                {
                    $sl=500;
                }else if($linkedin_account_id!='' && $linkedin_account_id!=NULL)
                {
                    $sl=1000;
                }else if($twitter_account_id!='' && $twitter_account_id!=NULL)
                {
                    $sl=500;
                }
            }
        } // end of if

       // print_r($user_credit_score); exit;
        //update credit
        if($sl != $user_credit_score['sl']){
            $update_cs['sl']=$sl;
           
            $update = $this->update($this->_tbl_user_credit_scores,array('fk_user_id'=>$user_id),$update_cs);

            $getUpdateMain = $this->updateMainCreditScore($user_id);
            //update cron table
            $is_added=$this->isAddedCronCredit($user_id);
            if($is_added==0){
                $cron_credit=array();
                $cron_credit['fk_user_id']=$user_id;
                $cron_credit['cron_status']='U';
                $this->addCronCredit($cron_credit);
            }

            
        }
        
    }

    

    public function updateUserprofilecity($user_id)
    {  

        $user_credit_score=$this->getUserCreditScore($user_id);

        $cityScore = $this->getusercity($user_id);
        $getgender = $this->getuserGender($user_id);
    
         $update_cs = array();
         $result = '';
         if(count($cityScore) > 0)
         {  

            $mastescore=$this->getMasterCreditScore();

            if($cityScore['category']=='CAT1')
            {
               
                if($mastescore['city']['w1'] > 0)
                {   
                    $result = ($mastescore['city']['w1']/100)*1000;
                }
                else
                { 
                    $result = (0)*1000;
                }
            }
            if($cityScore['category']=='CAT2')
            {
                if($mastescore['city']['w2'] > 0)
                {
                    $result = ($mastescore['city']['w2']/100)*1000;
                }
                else
                {
                    $result = (0)*1000;
                }
            }
         }
         else
         {
             $result = 0;
         }
         $update_cs['city'] = round($result);

         $gender = '';
         if(count($getgender) > 0)
         {  
            if($getgender['gender']=='Male')
            {
                $gender = 0;
            }
            else
            {
                $gender = 1000;
            }
         }
         else
         {
            $gender = 0;
         }

        $update_cs['gdr'] = $gender;

        $update = $this->update($this->_tbl_user_credit_scores,array('fk_user_id'=>$user_id),$update_cs);

        $getUpdateMain = $this->updateMainCreditScore($user_id);

        if(($gender!=$user_credit_score['gdr']) || ($result!=$user_credit_score['city'])){
            //update cron table
            $is_added=$this->isAddedCronCredit($user_id);
            if($is_added==0){
                $cron_credit=array();
                $cron_credit['fk_user_id']=$user_id;
                $cron_credit['cron_status']='U';
                $this->addCronCredit($cron_credit);
            }
        }

    }

    public function updatePaymentHistory($user_id)
    {
        $row = $this->getMasterCreditScore();

        $noTimesLoanRepaymentBeforDueDate=$this->getnoTimesLoanRepaymentBeforDueDate($user_id);
      
        $noClosedLoans=$this->getnoOfClosedLoans($user_id);
          
        $noOpenLoansPastDue=$this->getnoOfOpenLoasPastDue($user_id);

        if(($noTimesLoanRepaymentBeforDueDate==0) && ($noClosedLoans==0) && ($noOpenLoansPastDue==0) )
        {
            $OTP = 0;
            $WWP = 0;
        }
        else
        {   

            $OTP = ($noTimesLoanRepaymentBeforDueDate /($noClosedLoans + $noOpenLoansPastDue))*1000;

            $WWP = (($noTimesLoanRepaymentBeforDueDate + $row['payment_history']['payment_window'])/($noClosedLoans + $noOpenLoansPastDue + $row['payment_history']['payment_window'])) * 1000;
        }
        
        /*NUM*/
        $NUM = $noClosedLoans * $row['payment_history']['transaction_ceiling_factor'];
          
        $getvtm = $this->getvalueoftransactionmultiplier($user_id);
        if(!empty($getvtm['borrower']))
        {
           if($row['payment_history']['value_ceiling_factor']!=0)
           {
            $VCF = ($getvtm['borrower'] / $row['payment_history']['value_ceiling_factor']);
           }
           else
           {
             $VCF = ($getvtm['borrower'] / 1);
           }
            
        }
        else
        {
            $VCF = 0; 
        }
        
         //echo $OTP."<---WWP>".$WWP."<----NUM>".$NUM."<-----VCF>".$VCF; exit;

        $PH = (($row['payment_history']['w1']/100)*$OTP) + (($row['payment_history']['w2']/100)*$WWP) + (($row['payment_history']['w3']/100)*$NUM) + (($row['payment_history']['w4']/100)*$VCF);


        $update_ph['ph'] = round($PH);

        $update = $this->update($this->_tbl_user_credit_scores,array('fk_user_id'=>$user_id),$update_ph);
 

         $getUpdateMain = $this->updateMainCreditScore($user_id);
         //update cron table
            $is_added=$this->isAddedCronCredit($user_id);
            if($is_added==0){
                $cron_credit=array();
                $cron_credit['fk_user_id']=$user_id;
                $cron_credit['cron_status']='U';
                $this->addCronCredit($cron_credit);
            }

       
    }

    public function updateMainCreditScore($user_id)
    {
        $this->db->select('*');
        $this->db->where('fk_user_id',$user_id);
        $result = $this->db->get($this->_tbl_user_credit_scores)->row_array();
        $update_row = array();
        if(count($result) > 0)
        {  
            $row = $this->getMasterCreditScore();
           

            $tot = (($row['credit_score']['w1']/100)*$result['ph']) + (($row['credit_score']['w2']/100)*$result['col']) + (($row['credit_score']['w3']/100)*$result['gr']) + (($row['credit_score']['w4']/100)*$result['city']) + (($row['credit_score']['w5']/100)*$result['gdr']) + (($row['credit_score']['w6']/100)*$result['pf'])  + (($row['credit_score']['w7']/100)*$result['sl']);

            $update_row['cs'] = round($tot); 
            
        }
        else
        {
            $update['cs'] = 0;
        }
        $up = $this->update($this->_tbl_user_credit_scores,array('fk_user_id'=>$user_id),$update_row);
       
        return $up;
    }

    public function getCreditLimit($user_id){
        $this->db->where('fk_user_id',$user_id);
        $this->db->from($this->_tbl_user_credit_rating);
        $res=$this->db->get($this->_tbl_user_credit_rating);
        return $res->row_array(); 
    }


}