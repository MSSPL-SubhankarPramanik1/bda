<?php
/* * ******************************************************************
 * Creditrating_model for Mobile Api 
  ---------------------------------------------------------------------
 * @ Added by                 : Ritesh Kumar 
 * @ Framework                : CodeIgniter
 * @ Added Date               : 23-11-2016
  ---------------------------------------------------------------------
 * @ Details                  : It Cotains all the api related methods
  ---------------------------------------------------------------------
 ***********************************************************************/
class Creditrating_model extends CI_Model
{
	 public $_table = 'tbl_users';
     public $_table_device = 'tbl_user_mobile_devices';
     public $_table_loginkey = 'tbl_user_loginkeys';
     public $_table_verification_code = 'tbl_user_verification_codes';
     public $_table_user_type = 'tbl_user_types';
     public $_master_profession_type = 'master_profession_types';
     public $_table_pwd_reset = 'tbl_user_pwd_reset_codes';
     public $_table_profile_basics = 'tbl_user_profile_basics';
     public $_table_social_login = 'tbl_user_social_logins';
     public $_table_timezone = 'master_timezones';
     public $_master_gender = 'master_genders';
     public $_tbl_user_referal = 'tbl_user_referals';
     public $_tbl_user_basic = 'tbl_user_profile_basics';
     public $_tbl_mcoin_earning = 'master_mcoin_earnings';
     public $_tbl_user_mcoins_earning = 'tbl_user_mcoins_earnings';
     public $_tbl_history_user_email = 'tbl_history_user_emails';
     public $_tbl_history_user_mobile_number = 'tbl_history_user_mobile_numbers';
     public $_tbl_user_level = 'tbl_user_levels';
     public $_table_user_approval = 'tbl_user_approvals';
     public $_table_admin_data_collection = 'tbl_admin_data_collections';
     public $_table_tbl_timezone = 'master_tbl_timezones';

     public $_tbl_bda_funds = 'tbl_bda_funds';
     public $_tbl_user_bda_accounts = 'tbl_user_bda_accounts';

	 function __construct()
    {
       
        //load the parent constructor
        parent::__construct();        
         
    }



public function getnooftransaction($userid)
{
 

   // $sql = "SELECT COUNT('bdafund.id') AS `numrows` FROM `tbl_bda_funds` as `bdafund` JOIN `tbl_user_bda_accounts` as `mpktaccount` ON `mpktaccount`.`id` = `bdafund`.`fk_user_bda_account_id` WHERE    `bdafund`.`transfer_type` = 'P' And `mpktaccount`.`fk_user_id` =".$userid;
     $sql="SELECT COUNT('id') AS `numrows` FROM `tbl_cash_transfers` where `payer_id` =".$userid;
    
    $query=$this->db->query($sql);
    return $query->row_array();
   
    /*$this->db->where($where);
	$this->db->where('bdafund.transfer_type','R');
	$this->db->or_where('bdafund.transfer_type','P');
	$this->db->where('mpktaccount.fk_user_id',$userid);
	$this->db->from('tbl_bda_funds as bdafund');
     $sql = "SELECT COUNT('bdafund.id') AS `numrows` FROM `tbl_bda_funds` as `bdafund` JOIN `tbl_user_bda_accounts` as `mpktaccount` ON `mpktaccount`.`id` = `bdafund`.`fk_user_bda_account_id` WHERE (`bdafund`.`transfer_type` = 'R' OR `bdafund`.`transfer_type` = 'P' ) And `mpktaccount`.`fk_user_id` =".$userid;
    return $this->db->count_all_results(); */
}


public function getnoofconnection($userid)
{
   $sql ="SELECT COUNT('userconn.id') AS `numrows` FROM `tbl_user_connections` as `userconn` WHERE `userconn`.`connection_status` = 'C' AND (`userconn`.`fk_user_id` = ".$userid." OR `userconn`.`fk_connection_id` = ".$userid.")";
    $query=$this->db->query($sql);
    return $query->row_array();
	/*$this->db->select('*');
	$this->db->where('userconn.connection_status','C');
	$this->db->or_where('userconn.fk_user_id',$userid);
	$this->db->or_where('userconn.fk_connection_id',$userid);
	$this->db->from('tbl_user_connections as userconn');
    return $this->db->count_all_results(); */
}

public function getnocoins($userid)
{
    $sql = 'SELECT IFNULL(total_mcoin_points, "0") as total_mcoin_points FROM `tbl_user_levels` as `userlevel` WHERE `userlevel`.`fk_user_id` ='.$userid;
    $query=$this->db->query($sql);
    return $query->row_array();
	/*$this->db->select('IFNULL(total_mcoin_points,"0") as total_mcoin_points');
	$this->db->where('userlevel.fk_user_id',$userid);
	$res=$this->db->get('tbl_user_levels as userlevel');
    return $res->row_array();    */
	
}

public function gettenuretransactionmultiplier($userid)
{
	$this->db->select('sum(input_npm) as tenuresum');
	$this->db->join('tbl_user_loans as loanuser','loanuser.id = loanvariants.fk_user_loan_id');
	$this->db->where('loanuser.fk_user_id',$userid);
	$res=$this->db->get('tbl_user_loan_variants as loanvariants');
    return $res->row_array();    
}


public function getvalueoftransactionmultiplier($userid)
{
	$this->db->select('sum(borrower_da) as borrower');
	$this->db->join('tbl_user_loans as loanuser','loanuser.id = loanvariants.fk_user_loan_id');
	$this->db->where('loanuser.fk_user_id',$userid);
	$res=$this->db->get('tbl_user_loan_disbursement as loanvariants');
    return $res->row_array();    
}





    

}