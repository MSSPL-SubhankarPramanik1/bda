<?php

header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

class PaytmPay {
	
    public function __construct(){
		require_once("lib/config_paytm.php");
		require_once("lib/encdec_paytm.php");
    }

    public function getChecksum($paramList){  

		return $checkSum = getChecksumFromArray($paramList, PAYTM_MERCHANT_KEY);
	}


    public function validateChecksum($paramList, $paytmChecksum){ 
		$isValidChecksum 	= "FALSE";
		$isValidChecksum 	= verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum);
        $return_array 		= $paramList;

		$return_array["IS_CHECKSUM_VALID"] = ($isValidChecksum == "TRUE") ? "Y" : "N";
		unset($return_array["CHECKSUMHASH"]);
		return $encoded_json = htmlentities(json_encode($return_array));
	}


    public function cashDisbursal($postData){ 
    	//$request_mode = ($postData['request_mode'] != '')) ? $postData['request_mode'] : 'transaction';
        if(isset($postData['request_mode']) && $postData['request_mode'] != ''){            
            $request_mode = $postData['request_mode'] ;
        } else {
            $request_mode = $postData['request_mode'] = 'transaction';
        }

        $paramList = array();
        $paramList = array(
            'request'           => array(
                'merchantGuid'      => PAYTM_GRATIFICATION_MID_OR_MERCHANT_GUID,
                'merchantOrderId'   => $postData['order_id'],
                'salesWalletGuid'   => PAYTM_GRATIFICATION_SALES_WALLET_GUID,
                'payeeEmailId'      => NULL,	//$postData['payee_email_id'],
                'payeePhoneNumber'  => $postData['payee_phone_number'],
                'payeeSsoId'        => NULL,	//$postData['payee_sso_id'],
                'appliedToNewUsers' => 'N',
                'amount'            => $postData['amount'],
                'currencyCode'      => 'INR'        
            ),
            'metadata'          => $postData['order_id'].'###'.$postData['payee_phone_number'].'###'.$postData['amount'].'###'.$postData['user_id'].'###'.$request_mode,
            'ipAddress'         => $postData['ip_address'],
            'operationType'     => 'SALES_TO_USER_CREDIT',
            'platformName'      => 'PayTM'
        );
        if($postData['request_mode'] && $postData['request_mode'] == 'verify'){
            $paramList['request']['requestType'] = $postData['request_mode'];
        }
        
        //pre($paramList,1);
        $data_string = json_encode($paramList);


        //Here checksum string will return by getChecksumFromArray() function.
        $checkSum = "";
        $checkSum = getChecksumFromString($data_string, PAYTM_GRATIFICATION_MERCHANT_KEY);

        $ch     = curl_init();                    // initiate curl
        $url    = PAYTM_GRATIFICATION_URL_SALES_TO_USER_CREDIT;

        $headers = array('Content-Type:application/json','mid:'.PAYTM_GRATIFICATION_MID_OR_MERCHANT_GUID,'checksumhash:'.$checkSum);

        $ch = curl_init();  // initiate curl
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_POST, 1);  // tell curl you want to post something
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string); // define what you want to post
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // return the output in string format
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);     
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);    
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec ($ch); // execute
        //pre(json_decode($output));
        //$info = curl_getinfo($ch);
        $result_arr         = json_decode($response, true);
        return $result_arr;
    }


    public function repaymentStatusChecking($order_id){
        $ORDER_ID = $order_id;

        $requestParamList = array("MID" => PAYTM_MID , "ORDERID" => $ORDER_ID); 
        return $responseParamList = getTxnStatus($requestParamList);
    }


    public function disbursementStatusChecking($merchant_order_id){ 

        $paramList = array();
        $paramList = array(
            'request'           => array(
                'requestType'   => 'merchanttxnid',        
                'txnType'       => 'salestouser',
                'txnId'         => $merchant_order_id,
                'merchantGuid'  => PAYTM_GRATIFICATION_MID_OR_MERCHANT_GUID
            ),

            'platformName'      => 'PayTM',
            'operationType'     => 'CHECK_TXN_STATUS'
        );
        
        //pre($paramList,1);
        $data_string = json_encode($paramList);


        //Here checksum string will return by getChecksumFromArray() function.
        $checkSum = "";
        $checkSum = getChecksumFromString($data_string, PAYTM_GRATIFICATION_MERCHANT_KEY);

        $ch     = curl_init();                    // initiate curl
        $url    = PAYTM_GRATIFICATION_URL_CHECK_STATUS;

        $headers = array('Content-Type:application/json','mid:'.PAYTM_GRATIFICATION_MID_OR_MERCHANT_GUID,'checksumhash:'.$checkSum);

        $ch = curl_init();  // initiate curl
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_POST, 1);  // tell curl you want to post something
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string); // define what you want to post
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // return the output in string format
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);     
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);    
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec ($ch); // execute
        //pre(json_decode($output));
        //$info = curl_getinfo($ch);
        $result_arr         = json_decode($response, true);
        return $result_arr;
    }



}

?>