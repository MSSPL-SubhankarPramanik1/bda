<?php

// PAYMENT GATEWAY
// STAGING
define('PAYTM_MID', 				'Maybri48991263705015');
define('PAYTM_MERCHANT_KEY', 		'RWjbgg28OGNQiW%F');
define('PAYTM_INDUSTRY_TYPE_ID',	'Retail');
define('PAYTM_CHANNEL_ID', 			'WAP');
define('PAYTM_WEBSITE', 			'APP_STAGING');
define('PAYTM_STATUS_QUERY_URL',	'https://pguat.paytm.com/oltp/HANDLER_INTERNAL/TXNSTATUS');

// LIVE
/*define('PAYTM_MID', 				'MayVen59111641548797');
define('PAYTM_MERCHANT_KEY', 		'0_mzd61VBxbrjaYu');
define('PAYTM_INDUSTRY_TYPE_ID',	'Retail109');
define('PAYTM_CHANNEL_ID', 			'WAP');
define('PAYTM_WEBSITE', 			'MayVenWAP');
define('PAYTM_STATUS_QUERY_URL',	'https://secure.paytm.in/oltp/HANDLER_INTERNAL/TXNSTATUS');*/

// ============================================================================================

// GRATIFICATION
// STAGING
define('PAYTM_GRATIFICATION_SALES_WALLET_GUID', 		'3c1e010d-062a-4a89-a449-c3adcce853a2');
define('PAYTM_GRATIFICATION_MID_OR_MERCHANT_GUID', 		'4ac3e863-5b4b-4adb-bb00-4024662b3ac4');
define('PAYTM_GRATIFICATION_MERCHANT_KEY', 				'TOe#7bkig4rz@UOQ');
define('PAYTM_GRATIFICATION_URL_SALES_TO_USER_CREDIT', 	'http://trust-uat.paytm.in/wallet-web/salesToUserCredit');
define('PAYTM_GRATIFICATION_URL_CHECK_STATUS', 			'http://trust-uat.paytm.in/wallet-web/checkStatus');

// LIVE
/*define('PAYTM_GRATIFICATION_SALES_WALLET_GUID', 		'ab991c37-1c7a-4322-af59-e27c26b38c20');
define('PAYTM_GRATIFICATION_MID_OR_MERCHANT_GUID', 		'1813a05d-d1f6-4bcc-a2a0-bbe9ea15620a');
define('PAYTM_GRATIFICATION_MERCHANT_KEY', 				'NFc5bK4OJ!8zYwIJ');
define('PAYTM_GRATIFICATION_URL_SALES_TO_USER_CREDIT', 	'https://trust.paytm.in/wallet-web/salesToUserCredit');
define('PAYTM_GRATIFICATION_URL_CHECK_STATUS', 			'http://trust.paytm.in/wallet-web/checkStatus');*/

?>
