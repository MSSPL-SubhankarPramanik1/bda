<?php

class Creditlimt {

    public $_master_configurations = 'master_configurations';

    public function __construct(){

    	 $this->ci =& get_instance();

    }

  /**
     * mCoins Multiplier	
     *  $AA = $totalmcoin / $mcd
     *
  **/
public function mcoinsmultiplier($totalmcoin)
{    
	 	//$this->ci =& get_instance();
	 //	$this->ci->db->select('mcd');
	 //	$row=$this->ci->db->get('master_credit_limits')->row_array();
		$json = $this->getalljson();

	 	$row = json_decode($json,true);

		$mcd = $row['mcoins_multiplier']['mcoins_divisor']; //set by admin;

		$AA = $totalmcoin / $mcd;

		if($AA > 1)
		{
			 $val = number_format((float)$AA, 2, '.', '');
			 return $val * 100;
		}
		else
		{ 
			return 1;
		} 
		
}

 /**
     * tenure of transaction multiplier	
     *  $Z = $sumofalltenuretransaction / $TTD
     *
  **/

 public function tenureoftransactionmultiplier($sumofalltenuretransaction)
 {
		/*$this->ci->db->select('ttd');
	 	$row=$this->ci->db->get('master_credit_limits')->row_array();*/
	 	$json = $this->getalljson();
	 	$row = json_decode($json,true);

 		$TTD = $row['tenure_transaction_multiplier']['transaction_tenure_divisor']; //Set by admin;

 		$Z = $sumofalltenuretransaction / $TTD;

 		if($Z > 1)
 		{
 			$val = number_format((float)$Z, 2, '.', '');
 			return $val * 100;
 		}
 		else
 		{
 			return 1;
 		}
 }

 /**
     * value of transaction multiplier	
     *  $Y = $sumofdisbursementtransaction / $VD
     *
  **/

 public function valueoftransactionmultiplier($sumofdisbursementtransaction)
 {
 		/*$this->ci->db->select('vd');
	 	$row=$this->ci->db->get('master_credit_limits')->row_array();*/
	 	$json = $this->getalljson();
	 	$row = json_decode($json,true);
 		$VD = $row['value_transaction_multiplie']['transaction_divisor']; //Set by admin;

 		$Y = $sumofdisbursementtransaction / $VD;

 		if($Y > 1)
 		{
 			$val = number_format((float)$Y, 2, '.', '');
 			return $val * 100;
 		}
 		else
 		{
 			return 1;
 		}
 }

 /**
     * number of transaction multiplier	
     *  $X = $totalnooftransaction / $TD
     *
  **/

 public function numberoftransactionmultiplier($totalnooftransaction)
 {
 		/*$this->ci->db->select('vd'); 
	 	$row=$this->ci->db->get('master_credit_limits')->row_array();*/
	 	$json = $this->getalljson();
	 	$row = json_decode($json,true);

 		$TD = $row['number_transaction_multiplier']['transaction_divisor']; 

 		$X = $totalnooftransaction / $TD;

 		if($X > 1)
 		{
 			 $val = number_format((float)$X, 2, '.', '');
 			 return $val * 100;
 		}
 		else
 		{
 			return 1;
 		}
 }


 /**
     * Credit Score Factore
     *  $AA = $totalmcoin / $mcd
     *
  **/

 public function creditscorefactore($creditscore)
 {
 		$val = 1000; 
 		$csf = $creditscore / $val;
 		if($csf > 0)
 		{
 			$val = number_format((float)$csf, 2, '.', '');

 			return $val * 100;
 		}
 		
 }


 /**
	 * Calculated Credit limit
     *  
     *
 **/

public function calculatedcreditlimit($CSF,$NTM,$VTM,$TTM,$MCM)
{
	/*$this->ci->db->select('ld,weg_csf,weg_ntm,weg_vtm,weg_ttm,weg_mcm');
	$row=$this->ci->db->get('master_credit_limits')->row_array();
*/
	

	$json = $this->getalljson();
	$row = json_decode($json,true);
	$W1=$row['calculated_credit_limit']['w1'];
	$W2=$row['calculated_credit_limit']['w2'];
	$W3=$row['calculated_credit_limit']['w3'];
	$W4=$row['calculated_credit_limit']['w4'];
	$W5=$row['calculated_credit_limit']['w5'];

	$LD =$row['credit_limit']['lowest_disbursement'];

	$X = (($W1*($CSF/100))+($W2*($NTM/100))+($W3*($VTM/100))+($W4*($TTM/100))+($W5*($MCM/100)));

	$Z = number_format((float)$X, 1, '.', '');
	$CCL = $Z*$LD;

	$result['Z'] = $Z;
	$result['CCL'] = $CCL;

	return $result;

}


 /**
	 * Transaction Limit
     *  
     *
**/

public function transactionlimit($nooftransaction)
{		
		/*$this->ci->db->select('ld,tf');
	 	$row=$this->ci->db->get('master_credit_limits')->row_array();*/
	 	$json = $this->getalljson();
		$row = json_decode($json,true);

		$LD = $row['credit_limit']['lowest_disbursement'];
	    $TF = $row['credit_limit']['transaction_factor'];
		$TL = ($nooftransaction + $TF)*$LD;
		return $TL;
}

 /**
	 * Connection Limit
     *  
     *
**/

public function connectionlimit($noofconnection)
{
		/*$this->ci->db->select('ld,cf');
	 	$row=$this->ci->db->get('master_credit_limits')->row_array();*/

	 	$json = $this->getalljson();
		$row = json_decode($json,true);

		$LD = $row['credit_limit']['lowest_disbursement']; 
		$CF = $row['credit_limit']['connection_factor'];
		$TL = (($noofconnection+$CF)*$LD);
		return $TL;
}

/**
	 * mCoin Limit
     *  
     *
**/

public function mCoinlimit($noofmcoin)
{
		/*$this->ci->db->select('ld,mcf,mcp');
	 	$row=$this->ci->db->get('master_credit_limits')->row_array();*/
	 	$json = $this->getalljson();
		$row = json_decode($json,true);
		$LD =  $row['credit_limit']['lowest_disbursement'];
		$MCF = $row['credit_limit']['mcoins_factor']; 
		$MCP = $row['credit_limit']['mcoins_percentage']; 
		
		if($MCP > 0)
		{ //$MCL = (($noofmcoin + $MCF)/$MCP/100)*$LD)+$LD;
			$MCL = (($noofmcoin + $MCF)*$MCP/100)*$LD+$LD;	
		}
		else
		{	
			$MCL = (($noofmcoin + $MCF)*0)*$LD+$LD;
		}
		
		return $MCL;
}

/**
	 * Credit Limit
     *  
     *
**/
public function creditlimit($CCL,$TL,$CNL,$MCL,$pastdue)
{ 
		$json = $this->getalljson();
		$row = json_decode($json,true);
		$LD =  $row['credit_limit']['lowest_disbursement'];
		$CreditLimit='';
		
		$MINCAL = min($CCL,$TL,$CNL,$MCL);
		$CL = max($MINCAL,$LD);
		if($pastdue>0)
		{
			$CreditLimit = 0;
		}else
		{
			$CreditLimit = $CL;
		}

		return $CreditLimit;
}


public function getalljson()
{
	$this->ci->db->select('credit_limit_json');
	 $row=$this->ci->db->get($this->_master_configurations)->row_array();
	 return $row['credit_limit_json'];
}

/*********/
}
?>