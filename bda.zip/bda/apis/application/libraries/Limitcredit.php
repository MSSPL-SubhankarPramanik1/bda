<?php

class Limitcredit {

    public $_master_configurations = 'master_configurations';

    public function __construct(){

    	 $this->ci =& get_instance();

    }

  /**
     * mCoins Multiplier	
     *  $AA = $totalmcoin / $mcd
     *
  **/
public function mcoinsmultiplier($totalmcoin)
{    
		$json = $this->getalljson();
	 	$row = json_decode($json,true);
		$mcd = $row['mcoins_multiplier']['mcoins_divisor']; //set by admin;
		$AA = $totalmcoin / $mcd;
		if($AA > 1)
		{
			 $val = number_format((float)$AA, 2, '.', '');
			 return $val * 100;
		}
		else
		{ 
			return 1;
		} 
		
}

 /**
     * tenure of transaction multiplier	
     *  $Z = $sumofalltenuretransaction / $TTD
     *
  **/

 public function tenureoftransactionmultiplier($sumofalltenuretransaction)
 {
	 	$json = $this->getalljson();
	 	$row = json_decode($json,true);

 		$TTD = $row['tenure_transaction_multiplier']['transaction_tenure_divisor']; //Set by admin;

 		$Z = $sumofalltenuretransaction / $TTD;

 		if($Z > 1)
 		{
 			$val = number_format((float)$Z, 2, '.', '');
 			return $val * 100;
 		}
 		else
 		{
 			return 1;
 		}
 }

 /**
     * value of transaction multiplier	
     *  $Y = $sumofdisbursementtransaction / $VD
     *
  **/

 public function valueoftransactionmultiplier($sumofdisbursementtransaction)
 {	
	 	$json = $this->getalljson();
	 	$row = json_decode($json,true);
 		$VD = $row['value_transaction_multiplie']['transaction_divisor']; //Set by admin;
 		$Y = $sumofdisbursementtransaction / $VD;
 		if($Y > 1)
 		{
 			$val = number_format((float)$Y, 2, '.', '');
 			return $val * 100;
 		}
 		else
 		{
 			return 1;
 		}
 }

 /**
     * number of transaction multiplier	
     *  $X = $totalnooftransaction / $TD
     *
  **/

 public function numberoftransactionmultiplier($totalnooftransaction)
 {

	 	$json = $this->getalljson();
	 	$row = json_decode($json,true);
 		$TD = $row['number_transaction_multiplier']['transaction_divisor']; 
 		if($TD>=1)
 		{
			$X = $totalnooftransaction / $TD;
			if($X > 1)
			{
				$val = number_format((float)$X, 2, '.', '');
				return $val * 100;
			}
			else
			{
				return 1;
			}
 		}
 		else
 		{
 			return 0;
 		}


 }


 /**
     * Credit Score Factore
     *  $AA = $totalmcoin / $mcd
     *
  **/

 public function creditscorefactore($creditscore)
 {
 		$val = 1000; 
 		$csf = $creditscore / $val;
 		if($csf > 0)
 		{
 			$val = number_format((float)$csf, 2, '.', '');

 			return $val * 100;
 		}
 		
 }


 /**
	 * Calculated Credit limit
     *  
     *
 **/

public function calculatedcreditlimit($CSF,$NTM,$VTM,$TTM,$MCM)
{
	$json = $this->getalljson();
	$row = json_decode($json,true);
	$LD =$row['credit_limit']['lowest_disbursement'];
	$Ceiling =$row['credit_limit']['Ceiling'];
	$MDM = ($Ceiling/$LD)+1;
	$W1_percentage=$row['calculated_credit_limit']['w1'];
	$W2_percentage=$row['calculated_credit_limit']['w2'];
	$W3_percentage=$row['calculated_credit_limit']['w3'];
	$W4_percentage=$row['calculated_credit_limit']['w4'];
	$W5_percentage=$row['calculated_credit_limit']['w5'];
	$W1 = ($W1_percentage/100) * $MDM; 
	$W2 = ($W2_percentage/100) * $MDM;
	$W3 = ($W3_percentage/100) * $MDM;
	$W4 = ($W4_percentage/100) * $MDM;
	$W5 = ($W5_percentage/100) * $MDM;
	//$X = (($W1*($CSF/100))+($W2*($NTM/100))+($W3*($VTM/100))+($W4*($TTM/100))+($W5*($MCM/100)));
	$X = (($W1*$CSF) + ($W2*$NTM) + ($W3*$VTM) + ($W4*$TTM) + ($W5*$MCM));
	$Z = number_format((float)$X, 1, '.', '');
	$CCL = $Z*$LD;
	$result['Z'] = $Z;
	$result['CCL'] = $CCL;
	$result['MDM'] = $MDM;
	return $result;

}


 /**
	 * Transaction Limit
     *  
     *
**/

public function transactionlimit($nooftransaction)
{		
	 	$json = $this->getalljson();
		$row = json_decode($json,true);

		$LD = $row['credit_limit']['lowest_disbursement'];
	    $TF = $row['credit_limit']['transaction_factor'];
		$TL = ($nooftransaction + $TF)*$LD;
		return $TL;
}

 /**
	 * Connection Limit
     *  
     *
**/

public function connectionlimit($noofconnection)
{
	 	$json = $this->getalljson();
		$row = json_decode($json,true);

		$LD = $row['credit_limit']['lowest_disbursement']; 
		$CF = $row['credit_limit']['connection_factor'];
		$TL = (($noofconnection+$CF)*$LD);
		return $TL;
}

/**
	 * mCoin Limit
     *  
     *
**/

public function mCoinlimit($noofmcoin)
{
	 	$json = $this->getalljson();
		$row = json_decode($json,true);
		$LD =  $row['credit_limit']['lowest_disbursement'];
		$MCF = $row['credit_limit']['mcoins_factor']; 
		$MCP = $row['credit_limit']['mcoins_percentage']; 
		
		if($MCP > 0)
		{ 
			$MCL = (($noofmcoin + $MCF)*$MCP/100)*$LD+$LD;	
		}
		else
		{	
			$MCL = (($noofmcoin + $MCF)*0)*$LD+$LD;
		}
		
		return $MCL;
}

/**
	 * Credit Limit
     *  
     *
**/
public function creditlimit($CCL,$TL,$CNL,$MCL,$pastdue)
{ 
		$json = $this->getalljson();
		$row = json_decode($json,true);
		$LD =  $row['credit_limit']['lowest_disbursement'];
		$Ceiling =  $row['credit_limit']['Ceiling'];
		$CreditLimit='';
		
		$MINCAL = min($CCL,$TL,$CNL,$MCL);
		$MaxVal = max($MINCAL,$LD);
		$CL = min($Ceiling,$MaxVal);
		if($pastdue>0)
		{
			$CreditLimit = 0;
		}else
		{
			$CreditLimit = $CL;
		}
		return $CreditLimit;
}


public function getalljson()
{
	$this->ci->db->select('credit_limit_json');
	 $row=$this->ci->db->get($this->_master_configurations)->row_array();
	 return $row['credit_limit_json'];
}

/*********/
}
?>