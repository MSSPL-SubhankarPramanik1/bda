<?php

class Mrupee {

    public function __construct(){
        // SET JAVA ENVIROMENTAL VARIABLE
        //$JAVA_HOME = "/usr/local/jdk1.5.0_15";
        $JAVA_HOME = "/etc/java-8-openjdk";
        $PATH = "$JAVA_HOME/bin:/usr/local/bin:/usr/bin:/bin";
        putenv("JAVA_HOME=$JAVA_HOME");
        putenv("PATH=$PATH");        
    }

    public function generateMpinHashing($mpin, $mobile){

        // SET MPIN AND MOBILE VARIABLE
        //echo $mpin. "<====>" .$mobile;

        // COMPILE JAVA APPLICATION
        if(!file_exists( APPPATH . "libraries/mRupee/com/tcs/mwallet/MpinGeneration/GenerateMpinHashing.class")){
            shell_exec("cd " . APPPATH . "libraries/mRupee/; javac " . APPPATH . "libraries/mRupee/GenerateMpinHashing.java -d . 2>&1");
        }

        // CALL JAVA.CLASS
        $mPinHash = shell_exec("cd " . APPPATH . "libraries/mRupee/; java com.tcs.mwallet.MpinGeneration.GenerateMpinHashing ". $mpin ." ". $mobile ." 2>&1");
        return $mPinHash;
    }
}


?>
