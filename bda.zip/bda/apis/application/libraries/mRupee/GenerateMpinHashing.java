package com.tcs.mwallet.MpinGeneration;
import com.tcs.encrypt.EncryptUserData;

public class GenerateMpinHashing
{
	public static void main(String[] args) {

		String mpin 	= args[0];
		String mobile 	= args[1];

		EncryptUserData eud = new EncryptUserData();		
		String encMpin = eud.encryptData(mpin, mobile);

		System.out.print(encMpin);
	}
}
